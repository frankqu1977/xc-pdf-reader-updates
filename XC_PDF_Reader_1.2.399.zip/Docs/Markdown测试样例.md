# XC PDF Reader Markdown 阅读测试

这是一份用来验证 **Markdown → PDF 排版** 的样例文档，覆盖标题、段落、列表、引用、代码块、表格与图片。
文字应当可以*选中*、复制，也能被全文搜索命中（比如搜索「矢量文字层」）。

## 二级标题：行内样式

普通文字、**加粗文字**、*斜体文字*、~~删除线~~、`行内代码 inline code`，以及一个 [链接示例](https://example.com/docs)。
中英文混排：The quick brown fox jumps over the lazy dog，数字 1234567890，标点「，。！？」。

### 三级标题：无序列表

- 第一项：短文本
- 第二项：稍微长一点的条目，用来验证折行之后左侧圆点与续行是否对齐，这一段继续写长一些看看换行效果如何。
  - 嵌套子项 A
  - 嵌套子项 B
- 第三项：任务列表
- [x] 已完成的任务
- [ ] 未完成的任务

### 有序列表

1. 打开 `首选项 ▸ 文件关联`
2. 打开 Markdown 开关
3. 双击任意 `.md` 文件验证

## 引用

> 转换链路：Markdown → 临时 PDF → pdfium 渲染。
> 这样缩放、缩略图、全文搜索、打印与标注都能直接复用，不需要另写一套阅读器。

## 代码块

```csharp
// 代码块使用等宽字体，缩进与行距保持紧凑
public static string GetPdf(string mdPath)
{
    string key = CacheKey(mdPath);
    return Path.Combine(CacheDir, key + ".pdf");
}
```

## 表格

| 格式 | 扩展名 | 处理方式 | 文字层 |
| --- | --- | --- | --- |
| PDF | .pdf | 原生 pdfium | 有 |
| OFD | .ofd | 转临时 PDF | 有 |
| XPS | .xps / .oxps | 自研解析转 PDF | 有 |
| Markdown | .md / .markdown | 排版为 PDF | 有 |

## 图片

![文件关联开关截图](..\bin\Publish\03_Setup\文件关联5档_1.2.326.png)

## 分隔线

---

结尾段落：如果这一页排满，应当自动分页，并在页脚显示页码；正文的矢量文字层不会因为分页而丢失。
