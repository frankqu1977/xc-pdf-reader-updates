﻿# Bug 修复记录

## 2026-11-26 V1.2.379

**定版｜检查更新窗口精简、浅色主题降白、文档属性居中、默认偏好固化**

- 「检查更新」窗口：删除「更新说明：…」整段与 `OnInstall` 的下载确认框；宽度改为 `620`、`SizeToContent=Height`、`MinHeight=250`，`ResizeMode=NoResize` 且只保留关闭按钮；版本信息与说明占左侧，检查更新 / 下载并安装、打开发布页、关闭收进右侧 `146 DIP` 竖排操作栏，按钮统一 `122×30` 居中排列；状态文字移到说明区下方，底部空白由自动高度消化。
- 浅色主题：`ThemeManager.LightPalette` 的 `WindowBg #E9EDF2`、`PanelBg/MenuBg #F2F4F7`、`TabBarBg #E0E5EB`、`DocAreaBg #DDE2E9`、`Border #CFD7E1`、`InputBg #F9FAFC` 等改为蓝灰层级，避免工具栏、标签栏、状态栏和对话框一片纯白；PDF 纸张仍保持白色渲染。
- 文档属性居中：原 `Loaded` 先调用 `FitHeightToContent()` 再定位，且最大化 owner 的 WPF `Left/Top` 带约 `-7.6 DIP` 的屏幕外边框，导致约 `9.5px` 偏移。`DialogCentering.Center` 在高度定稿后执行；owner 最大化时改为按 `MonitorWork` 工作区居中。实测 owner `0,0 1920×1020`，对话框 `378,79 1163×861`，中心 `959.5,509.5`，偏差 `0.5px`。
- 默认偏好：`AppPrefs` 的默认值改为当前配置中的可复用项，包括浅色主题、侧栏宽度、菜单图标、右键工具集合和硅基流动 Hunyuan-MT-7B 模型；不内置 API Key、最近文件、阅读位置与搜索历史。已有 `prefs.json` 不被覆盖。
- 验证：Release 重建通过；冷启动正常；测试实例与临时截图已清理。

## 2026-11-25 V1.2.346

**修复｜彩色 Emoji 在标题中与文字错位**
- 现象：V1.2.345 生词本 PDF 里 `⭐ abbreviation` 的星星颜色正确，但明显低于标题文字；字号越大越歪。
- 根因：内联图片统一用 `y = baseline - height × 0.82`，也就是把图片底边放在基线附近；emoji 是字身框式图形，不能按底边贴基线。
- 改法：图片分支对 `it.Emoji` 单独用 `y = baseline - height × 0.30`，公式与 SVG 保持原逻辑。
- 验证：`# ⭐ abbreviation`、`## ⭐ Codex`、正文 ⭐ 三档字号渲染截图均与同行文字对齐；增量构建 0 错误 0 警告。

## 2026-11-25 V1.2.345

**修复｜Markdown 音标字符变 `?`、星形 Emoji 退化成问号**
- 现象：用户生词本 MD 在另一预览器里显示 `⭐ abbreviation`、`音标: /əˈbreviˈeɪʃn/`，本程序 PDF 里变成 `? abbreviation`、`音标: /e'brevi'efn/`。
- 根因：① Deng/SimHei 的 cmap 不含 IPA 扩展码位，`HexFor` 统一映射成 `?`；② 星形 emoji 的彩色图片路径正常，但用户运行的是旧版本（标题栏 V1.2.339），当前版本已修复；本版仍补充了缺字兜底，避免其它特殊符号再退化。
- 改法：`MdPdfWriter` 增加 F3 兜底字体槽（Segoe UI/Arial/Times），`SlotOf` 逐字检测缺字并切换；兜底文本用 WPF `FormattedText` 渲染成透明 PNG 嵌入，缓存基线偏移并按 `y = baseline - imgHeight + baselineOffset` 放置（PDF 图片 `cm` 原点在左下角，这点最容易错）。`TtfSubsetter` 改为小子集 short loca、超限才 long loca。
- 验证：生词本样例渲染截图中 H1~H6 中文、`⭐`、IPA 音标全部正确且与正文基线一致；6000 汉字大字集回归 5 页 / 2036KB 无异常；构建 0 错误 0 警告。
- 已知取舍：兜底音标是图片，PDF 文本层不再包含这段字符；中文与 ASCII 正文仍可选中复制。

## 2026-11-25 V1.2.343

**修复｜含大量汉字的 Markdown 打开失败（short loca 溢出）**
- 现象：弹窗 `Could not open Markdown file`，内容为 `子集后 glyph 超出 short loca 上限`。
- 根因：`TtfSubsetter` 固定输出 short loca，偏移值是 `glyf 字节数 / 2` 且塞进 16 位；字符集大时 glyf 超过约 128KB 即溢出。
- 改法：输出改为 long loca（32 位字节偏移），`head.indexToLocFormat` 写 1，`loca` 表按 4 字节写入；源字体仍按原格式读取，输入兼容性不变。
- 验证：6000 个不同汉字样例成功生成 5 页 / 约 2MB PDF；嵌入字体 `numGlyphs=6010`、`glyf=2818050`、`locaFormat=1`；构建 0 错误 0 警告。

## 2026-11-25 V1.2.342

**修复｜MD 另存 PDF 用缓存哈希名、标题只有一种颜色；外链图片无法打包进单文件 MD**
- 现象：MD/OFD/XPS 转换文档「另存为 PDF」默认文件名是 `md-cache\哈希.pdf`；六级标题在 PDF 里全是同一个深色；带外链图片的 MD 另存后仍是外部链接，脱离网络就丢图。
- 改法：
  - `MainWindow` 新增 `OnExportPdf`，按源文件基名导出；无打开文档时弹选择框走 `MdConverter / OfdConverter / XpsConverter / PostScriptConverter` 通用映射。
  - `ThemeManager.MarkdownHeadingHex(level)` 提供 H1~H6 浅色主题色，`MdPdfWriter.HeadingColor()` 转成 PDF 色算子；`MdConverter` 缓存键接入程序集版本，避免旧 PDF 掩盖新排版。
  - 新增 `Markdown/MdSingleFile.cs`：逐行扫描 Markdown 图片语法（跳过围栏代码块），http(s) 下载、本地图片读取、签名/MIME 嗅探，统一编码成 `data:` URI；`OnSaveAs` 对 MD 默认写单文件 `.md`，选 PDF 过滤器仍走原来的 PDF 另存。下载失败保留原链接并提示数量。
- 验证：反射检查六级 `HeadingColor` 与 PDF 内容流中的色算子一致；`/Outlines`、`/PageMode /UseOutlines` 均存在；代码块关键字/字符串/注释着色算子存在；含本地图片与既有 data URI 的样例另存后原相对路径 0 残留；构建 0 错误 0 警告。

## 2026-11-25 V1.2.341

**修复｜英文界面「文件关联」页残留中文**
- 现象：切到英文后，文件关联页的说明句、四种格式名与扩展名提示、`默认` 状态标签仍是中文（`Markdown document` 与底部状态行已是英文）。
- 原因：这些文案是 XAML 写死的中文或运行时拼出的状态词，`UiText.En` 缺少对应键；`UiText.Translate` 查不到译文就原样保留中文。
- 改法：在 `Localization/UiText.cs` 的文件关联段补齐 13 条译文（含 `已关闭 / 未关联 / 已关联`，避免开关拨动后再出中文）。
- 验证：反射切到 `en-US` 后逐条调用 `UiText.T` 均返回英文；Release 构建 0 错误 0 警告。

## 2026-11-25 V1.2.340

**修复｜Markdown 渲染特殊行内项被合并成文本；Emoji / 公式显示为 `?`；SVG data URI 解析失败**
- 现象：Emoji、行内公式 span 与相邻普通文字样式相同，`DrawItems` 的连续合并循环把它们当作普通字符拼进正文，最终用正文字体画出 `?`；公式块因基线传入位置错误被裁成空白；SVG data URI 因在 .NET Framework 上调用 `string.Contains(string, StringComparison)`（运行时缺失该重载）落入 catch 并返回 false。
- 改法：合并循环排除 `IsImage` / 脚注项；公式布局改为以绝对基线排版并重新计算高度；data URI 判断改用 `IndexOf(..., StringComparison)`。Emoji 改为读取系统字体 COLR/CPAL 分层并用 `GlyphRun` 上色；带 alpha 的图片按像素合成到白底，避免透明区域变黑。
- 验证：样例文档中 🚀 / 😀 / 👩‍💻 显示为彩色图片，`$E=mc^2$` 与 `\frac{a}{b}+\sqrt{x}=\sum_{i=1}^{n}i` 正常成像，`data:image/svg+xml;base64,...` 正常显示；PDF 文本层不再含 Emoji 乱码；构建 0 错误 0 警告。

## 2026-11-24 V1.2.316

**修复｜英文界面属性页的中文残留；属性页移除「文件」分组标题**
- 现象：英文模式下属性页仍显示 `文件`（分组标题）、`文件名 / 大小 / 创建时间 / 修改时间 / 页数 / 页面尺寸 / 主题 / 关键词 / 创建程序 / PDF 生成程序 / 创建日期 / 修改日期`，值里的单位仍是 `38 页`、`… 字节`。
- 改法：`UiText.EnExtra` 补齐上述词条；分组标题改用 `UiText.T(group.Key)` 在创建时取词（不再依赖窗口 Loaded 的整树翻译）；`DocumentPropertiesDialog.LocalizeValue` 在英文下把数据层拼出的单位句子转成英文（`N 页 → N pages`、`… 字节 → … bytes`、全角括号转半角）。
- 另按需求移除「文件」分组标题：`Header = group.Key == "文件" ? null : …`，第一块信息直接以文件名开头。
- 验证：`--propshot ... en-US` 属性页无中文标签，值显示 `38 pages` / `4,963,386 bytes`；中文页无「文件」标题；构建 0 错误 0 警告。

## 2026-11-24 V1.2.315

**新增｜文档属性窗口改为「属性 / 字体 / 安全」三个选项卡**
- 需求：按参考截图，在文档属性里补「字体」「安全」两个选项卡，原有页面选项卡更名为「属性」。
- 改法：`DocumentPropertiesDialog` 换成 `TabControl`（自带下划线页签模板，深色下不再露出浅灰 3D 边框），三页共用一个 `DockPanel` 页脚；构造函数改为接收 `PdfDocument`，字体页首次选中时 `Task.Run` 扫描（`PdfDocument.GetDocumentFonts()` 用 `FPDFPage_GetObject` + `FPDFTextObj_GetFont` + `FPDFFont_GetBaseFontName/GetFamilyName` 读名字，按名字归并，`ABCDEF+` 前缀判嵌入子集）。
- 安全页复用 `PdfDocument.IsEncrypted / Permissions / SecurityRevision`，权限位逐项「允许 / 禁止」。
- 踩坑：① `FPDFFont_GetBaseFontName` 的缓冲是 `char*`（UTF-8 字节），按 `ushort*` 读会得到一串乱码字体名；② `XamlReader.Parse` 的模板里用 `x:Name` 必须在根上声明 `xmlns:x`，否则整个类型初始化抛 `XamlParseException`；③ `FPDF_GetSecurityHandlerRevision` 未加密时返回 **-1**，`SecurityRevision` 要 `Math.Max(0, …)`；④ 窗口高度在构造函数里量不准（GroupBox 模板未套用），改到 `Loaded` 里按整棵树量，探针则显式调用 `FitHeightToContent()`。
- 验证：`--propshot` 三个选项卡 × 深色 / 浅色 / 英文 + 加密样本，字体 7 条、加密 `revision=3 permissions=0xFFFFF2C4` 全部符合预期；构建 0 错误 0 警告。

## 2026-11-24 V1.2.314

**改进｜书签当前位置底板：贴左边沿、加粗竖线、半透明底色**
- 现象：1.2.313 的底板放在行模板里，行本身带层级缩进，且被上一级 `ItemsPresenter` 裁切，底板左侧永远缺一截（实测起点约 25 DIP，不是 0）。
- 改法：底板改为 `OutlineHost` 上的独立浮层 `OutlineCurrentOverlay`（`VerticalAlignment=Top`、`Height/Margin.Top` 由当前行 `TransformToAncestor` 计算），树背景改 `Transparent` 让浮层透出；行模板删除 `CurrentBar`，`IsCurrent` 触发只负责文字染色，并把本行背景设为透明（悬停所选也不覆盖）；底色统一 50% alpha。
- 位置重摆：`SelectOutlineNode` 内 `OutlineHost.UpdateLayout()` 后摆一次、`Dispatcher.Background` 再补一次；`OutlineHost` 挂 `ScrollViewer.ScrollChanged` 处理树自身滚动与展开折叠；当前行滚出视口自动收起。
- 验证：`overlay=Visible ovH=20.8 rowH=22.4 ovW=292.8 rowX=32.8`（底板宽覆盖整行、左沿 x=0）；渲染图 `书签当前_1.2.314_浅色.png`（绿）/ `_深色.png`（蓝）逐像素核对；跟随断言仍为 `isCurrent=True`、页内切换正常；构建 0 错误 0 警告。

## 2026-11-24 V1.2.313

**改进｜书签当前位置的底板与强调条（按参考截图）**
- 需求：底色矩形拉到侧栏左边沿、左边竖线加粗；深色模式蓝、浅色 / 护眼模式绿。
- 改法：`CurrentBar` 左边距改 0（`Margin="0,1,2,1"`），条内嵌 `CurrentBarEdge`（`Width=3`、`CornerRadius=1.5`、上下各留 3px）取 `Th.OutlineCurrentEdge` 上色；`ThemeManager` 浅色板改绿（`#E3F5E9 / #2E9E5B / #146B39`）、深色板蓝（`#22395C / #4C8DF6 / #D3E5FF`），`EyeCareTint` 补护眼绿（`#E1F2E4 / #2C8F4E / #14613A`）。
- 探针：`--outlineshot` 增加可选 `[theme]` 参数，分别渲染 Light / Dark。
- 验证：Light → 绿条绿线深绿字；Dark → 蓝条蓝线浅蓝字；跟随断言 `isCurrent=True`、页内 `frac=0.60` → `2.6.3` 均通过；渲染图 `书签当前_1.2.313_浅色.png` / `_深色.png`；构建 0 错误 0 警告。

## 2026-11-24 V1.2.312

**改进｜书签跟随的显示方式与页内定位（对齐参考截图）**
- 显示：选中不再是整行米色，当前小节改为浅蓝圆角条 + 深蓝半粗字；`PART_Header` 改拉伸 + 书签行右侧留 8px，长标题以省略号收尾，不会被侧栏滚动条压住裁断。
- 定位：原实现只按页号（`PickOutlineForPage`），一页里排着 2.6.2 / 2.6.3 多个小节时永远停在第一节。现改为 `PickOutlineForPosition`：用标题文本实际位置（`OutlineNodeFraction`）算每个书签的页内比例，取视口上沿之上最后一个；视口还在本页第一小节之上就归到上一页最后一节；本页无可定位书签才退回按页判断。
- 状态：新增 `OutlineItem.IsCurrent`（独立于选中态，不落盘不参与书签持久化），模板触发浅蓝条与半粗字；`_outlineLastFrac` 位移 <0.4% 页高不重算，页内位置表按页缓存、换文档与改编书签时清空。
- 验证：`--outlineshot` 页 30 `isCurrent=True`；页内 `frac=0.60` → 2.6.3（2.6.2 的 IsCurrent 置回 false）、`frac=0.004` → 上一页 2.6.1；渲染图 `书签跟随_1.2.312.png` / `_页内.png`；`--advshot` 回归无变化；构建 0 错误 0 警告。
## 2026-11-24 V1.2.311

**改进｜滚动正文时左侧书签树不跟随（高亮停在旧章节）**
- 现象：200% 缩放读 GD32F502xx 数据手册，正文已滚到「2.6.2 GD32F502Rx LQFP64 pin definitions」，左侧书签仍高亮「2.3 Pinouts and pin assignments」，「2.6 Pin definitions」还是折叠的，看不出读到哪一节。
- 根因：`OnScrollChanged → SyncCurrentPageFromOffset` 只同步缩略图选中项与状态栏；`SyncOutlineNav(page)` 也只改 `ThumbList.SelectedIndex`。整条链路没有任何大纲展开 / 高亮逻辑，`OnOutlineSelected` 只在点击时生效。
- 改法：新增 `SyncOutlineToPage`：`PickOutlineForPage` 取文档顺序里最后一个目标页 ≤ 当前页的书签（同页取更深一级），`FindOutlinePath` 求祖先链，祖先一律展开、自身子树仅在换章节时展开；`SelectOutlineNode` 沿路径逐级取容器设 `IsSelected=true` 再 `BringIntoView`（虚拟化未生成的深层节点本轮跳过）。`OnOutlineSelected` 增加 `_outlineAutoSync` 抑制，避免跟随高亮反触跳页；`BindOutline` 重置 `_outlineCurrent` 并在 Background 按当前页定位；`SideTabs` 切回「书签」时补一次定位；`SyncCurrentPageFromOffset` 里给「页面」标签补 `ThumbList.ScrollIntoView`。
- 验证：`--outlineshot` 合成大纲两组断言——页 30 `rootExpanded=True subExpanded=True selected="2.6.2 GD32F502Rx LQFP64 pin definitions" highlighted=True`；页 8 `selected="2.1 System architecture"` 且 2.6 保持折叠。渲染图 `书签跟随测试.png` / `书签跟随测试_章首.png` 复核高亮与缩进；构建 0 错误 0 警告。
## 2026-11-24 V1.2.310

**修复｜「关于」英文界面出现竖向滚动条**
- 现象：中文一屏读完，切英文后正文底部出现竖滚动条（英文比中文高约 19px）。
- 根因：窗口高度写死 660，真实客户区要扣标题栏与边框，只剩约 617；英文内容 522.5 在离屏排版下看着够，换成真实窗口就刚好越界。
- 改法：`SizeToContent=Height` + `MaxHeight=工作区-48`；`Loaded` 里再兜底一次（若 `ComputedVerticalScrollBarVisibility=Visible`，按 `Extent-Viewport+3` 增大窗口高度）。
- 文案：把两条会折成两行的英文压成一行，减少列高差。
- 验证：`--aboutshot` 改为真实 `Show()`（`Left/Top=-4000` 移出屏幕），实测 `window=800x654.8 client=785.6x617.2 content=503.5 viewport=503.5 scrollbar=Collapsed`，中英一致；英文 `untranslated=0`。

## 2026-11-24 V1.2.309

**改进｜「关于」窗口功能清单**
- 需求：把软件的功能与特色列进「关于」。
- 改法：重写 `Dialogs/AboutBox.cs` 中部为两栏分组清单（`FeatureSections()` 数据驱动，新增 6 组 29 条），页脚改为「运行信息 + 确定」；`Localization/UiText.cs` 新增 30 余条英译与页脚版本模板；新增 `Diagnostics/AboutShot.cs` 与 `--aboutshot` 探针。
- 验证：`--aboutshot` 中文 / 英文 / 亮色三版实测 `needScroll=no`（中 503.5 / 英 522.5，视口 546.4），英文 `untranslated=0`；中文模式下 7 个分组标题原文属正常。

## 2026-11-24 V1.2.308

**改进｜文档行计数改为两色圆徽章**
- 需求：把结果行右侧「21 页 · 51 处」换成两枚不同颜色的数字圆徽章。
- 改法：新增 `Controls/TreeBadges.cs`：`Badge(text, bgKey, fgKey, tip)` 造「圆角 9、MinWidth 18、Height 18」的胶囊，`Pair(pages, hits)` 返回 蓝(页数)+橙(命中数) 并排的 StackPanel；`ThemeManager` 两套色板新增 `BadgePageBg/Text`、`BadgeHitBg/Text`。
- `RunAdvSearch` 文档行：右侧 Dock 的原来那个 `N 页 · M 处` TextBlock 换成 `TreeBadges.Pair(...)`，文件名仍走省略号，悬停名、悬停徽章各有提示。
- 验证：`--advshot` 示例与主窗口共用 `TreeBadges`，340 / 260 px 下两枚徽章均为正圆/胶囊、白字居中、右弧不被裁（放大 4 倍逐像素核对）。

## 2026-11-24 V1.2.307

**改进｜「全部文档」结果树文档行过长，把搜索结果挤出可视区**
- 现象：多文档搜索结果里，文档行显示 `GD32E533xx_Datasheet_Rev0.9RC1.pdf (15 页, …`，右半截被裁，树下方出现横向滚动条，页节点/片段看不到。
- 原因：文档行把整条「文件名（N 页, M 处）」放进一个 TextBlock，既没有省略号也没有宽度约束；`AdvResults` 允许横向滚动，条目按内容无限宽测量，于是溢出。
- 改法：文档行改用 `DockPanel` —— 右侧 `N 页 · M 处`（`FontSize 11`、`Th.TextMuted`、右内边距 8）先 dock，左侧文件名用 `Path.GetFileNameWithoutExtension` + `TextTrimming=CharacterEllipsis`，`ToolTip` 给完整文件名；`AdvResults` 增加 `ScrollViewer.HorizontalScrollBarVisibility="Disabled"`，宽度由面板决定。
- 验证：`--advshot` 的示例改成两份长文件名文档节点，340px / 260px 下文件名均以省略号收尾、右下角字数完整、无横向滚动条；`groupExpanded=True` 确认文档行默认展开（页节点与片段直接可见）。

## 2026-11-24 V1.2.306

**Bug｜中文模式下「搜索 PDF」面板残留英文（Search results / Page N (M matches)）**
- 原因：摘要与页节点标题由 `UiText.Format` 在运行时拼出，属于代码创建的 TextBlock，不在 XAML 静态树中。`UiText.Translate` 只遍历静态树（且窗口只在 `Loaded` 与显式 `ApplyLanguage()` 时翻译），语言切换后这些节点保持旧语言；XAML 里的「立即搜索 / 选项 / 清除结果」会被翻回中文，于是呈现「中文界面 + 英文结果」。
- 改法：`ApplyLanguage()` 追加 `RefreshAdvSearchText()`；面板打开且 `AdvSearchBox` 非空时调用 `RunAdvSearch()` 按新语言重建结果树（片段仍按需生成），无查询词则清空 `AdvSummary`。
- 验证：`--advshot` 新增 `i18n IsEnglish / leak` 自检，中文模式下 `leak=no`；构建 0 错误 0 警告。

## 2026-11-24 V1.2.305

**改进｜搜索 PDF 面板按钮重排：范围取代「立即搜索 / 选项」**
- 诉求：去掉「Search now」「Options」，换成「搜索当前文档 / 全部文档」，默认显示当前文档的搜索结果。
- 改法：XAML 里按钮行改为 `WrapPanel` —— `当前文档`、`全部文档`、`清除结果`；点击范围按钮即按该范围重跑搜索，`UpdateAdvScopeUi()` 用 `Th.Selected` / `Th.PanelAltBg` 给选中态上色；打开面板时 `_advScopeAll = false` 并刷新选中态（默认当前文档）。搜索选项（全词 / 区分大小写）移到提示行右端的「⋯」，复用原 `OnAdvOptions`。
- 多文档：`RunAdvSearch` 的扫描目标由单份 `_doc` 改为 `List<(DocTab Tab, string Label)>`；`_advScopeAll` 时取 `_tabs` 全部标签，逐份扫描、逐份 `ReleaseTextPages()`，文档级异常单独吞掉。结果树在多文档时插一层文档节点（`文件名（N 页, M 处）`），页节点 `Tag` 改为 `AdvPageResult`（含 Doc/Tab）、片段 `Tag` 改为 `AdvHitResult`；`OnAdvPageExpanded` 改用 `pr.Doc` 取片段，`OnAdvResultSelected` 先 `ActivateTab` 再走高亮定位，并拦掉已关闭标签的死引用。
- 摘要模板由「1 文档」固定文案改为 `搜索结果: {0} 文档, {1} 页, {2} 处 ({3}s)`，`UiText` 增补对应英译与进度模板。
- 顺带修正：面板被拖到 220px 时第三个按钮会被裁成空框，改用 `WrapPanel` 自动换行；提示行改两列（星号 + 固定），文字超宽走省略号，不再压到「⋯」下面。

**工具｜新增 `--advshot` 面板版面探针**
- 未显示窗口里列宽动画不推进，探针直接把 `AdvancedColumn` 宽、面板可见性与选中态摆好，再 `ApplyLanguage()` 套当前语言后渲染整窗，输出 `advshot=ok panel=<实际宽>`，用于像素级检查裁字。

## 2026-11-23 V1.2.304

**Bug｜高级搜索结果折叠时看不到展开三角**
- 现象：搜索 PDF 面板列出「Page 1 (3 matches)」等结果页，每行前面没有三角，也没有片段，看不出这行还能展开。
- 原因：命中片段懒生成，`OnAdvPageExpanded` 只在展开时才 `node.Items.Add(...)`，所以折叠页 `HasItems == false`；`MainWindow.xaml` 的 `TreeViewItem` 模板里 `<Trigger Property="ItemsControl.HasItems" Value="False">` 把 `Expander` 设为 `Hidden`，懒加载页被误判成叶子节点。
- 改法：新增 `Controls/TreeLazy.cs`（附加属性 `HasHiddenChildren`）；模板中的该触发器改为 `MultiTrigger`——`HasItems=False` **且** `HasHiddenChildren=False` 才隐藏三角；`RunAdvSearch` 建页节点时调用 `TreeLazy.SetHasHiddenChildren(pageNode, hits.Count > 0)`。真正的叶子节点（书签 / 注释 / 命中片段）属性默认 false，行为不变。
- 验证：`--treeshot`（借用 `RootLayout.Resources` 的隐式样式渲染三种节点）输出「叶子无三角 / 懒加载折叠 ▶ / 已展开 ▼」。

**改进｜高级搜索结果默认展开全部页**
- 需求：默认展开所有搜索结果，不用逐页点开。
- 改法：删除 `AdvAutoExpandHits=120` / `AdvAutoExpandPages=4` 两个阈值；搜索完成后把页节点排成队列，在 `DispatcherPriority.Background` 里逐页 `IsExpanded = true`（`ExpandNext` 自链，每页一次让出 UI 线程），并用 `seq == _advSearchSeq && doc == _doc` 防止换文档 / 新搜索后继续展开旧结果。
- 验证：逻辑与既有懒加载配合（`OnAdvPageExpanded` 防重入标记不变）；构建 0 警告。

## 2026-11-23 V1.2.303

**Bug｜搜索历史下拉与搜索工具栏重叠**
- 现象：点搜索栏左侧历史按钮后，下拉弹层压在设计工具栏的底边与投影上（截图里弹层顶边明显插进搜索栏内部）。
- 原因：`SearchHistPopup` 的 `PlacementTarget` 是 26px 高的 `SearchHistBtn`，`Placement=Bottom` 于是弹层顶边 = 按钮底边 = 搜索栏内部 30px 处（栏高约 36px），再加 `Border` 的 4px 外边距，视觉上只剩 2px 重叠带。
- 改法：`MainWindow.xaml` 第 1442 行改为 `PlacementTarget="{Binding ElementName=SearchBar}"`、`Placement="Bottom"`、`VerticalOffset="4"`，弹层顶边固定在栏底 +4px，横向也随栏左对齐；去掉 Popup 上无效的 `Margin`。
- 验证：几何上弹层顶边 = 搜索栏底边 + 4，不再可能压住工具栏；实机确认弹层随栏移动、点历史项仍会填词并关闭。

**Bug｜AI 设置里的 API Key 以明文存盘**
- 现象：`prefs.json` 里 `ApiKey` / `AiApiKey` 是明文，配置文件被拷走即泄露。
- 改法：新增 `LLM/SecretCipher.cs`（DPAPI CurrentUser + `dpapi:` 前缀）；`AppPrefs.Save()` 序列化前把每条预设与全局镜像的 Key 换成密文、写完在 `finally` 里还原内存明文（`LlmClient` 仍然只读明文标量）；`Load()` 反序列化后统一 `Unprotect`，旧明文无前缀原样通过、下次保存自动加密；解密失败（换机 / 换用户）返回空串，界面按「未填 Key」提示重填。
- 验证：实机 `prefs.json` 已落地为 `dpapi:…` 密文，重启后 `--aishot` 渲染的密钥圆点数量不变，说明解密链路正常。

**缺陷｜AI 设置窗口内容超出 780×560 客户区**
- 现象：英文界面下「测试连接」状态多占一行，生成参数卡底部提示被视口裁掉，右侧出现滚动条。
- 改法：输入框 34 → 32、卡片内边距 14,12 → 14,10、标签下边距 4 → 3、卡片间距 10 → 8；「设为工作模型」英文标签收成「Set working」以免撑破 264px 左栏的两列按钮。
- 验证：`--aishot` 报 `contentWanted=764x520.1 / 客户区 521`，两张卡片与底部说明条全部完整显示，滚动条消失。

## 2026-11-22 V1.2.301

**调整｜划词/取词「T」徽章改用 Geo.Translate 图标**
- 需求：把译文卡徽章从字母「T」换成图标（采用现成 `Geo.Translate`，`App.xaml:90`）。
- 改法：`WrapBadge`（`Controls/PdfPageView.cs:2292`）增加图标分支——`label.StartsWith("Geo.")` 时渲染 `System.Windows.Shapes.Path`（`Data=FindResource(label)`、`Stroke` 取 `accentKey` 随主题、18×18、不套方框），否则保留字母+方框；调用处 `2217`/`2935` 的 `"T"` → `"Geo.Translate"`。注释卡 `"A"`（`2101`）保留字母。
- 验证：未编译；实机确认图标显示、垂直对齐、深浅色描边色。

## 2026-11-22 V1.2.300

**调整｜划词/取词译文颜色恢复为正文色 Th.Text**
- 需求：译文/释义当前用 `Th.TransAccent`（深色绿 #3FB950、浅色蓝 #1A5FB4）强调，用户要求恢复为与标题/按钮一致的正文色。
- 改法：`Controls/PdfPageView.cs` 划词卡 `body`(2855)、取词卡释义 `textBlock3`(2170) 的 `SetResourceReference(Foreground, "Th.TransAccent")` → `"Th.Text"`。"T" 徽章（`WrapBadge(...,"Th.TransAccent")`，2217/2911）保留强调色（非译文）。
- 验证：未编译；实机确认深/浅色下译文与标题、按钮同色。

## 2026-11-22 V1.2.299

**移除｜去掉工具栏「区域选择」开关及 RectSelectMode 功能**
- 需求：去掉 1.2.297/298 的「区域选择模式」工具栏图标与功能。
- 移除：`MainWindow.xaml` 的 `ToolRectSelect` 按钮、`MainWindow.xaml.cs` 的 `OnRectSelectModeChanged`、`Controls/PdfPageView.cs` 静态 `RectSelectMode` 字段、`OnMouseDown` 条件回退为仅 `Alt`、`Localization/UiText.cs` 英文 ToolTip 词条。
- 保留：Alt+拖 矩形框选内核（`_selRectMode`/`GetRectSelection`）未删；grep 确认 `RectSelectMode`/`ToolRectSelect`/`OnRectSelectModeChanged` 零残留。
- 验证：未编译；需确认无残留引用导致编译错误。若要连 Alt 框选内核一起删，另行处理。

## 2026-11-22 V1.2.298

**本地化｜补「区域选择模式」按钮英文 ToolTip**
- 根因：1.2.297 的 `ToolRectSelect` ToolTip 仅中文，`UiText` 词典无对应条目，英文界面会残留中文。
- 改法：`Localization/UiText.cs` 加 `["区域选择模式：开启后在页面上拖拽即矩形框选…"] = "Area-select mode: when on, dragging…"`（中文键与 XAML 逐字一致）。
- 验证：未编译；切英文界面确认该按钮 ToolTip 为英文。

## 2026-11-22 V1.2.297

**修复｜矩形框选改用工具栏「区域选择模式」开关（Alt 与菜单访问键冲突）**
- 根因：矩形框选（1.2.283/1.2.286）用 `Keyboard.Modifiers & ModifierKeys.Alt` 触发（`Controls/PdfPageView.cs:1378`），但主窗口菜单栏用 Alt 访问键（`文件(F)` 等），按 Alt 进入菜单模式，拖拽的 MouseDown 收不到正常 Alt 修饰/被菜单拦截 → 框选无法启动（用户实测"按 Alt 根本选不了"）。
- 改法：新增全局静态 `PdfPageView.RectSelectMode`（`Controls/PdfPageView.cs:79` 后），`OnMouseDown` 条件改为 `if (RectSelectMode || (Keyboard.Modifiers & ModifierKeys.Alt) != 0)`；工具栏加独立开关 `ToolRectSelect`（`MainWindow.xaml` 夜间模式后），`OnRectSelectModeChanged` 写 `PdfPageView.RectSelectMode = ToolRectSelect.IsChecked==true`（`MainWindow.xaml.cs`）。开启后拖拽即矩形框选，关闭恢复普通流式。
- 验证：未编译；需实机回归工具栏「区域选择」开关 → 拖拽框选表格整列/整块、关闭恢复普通选区。英文 ToolTip 待补词典。

## 2026-11-22 V1.2.296

**修复｜P1 起点/终点行选择性补齐上标碎片（间隙阈值区分上标 vs 表格列）**
- 根因：1.2.282 移除起点行补齐后，含上标的标题（`Vref` 的 `ref`）被 `BuildTextMap` 切成独立碎片，起点行只选到起点片段边界 → 上标碎片漏选（实测 TI-SN65HVD230 10.3.1 标题 `10.3.1 [Vref] Voltage Reference` 中间漏选）。
- 改法：`GetVisualSelection` 的 else 分支起点/终点行加 `ExtendTight`，沿阅读方向只补「水平间隙 < `TightGapFactor`(0.5)×字高」的紧邻碎片（同词上标碎片间隙≈0 补回），表格列间隙（5–15pt）超阈值即停 → 不串格。`Pdf/PdfDocument.cs:2391` else 分支。
- 阈值需实机标定：偏大串表格列、偏小仍漏上标。
- 验证：未编译；需实机回归 `Vref`/`VCC/2` 标题上标不漏、表格选单列不串、正文跨行拖选正常。

## 2026-11-22 V1.2.295

**改进｜取词翻译引擎切换为 AI 大模型，与划词 / 全文翻译统一**
- 根因：`Controls/PdfPageView.cs:1913` 的悬停取词仍直接调 `YoudaoDictionary.LookupAsync`，而 `Translation/WordLookup.cs` 早已实现完整的 AI 取词封装（缓存、在途去重、流式首行、`LookupResult` 解析）却没接进主链路；`WordLookup.TryGetCached` 成为死分支，首选项里改 AI 配置也不会影响取词。
- 改法：`RequestWordLookup` 改调 `WordLookup.LookupStreamAsync(word, onPartial, ct)`；`onPartial` 用 `ParsePartial` 提前亮卡并 `Dispatcher.Invoke` 回 UI，最终再用完整结果覆盖。网络检查只对云端端点生效，本地 Ollama / LM Studio 等 `LlmClient.IsLocalEndpoint` 不受断网误拦；未配置 / 失败由 `WordLookup` 生成 `Transient` 结果在卡片内提示，不弹打断悬停的 MessageBox。`Controls/PdfPageView.cs:1900-1952`。
- 配套：主菜单 / 划词卡 / 全文翻译页关闭 AI 设置后统一 `WordLookup.ClearCache()`，避免换模型后旧词仍显示旧模型译文；`AppPrefs` 注释同步为 AI 引擎。
- 验证：`dotnet build -c Release` 0 警告 0 错误；全源码仅剩 `MainWindow` 的 `dictprobe` 调试钩子调用有道，取词主链路已无 `YoudaoDictionary.LookupAsync`。待实机回归——配置 AI 后悬停英文词显示来源「AI 智能翻译」、音标/释义/例句，未配置时卡片内提示，本地端点断网可用。

## 2026-11-22 V1.2.294

**修复｜P1 表格行内对角拖选误吸附到相邻行，整行选不中**
- 根因：`GetVisualSelection` 的终点片段按最近距离吸附，`dy` 权重 4；从表格某行右下角拖到该行左上角时，终点落在行上边框附近，表头文字比本行文字更近 → `iF` 被判到上一行，走跨行分支后只选到「起点行末格 + 表头首格」。另外行边框处起手时 `GetCaretBoundary` 严格命中失败，就算 `GetCharIndexNear` 宽松命中也不启用拖拽（`_dragging = boundary >= 0`）。
- 改法：`AssignFragmentRows` 输出每行垂直范围；新增 `IsInRowTerritory`，起终点都在起点行的势力范围（与相邻行文字带的中线）内时，`FindFragmentInRange`/`FindFragmentAt` 只允许吸附到同一行 → 落回 `sameRow` 几何分支，按水平范围选中整行所有单元格。`OnMouseLeftDown` 改为宽松命中也可起手视觉拖选。`Pdf/PdfDocument.cs:2326`、`Controls/PdfPageView.cs:1444`。
- 附带：修复 V1.2.292/293 遗留的编译错误——`SecretCipher` 缺 `System.Security` 引用、`FreeModelPickerDialog` 误用 `SignupUrl`（字段实为 `ApplyUrl`）、`AiSettingsPanel`（`UserControl`）把 `this` 传给 `Msg.Show(Window?)` 改传 `Window.GetWindow(this)`。
- 验证：`dotnet build -c Release` 0 警告 0 错误；临时探针用合成表格 PDF 验证——行右下→左上选中整行 5 格、跨行拖选仍可选表头+中间行+末行。仍待实机 UI 回归——真实 datasheet 表格、正文对角拖选、行边框起手可拖。

## 2026-11-22 V1.2.293

**修复｜P1 Shift+单击扩选走视觉走廊，避免表格/双栏跨格串选**
- 根因：Shift 扩选分支（`Controls/PdfPageView.cs:1395`）用字符索引区间 `[lo,hi)`、`UpdateSelectionRects` 走 `GetSelectionRects`（按索引）；表格一行是多个独立文本对象、相邻格字符索引连续 → 一条选区横跨多格、复制带出邻格（与拖选 1.2.276 同痛点的另一分支）。
- 改法：起点矩形 `_caretRectPage`（页面坐标，`3780` 的 `PageRectToScreen` 反证）有效时，改调 `GetVisualSelection(PageIndex, sx, sy, val.X, val.Y, _caretAnchor)` 视觉走廊选区，起点 sx/sy 取旧 `_caretRectPage`（覆盖前）、终点取本次 `val`；不可用时退回原字符区间（fall-through 不回归）。`Controls/PdfPageView.cs:1395-1440`。
- 验证：未编译；需实机回归正文 / 表格 / 双栏 shift 扩选、双击选词后 shift 扩展、从词中间 shift 扩半词。

## 2026-11-22 V1.2.292

**优化｜A2 表单命中合并为一次整页扫描**
- 根因：`FindFormWidgetAt`（`Pdf/PdfDocument.cs:853`）每次 O(annotCount) 全页扫描；`GetFormWidgetRectAt`/`GetFormFieldValueAt`/`IsFormTextFieldAt` 各自内部再调一次。`OnMouseDown`（`Controls/PdfPageView.cs:1143`）一次点击扫 4 次、`MouseMove` hover（`1576`）每次移动扫 2 次，全程持 `_lock` → 表单密集页卡顿并阻塞后台渲染。
- 改法：新增 `GetFormHitAt(page,x,y)`（`Pdf/PdfDocument.cs:888`）一次扫描返回 `FormHit(Rect?, Value, IsText)`，内部 `CloseAnnot` 一次；rect/value/isText 读法与原三方法逐字一致（tuple 的 X/Y/W/H = Rect 的 X/Y/Width/Height）。`OnMouseDown`/`MouseMove` 各改 1 次调用；键盘/签名等单点调用未动。
- 验证：未编译；需实机回归表单点击 / 悬停 / 编辑 / 下拉 / 复选行为不变、大表单页不卡。

## 2026-11-22 V1.2.291

**修复｜P2 渲染健壮性：取色缩放系数 / 写像素失败重试 / 覆盖层异常日志**
- A5：`SampleAnnotColorFromBitmap`（`Controls/PdfPageView.cs:3214`）用 `_renderedScale`（请求缩放）映射页面 pt→位图像素；渲染超 MaxPagePixels/maxDim 时等比降采样，真实像素/pt < `_renderedScale`，采样区被 `Math.Min(PixelWidth-1)` 钳到边缘 → 高缩放/超宽表格取色错位。改用 `bitmap.PixelWidth / _pageW`（`_pageW` 为未旋转页面 pt 宽，`469`）；等比降采样 x/y 同系数，未降采样时该值即等于 `_renderedScale`。`Controls/PdfPageView.cs:3222`。
- A8：双缓冲 `WritePixels` 失败（`Controls/PdfPageView.cs:800`）原 `catch{ ReturnFrame; return; }` 丢弃帧不重试 → 页面停旧图；补 `ScheduleBlankRetry()` + 日志。覆盖层通用 `catch`（`853`）原静默吞非预期异常，补日志；`ObjectDisposedException`（`852`）经注释确认是页视图拆除时的有意静默，保留不改。
- 待办：A2（表单命中一次点击重复全扫 4 次、全程持锁）需新增"一次命中返回 rect/value/isText"的 API 并复用 widget 句柄、调整 `CloseAnnot` 时机，属表单交互链路改动，风险高于本批，留待编译验证后单独做。
- 验证：未编译；需实机回归高缩放/超宽表格取色、渲染异常自愈、覆盖层日志。

## 2026-11-22 V1.2.290

**修复｜P2 页视图 Unload 未解绑 AI 划词卡 Window 事件 → 泄漏 / 回调进已回收视图**
- 根因：AI 卡在 `ShowAiTranslateCard` 绑 `owner.PreviewMouseDown += _aiTransOutsideDown` / `owner.Deactivated += _aiTransDeactivated`（`Controls/PdfPageView.cs:2970-2971`），解绑只在 `ForceCloseAiTranslateCard`（`3104-3105`）；`CloseAiTranslatePopup` 走动画、解绑在回调里。页视图虚拟化回收走 `Unloaded`（`524`），原只 `StopFormCaretTimer`+解绑表单事件，未关卡；`ClosePopup`（会关卡）只在切标签/关文档调用（`2387/2736/8087/8093/8844`），回收路径不经过 → owner 事件残留、lambda 捕获 this 使页视图无法 GC。
- 改法：`Unloaded` 加 `_aiTransCts?.Cancel(); _aiTransCts = null; ForceCloseAiTranslateCard();`（立即解绑，不依赖动画）。`Controls/PdfPageView.cs:524`。
- 验证：未编译；需实机回归划词卡开着时滚动 / 关标签不崩、卡正确关闭、无泄漏。

## 2026-11-22 V1.2.289

**修复｜P1 UpdateShapeStyle 先关页再关标注 UAF 顺序**
- 根因：`UpdateShapeStyle`（`Pdf/PdfDocument.cs:4816`）原 `try{ …ReleasePage(pageIndex)… } finally{ CloseAnnot(annot) }`，ReleasePage 先执行；`ReleasePage`（`Pdf/PdfDocument.cs:492`）在页未被 `_pinnedPages` 持有时会 `FPDF_ClosePage` 销毁页及标注，随后 finally `FPDFPage_CloseAnnot(annot)` 操作已失效 annot → UAF。
- 改法：`ReleasePage` 移到 `finally { CloseAnnot }` 之后（`Pdf/PdfDocument.cs:4938`），与 MoveShape / UpdateTextMarkupStyle 一致。
- 验证：未编译；需实机回归改形状 / 箭头样式不崩、样式正确、可撤销。

## 2026-11-22 V1.2.288

**修复｜P1 UpdateTextMarkupStyle / UpdateShapeStyle 先删后建丢原标注**
- 承接 1.2.287（MoveShape）。同模式两处：`UpdateTextMarkupStyle`（`Pdf/PdfDocument.cs:4609`，quads 版，throw）、`UpdateShapeStyle`（`Pdf/PdfDocument.cs:4816`，strokes 版，return）原「先 `RemoveAnnot` 删旧 → `CreateAnnot` 建新 → 失败丢标注」。
- 改法：均改为先 `CreateAnnot` 建新（失败 throw/return，旧保留）→ 配置新 → 成功后 `RemoveAnnot(page, annotIndex)` 删旧。删旧位置：`UpdateTextMarkupStyle` 在取 `newIndex` 前（`Pdf/PdfDocument.cs:4690`），`UpdateShapeStyle` 在 `ReleasePage` 前（`Pdf/PdfDocument.cs:4933`）。
- 待办（既有隐患，非本轮引入）：`UpdateShapeStyle` 的 `ReleasePage` 在 `finally { CloseAnnot(annot) }` 之前，疑似"先关页再关标注"UAF 顺序，需单独核验。
- 验证：未编译；需实机回归改文本标记 / 形状样式、箭头改头部、撤销正常。

## 2026-11-22 V1.2.287

**修复｜P1 MoveShape 先删后建，CreateAnnot 失败丢原标注**
- 根因：`MoveShape`（`Pdf/PdfDocument.cs:4728`）原「先 `RemoveAnnot` 删旧 → `CreateAnnot` 建新 → 失败 `return -1`」，建新失败时旧已删、新未建 → 形状标注丢失，`IsModified` 未置。
- 改法：先 `CreateAnnot` 建新（失败 `return -1`，旧保留）→ 配置新（SetRect/InkStrokes/Color/Contents/Author/MKey）→ 成功后 `RemoveAnnot(page, annotIndex)` 删旧 → `newIndex = GetAnnotCount-1`（建新在页尾不影响旧 annotIndex，删旧后新前移到末尾，索引成立）。`Pdf/PdfDocument.cs:4768`、`4799`。
- 待办：`UpdateMarkupStyle`（`Pdf/PdfDocument.cs:4642`）、`UpdateShapeStyle`（`Pdf/PdfDocument.cs:4898`）同「先删后建」模式未改。
- 验证：未编译；需实机回归移动形状 / 含笔画墨迹、撤销正常。

## 2026-11-22 V1.2.286

**改进｜矩形框选列/行吸附（按片段中心判定，解决选表格一列带入邻列）**
- 根因：`GetRectSelection`（`Pdf/PdfDocument.cs:2238`）原按逐字符中心 x/y 落在拖拽矩形内判定，手拖框边界压到邻列时会带入邻列字符（实测 SGM61231 PIN 表选 FUNCTION 列带入了 VIN 行）、且可选到半个单元格。
- 改法：改为遍历 `map.Fragments`，按「片段中心 cx/cy 落在 `[x0,x1]×[y0,y1]`」整段入选 / 不选；文本按片段逐行拼接。`Pdf/PdfDocument.cs:2238`。
- 验证：未编译；需实机回归 Alt+拖 选表格一列不带入邻列、整列干净、复制按行。

## 2026-11-22 V1.2.285

**修复｜GetText 大块 stackalloc 栈溢出风险**
- 根因：`GetText`（`Pdf/PdfDocument.cs:2807`）`int n = Math.Min(count, 65536); ushort* buf = stackalloc ushort[n + 1];` ≈128KB 栈；`GetPageText` 抽整页文字、在后台线程 / 递归文本遍历栈下可 StackOverflow（进程级崩溃，`catch` 接不住）。
- 改法：`n ≤ 8192` 用 `stackalloc`；更大用 `new ushort[n + 1]` + `fixed (ushort* p = hbuf)` 传指针；两路都传 `n`（缓冲容量）不写穿。`Pdf/PdfDocument.cs:2807`。
- 其余 `stackalloc`：`AddTextLine`（`Pdf/PdfDocument.cs:2944`）上限 4096（约 8KB）安全，未改。
- 验证：未编译；需实机回归——密集长页全文抽取 / 搜索 / AI 分析不崩、文本一致。

## 2026-11-22 V1.2.284

**修复｜P0 删除水印/页眉页脚跨阶段复用过期 pdfium 对象指针 → UAF 崩溃 / 误删**
- 根因：`BandText.Obj/Parent`（`Pdf/PdfDocument.cs:5752-5753`）等扫描缓存存的是上次扫描时的 pdfium 原生对象指针/序号；`ScanBandPage/ScanWatermarkPage` 命中 `_bandScanCache/_wmScanCache` 旧缓存，而 `DropScanCaches()` 仅在删除成功后调，删除开始时不清。时序「识别预览 → 滚动(该页 ReleasePage 重载) → 删除」下，删除用悬空 `w.Obj/Parent` 调 `FPDFFormObj_RemoveObject/FPDFPage_RemoveObject` → UAF；`RemoveForeignWatermarks` 用旧 `TopIndex` → 指向重载后错误对象 → 误删。
- 改法：`RemoveForeignWatermarks`（`Pdf/PdfDocument.cs:5768`）与页眉页脚删除（`Pdf/PdfDocument.cs:6279`）在 `lock(_lock)` 后、页循环前先 `DropScanCaches()`，强制本次现场重扫，序号/指针与当前页句柄一致。
- 代价：删除时重扫一次（放弃复用预览缓存的省时优化），正确性优先；低频操作影响可忽略。
- 验证：未编译；需实机回归——预览后滚动再删除不崩溃、删除结果正确、倒序删仍生效。

## 2026-11-22 V1.2.283

**新增｜Alt+拖拽 矩形/区域选择（解决表格跨格框选）**
- 背景：表格对角跨多行多列拖选，流式选区算法结构性不适配二维区域——终点落空白格会吸附错乱、选区塌缩（实测 V1.2.282 在 SGM61231 订购表对角拖选只剩表头 MODEL 一格）。用户确认需要"矩形框选一片"。
- 实现：`Pdf/PdfDocument.cs:2238` 新增 `GetRectSelection(index, Point a, Point b)`——遍历 `GetTextMap` 字符 box，中心落在拖拽矩形内的收集，按 y 降序 / 行内 x 升序排序，垂直重叠 ≥50% 聚成视觉行、每行合并为一个 `Rect`，文本按行拼接。`Controls/PdfPageView.cs` 新增 `_selRectMode`，在 OnMouseDown（Alt 进入）/OnMouseMove（更新终点）/OnMouseUp（定稿）/UpdateSelectionRects（算选区，置于 `_selStart<0` 早返回之前）/ClearSelection（复位）五处串接；渲染 / 复制 / 批注复用 `_selRects`/`_selText`。
- 触发：按住 Alt 拖拽；正文普通拖选不变。
- 已知限制：复制文本同行多列间未插分隔符（可能粘连），高亮 / 框选正确。
- 验证：未编译；需实机回归 Alt+拖 框选表格、与流式选 / 双击 / shift 互不干扰、松 Alt 恢复。

## 2026-11-22 V1.2.282

**修复｜表格拖选串格（回退 1.2.280/1.2.281 的行内横向补齐）**
- 根因：为修正文上标行"选区空洞"，`GetVisualSelection` 跨行分支的起点/终点行加了 `ExtendRow` 水平补齐；其 `Adjacent` 判据用"水平间隙 < 阈值"区分正文碎片与表格列，但表格相邻列文字间隙（约 10pt）与正文词间隙同量级，分不开 → 表格列被一并补齐 → 选单列串到相邻列。`Pdf/PdfDocument.cs:2304`。
- 改法：删除 `Adjacent`/`ExtendRow`，起点/终点行回退为只选到 `iA`/`iF` 片段边界（`f.End` / `f.Start`），不做行内补齐；`sameRow` 几何化（按拖拽水平范围 `[xLo,xHi]` 选字符）保留。`Pdf/PdfDocument.cs:2304-2341`。
- 取舍：正文上标行跨行拖选可能仍有小洞（用户确认"表格不串格优先"）。
- 验证：未编译；需实机回归——表格选单列不串格、格内拖选只选该格、正文行内/跨行拖选、含上标 datasheet 正文。

## 2026-11-22 V1.2.281

**修复｜表格横选一整行选不中（同一行拖选，字符索引区间错配）**
- 根因：`GetVisualSelection` 的 `sameRow` 分支按字符索引区间 `[bLo,bHi)` 选字；表格一行是多个独立文本对象、pdfium 字符索引顺序未必等于视觉左右顺序，索引区间框空 → 一格都不高亮。`Pdf/PdfDocument.cs:2281`。
- 改法：`sameRow` 改为按拖拽水平范围选字符（字符中心 x ∈ `[xLo,xHi]`），不依赖索引顺序；删除 `bA/bF/bLo/bHi`。`Pdf/PdfDocument.cs:2281-2302`。
- 关联增强：`ExtendRow` 同视觉行判定从「Row 编号相同」改为「与起点片段垂直重叠 ≥70%」，覆盖含上标右碎片被归到别的 Row 的情况；删除随之不再使用的 `RowFragsSorted`。`Pdf/PdfDocument.cs:2296-2369`。
- 验证：未编译；需实机回归——表格横选整行、单元格内拖选不串格、正文行内拖选、跨行拖选、含上标 datasheet 正文。

## 2026-11-22 V1.2.280

> 本轮为源码审查 + 用户实测反馈驱动的修复。本环境无法编译/运行，以下均**未经编译与实机验证**，需 `MSBuild.exe /t:Restore;Build` 复验。

**修复｜P0 导出页面与后台渲染并发访问 pdfium 文档句柄 → 原生崩溃**
- 根因：`PdfDocument.ExportPagesToPdf` 调 `FPDF_ImportPages(dest, _doc,…)` 不在 `lock(_lock)` 内，渲染线程同时读 `_doc`（同文件 166-168 自述 pdfium 公开 API 非线程安全）。
- 改法：导入这一行包进 `lock(_lock)`；`StampExportPageNumbers` 只操作新建 `dest`，不入锁。`Pdf/PdfDocument.cs:1360`。
- 验证：未编译；需实机"打开大手册滚动时导出页"复测。

**修复｜P1 去保护 / 导出页非原子写可损坏文件**
- 根因：`RemoveProtection`/`ExportPagesToPdf` 用 `FileMode.Create` 直写目标；目标=源文件或写一半失败即截断损坏。
- 改法：新增 `SaveDocAtomically`（写 `path+".$$pdf$$"` 临时 → `ReplaceWithRetry` 原子替换，失败/取消删临时、原文件不动），与正常 `Save` 口径统一。`Pdf/PdfDocument.cs:1539-1565`。
- 验证：未编译；需实机"去保护时选同名源文件 / 磁盘满"复测。

**修复｜P1 OCR 成品"先覆盖后保存"丢数据**
- 根因：`OutputOcrLayerPdfAsync` 先 `File.Copy(overwrite)` 把旧 `_ocr` 成品覆成无文字层裸副本，随后取消/异常不 Save、不回滚。
- 改法：全程在临时副本 `target+".$$pdf$$"` 上 Load/写层/Save，成功后 `PdfDocument.PublishTempFileAtomically` 覆盖旧成品；`finally` 未发布时删临时。`MainWindow.xaml.cs:6932-6963`。

**修复｜P1 OCR 引擎构造失败泄漏推理会话**
- 根因：`PaddleOcrEngine` 构造中 `_det` 建好后若 `_rec`/字典/`_cls` 抛异常，调用方拿不到对象、永不 Dispose，已建会话原生资源泄漏。
- 改法：构造体包 try/catch，失败路径 `Dispose` 已建会话后再 throw。`Ocr/PaddleOcrEngine.cs:58-97`。

**修复｜P1 拖选跨行起点/终点行选区空洞**
- 根因：`GetVisualSelection` 起点行只把"起点片段"选到其右边界；被上标/特殊对象切碎的右侧碎片此前靠拖拽带 x 约束，终点落在更短行时漏选，同一行出现选区空洞（实测 TI `SN65HVD230` 页 `available`/`as a VCC/2…This pin` 处）。
- 改法：起止行改为 `ExtendRow`——按"与起点片段垂直重叠 ≥70%（同视觉行，不依赖 `AssignFragmentRows` 的 Row 编号）+ 水平紧邻（间隙 < 正文阈值）"补齐到行末/行首，遇大间隙（表格列）即停，保持表格不串格；并补全起点/终点片段自身两端边界。删除不再使用的 `RowFragsSorted/SelectInBand/FragIntersectsBand` 与 `by0/by1`。`Pdf/PdfDocument.cs:2296-2369`。
- 验证：未编译；需重点实机回归——`available` 不再被切开、表格窄单元格不串格、双栏不跨栏、向上拖/shift 扩选正常。

**修复｜P1 阅读统计计时器关窗未停**
- 根因：`_statsTimer.Start()` 后 `Closed` 只 `Save`，从不 `Stop`，退出竞态会继续 Tick 访问已释放文档。
- 改法：`Closed` 内补 `_statsTimer.Stop()`。`MainWindow.xaml.cs:402`。

**优化｜P2 健壮性**
- `IsEncrypted`/`Permissions` 补 `_doc==0` 判空，避免关标签竞态传空句柄（`Pdf/PdfDocument.cs:1536-1542`）。
- `AnnotationHistory.Trim` 硬编码 `31` → `MaxSteps+1`，消除常量与逻辑漂移（`AnnotationHistory.cs:113`）。
- 首选项 `ApplySettings` 速度档 `First(...)` → `FirstOrDefault(...)`，无勾选时保留原值，不再抛异常中断落盘（`PreferencesDialog.xaml.cs:860`）。

> 留待专门处理（本版本未改）：水印/页眉页脚"识别→删除"跨阶段缓存 pdfium 原生对象指针的 UAF（需删除链路重构 + 实机回归）、`/Rotate` 离屏坐标（打印/OCR/水印/页眉页脚四类路径）、书签增量 `/ID` 回写、`GetText` 大块 `stackalloc`、`AnnotationHistory` 大文档撤销深度塌缩。

## 2026-11-21 V1.2.279

**修复｜对数字版 PDF 跑 OCR 会在原文字层上再叠一层，复制与搜索出现重复内容**

- 现象：对自带文字层的 PDF（数据手册、说明书）做 OCR 后，选中文字会得到两份重叠文本，搜索结果重复。实测一页原文 2640 字符，成品取文本 5104 字符。
- 根因：OCR 全流程不判断页面是否已有文字层，一律渲染成位图识别后追加不可见文字层。
- 改法：新增 `Ocr\TextLayerGate`（判定阈值 50 字符，取不到字符数时视为无文字层），识别前过滤页面；对话框加「跳过已有文字层的页面」开关（默认开）；全部跳过时不加载模型、直接提示。「跳过」判定同时接进 `--ocrpdf` 诊断（`XC_OCR_SKIP_TEXT=0` 可关）。
- 验证：混合文档（第 1 页图片 + 第 2 页数字版）实测 p1 识别 74 行、p2 跳过（890 字符）；纯数字版单页输出文件从 6996 KB 降到 1532 KB（不再嵌入整页渲染图与多余文字层）。

**优化｜识别分批按行宽分桶，减少补零造成的无效推理**

- 原分批按检测顺序每 8 行一批，画布宽度取批内最长行，短行右侧补零到该宽度；推理量正比于「批内行数 × 批宽」，短行被白算。
- 改为按行宽升序分组（组内宽度差 ≤1.3 倍 + 8 px），单页 74 行推理面积 77%、密集表格页 66 行 53%；输出逐字比对相似度 0.9986，识别结果未受影响。
- 附带：进度文案加剩余秒数与跳过页数；字体下拉加宽到 230，长族名不再截断。
## 2026-11-20 V1.2.278

**改进｜可搜索 PDF 的文字层字体可选（中文 / 英文分开），缺字体时明确提示**

- 背景：OCR 只输出文字、认不出原文档字体；文字层是不可见文本，字体只影响字符度量与「能否复制/搜索到中文」。此前中文字体硬编码为 `C:\Windows\Fonts\simhei.ttf`，文件缺失时静默退到 Helvetica（仅拉丁）——中文复制与搜索会整段失效，且用户无从得知。
- 改法：新增 `Ocr\OcrFontCatalog`（扫描注册表与 Fonts 目录，列出有字体文件的项并标记是否含中文字形）；`PdfDocument` 增加 `OcrCjkFontPath` / `OcrLatinFontPath` 与按段选字体（含 CJK 的段用中文字体、纯拉丁段用英文字体），加载失败时逐级回退并记录 `OcrFontFallbackNote`；OCR 对话框新增两个下拉与橙字提示；选择存进 `prefs.json`。
- 验证：默认 SimHei + ArialMT、`msyh.ttc` → MicrosoftYaHei、`times.ttf` → TimesNewRomanPSMT 均按段生效；指定不存在的字体自动回退 SimHei 并触发提示；安装版 1.2.278 已升级并用安装版 exe 复测通过。
## 2026-11-20 V1.2.277

**修复｜整页倒置（180°）的扫描文本识别不出来（只出一个句号）**

- 现象：双面文档背面的透明内容（整页倒置）OCR 后整页只剩一个 `。`，正文全丢。
- 根因三处叠加：
  1. 方向分类阈值 `ClsFlipThreshold = 0.75`，实测倒置行输出 0.731、正向行 0.269，倒置行刚好被挡在阈值外。
  2. `FillCrop` 的 `flip` 只做上下镜像、不做左右镜像，翻出来是「字序不变、字形上下颠倒」的镜像字，不是 180° 旋转，识别器照样读不出。
  3. 倒置时字符上下沿之间没有贯通空白行，DB 把三行粘成一个 78px 高的框，整块按 48 高重采样后每行只剩十几像素。
- 修复：`flip` 改为真正的 180° 旋转（行自底向上、列自右向左）；阈值 0.75 → 0.7，并对判翻的块做反向识别取明显更高者（修掉「项目」p=0.61→「目虹」、「97.2%」p=0.69→「%726」这类短词误判）、识别为空/低置信的块反向兜底；新增 `SplitStackedLines` 用框内暗像素行投影把粘连多行切回单行（子框带 `Split` 标记阻止聚类回粘）。
- 验证：新增 `扫描测试_倒置文本_标准字号.pdf`（`Tools/make_upside_down_sample.py`）修复前 1 个 span → 修复后 3 个 span 全识别、坐标与原文对齐；用户小字截图样张 1 个句号 → 2 行可读；四列表格 37 span 全对、双栏窄栏距 15 span 与 1.2.276 一致，无回归。安装版 1.2.277 已升级并用安装版 exe 复测通过。
## 2026-11-20 V1.2.276

**修复｜表格里框选一个单元格，复制出来带着隔壁单元格的首字**

- 现象：四列网格表 OCR 成品，框选「输入电压范围」这一格，复制得到 `输入电压范围3`；框选「200k-1.2M」得到 `200k-1.2M/R`。
- 根因：检测框经 unclip 膨胀，比真实文字两头宽约半个字高；文字层为了贴合高亮，把文字水平拉伸到框宽，首字符因此越过格线落到邻格。pdfium 按字符框命中，邻格那个越界首字被一并选中。
- 修复：`PdfDocument.AddOcrTextLayer` 在写每个文本对象前，按字高把段两端各内收 `min(0.15 × 字高, 0.05 × 段宽)`，使文字落在格线内侧；内收后不足 0.8 字宽的短段不处理。
- 验证：贴线表格越界字符 17 → 6、窄格 21 → 11，按格框选全部只返回本格文字；双栏窄栏距样张仍是 `wide_cross=0`、`overlap=0`，无回归。安装版 1.2.276 已升级并用安装版 exe 复测同一页通过。
## 2026-11-20 V1.2.275

**修复｜双栏文档选中左栏会连带选中右栏（选区横贯两栏）**

- 现象：OCR 成品里左栏文字被选中时，选区横穿页面中线覆盖到右侧栏；复制得到「左栏半句 + 右栏半句」。
- 根因：检测阶段左右两栏被并成一个宽框 → 识别文本被拼接；行聚类把两栏当同一行 → 文字层写出一个横跨两栏的对象。
- 修复：引擎新增 `SplitWideBoxes`（双栏页判据用「右栏起点簇」，切点用「右栏起点左侧 5% 页宽内最靠右的空白列」），切开的框带 `Split` 标记阻止聚类回粘；换栏距离 1.2→0.8 字高；文字层 `splitGap` 1.0→0.6 倍字号。
- 验证：窄栏距竖线样张宽对象 2→0、左栏框选只返回左栏文字；4 页双栏样张第 2 页 `cross_mid` 4→0，同行水平重叠 0；单栏页 spans 未变化（未误切）。安装版 1.2.275 已升级并用同一页复测通过。
## 2026-11-20 V1.2.274

**改进｜OCR 完成后不再弹「打开位置」，直接打开成品；文件名统一为 `_ocr`**

- 原行为：识别结束弹一个模态框问「是否打开文件所在位置」，点「是」只调起资源管理器定位文件，用户还要再手动双击打开；成品名后缀还是大写的 `_OCR`，与界面预览要各写一遍。
- 改法：`OutputOcrLayerPdfAsync` 保存成功后直接 `await OpenFileCore(target)` 打开成品；后缀抽成 `OcrDialog.OutputSuffix = "_ocr"`，预览与落盘共用；目标文件已存在时仍保留覆盖确认。
- 验证：`--ocrpdf <in> auto` 走同一命名规则，实测生成 `扫描测试_中英双栏表格4页_ocr.pdf` 于原目录，5.71 MB，`get_text` 29 行可提取；安装版 1.2.274 已升级，`--ocrshot` 渲染尺寸与开发构建一致（684×585.7）。
## 2026-11-20 V1.2.273

**修复｜中文界面下 OCR 徽章的「OCR」被翻成「OCR识别」，撑破 54 px 图标框**

- 现象：识别对话框左上角图标块里，本该是 17 px 粗体「OCR」，实际渲染成「OCR识」并溢出到框图外，压住右侧标题。
- 根因：`UiText` 词典有一条 `["OCR识别"] = "OCR"`，反向表（英文→中文）会把任何等于 `OCR` 的文本回溯成 `OCR识别`。中文模式下 `T()` 也走反向表，于是品牌字被当成译文改写。
- 修复：`UiText` 新增 `Tag="no-i18n"` 约定，`Apply` / `TranslateElementMeta` 首行判断该标记即跳过；对话框徽章的「OCR」「v5」两个 TextBlock 打上标记。品牌词、型号这类不该翻译的文本都可复用该约定。
- 验证：`--ocrshot` 渲染中文浅色版，徽章恢复为「OCR / v5」，框图内不溢出、标题让出干净。

**改进｜OCR 输出模式收成唯一「可搜索 PDF」**

- 背景：三种输出（可编辑文本和图像 / 覆盖原文 / 可搜索图像）里，前两种都会改写页面本身，阅读端表现不稳定；用户实际只需要「扫描件识别成可选中、可复制、可搜索、可标记的 PDF」。
- 处理：对话框去掉两个单选与两段说明；`OcrJob` 去掉 `OutputMode`；`MainWindow` 删掉 `OutputOcrEditablePdfAsync` / `OutputOcrCoveredPdfAsync`；`PdfDocument` 删掉 `RebuildPageAsEditableText` / `RebuildPageAsCoveredText`；`UiText` 删掉对应词条。
- 验证：`--ocrpdf` 导出 1.6 s 识别 / 80 ms 写层 / 5846 KB，`get_text` 取回 29 行，与 1.2.272 一致；`--ocrshot` 中英双语版式均无溢出、无裁切。

**修复｜英文界面下「识别范围」把「Even pages」挤到第三行**

- 现象：英文文案比中文长，WrapPanel 在 656 px 可用宽度里放不下「All / Current / Custom + 输入框 + Odd / Even」，最后一个按钮单独掉到下一行，输入框留在上一行，看起来像排版塌了。
- 修复：改成两行固定布局——第一行三个单选 + 指定页输入框（190 px），第二行奇偶快捷按钮 + 分隔符说明 + 已选页数（说明文字允许换行）。
## 2026-11-20 V1.2.272

**修复｜「可搜索 PDF」导出后文字叠在扫描图上、无法阅读**

- 现象：把扫描件 OCR 成「可搜索 PDF」后打开，黑字密密麻麻压在原扫描图上，原文看不清；选中区域与实际文字也对不上。
- 根因：文字层是 FreeText 注释 + `FPDFAnnot_SetColor(type=0, alpha=0)`。pdfium 生成的注释外观里 alpha 并不生效（且注释本身不参与页面内容流），各阅读器按默认黑字绘制，于是覆盖在图像上。
- 修复（`Pdf/PdfDocument.AddOcrTextLayer` 重写）：
  - 不再创建注释，改为按行创建文本对象：`FPDFPageObj_CreateTextObj(doc, SimHei字体, size)` → `FPDFText_SetText` → `FPDFPageObj_SetFillColor(0,0,0,0)`（alpha 0 不可见）→ `FPDFPageObj_Transform(sx,0,0,1,x,baseY)`（水平缩放贴合框宽）→ `FPDFPage_InsertObject` → 每页 `FPDFPage_GenerateContent`。
  - 字体沿用 `EnsureOcrEditableFont()`（SimHei TTF 嵌入，中英文都能写，`FPDFText` 提取回来是正确 Unicode）。
  - 基线取 `行底边 + 0.8 倍字号的 0.15`，与「可编辑」模式一致。
- 验证：`--ocrpdf` 导出后 PyMuPDF `get_text` 完整取回识别文本；渲染页面与原始扫描件逐像素一致、无文字叠加；ExtGState 为 `/ca 0`；文件 0.94 MB → 5.8 MB（字体嵌入）。
- 影响：仅「可搜索」输出模式；「可编辑文本」「覆盖原文」两种模式未改。
## 2026-11-20 V1.2.271

**修复｜换 PP-OCRv5 后 OCR 引擎创建失败：模型 IR version 10 超出运行时上限**

- 现象：探针 `engine: create failed`，日志 `Unsupported model IR version: 10, max supported IR version: 9`，对话框里表现为「OCR 组件加载失败」。
- 根因：PP-OCRv5 的 ONNX 模型用 IR version 10 导出，工程引用的 onnxruntime 1.16.3 只支持到 IR 9。
- 修复：`Microsoft.ML.OnnxRuntime` 升级到 1.20.1（支持 IR 10），并执行 `/t:Restore`（`/t:Rebuild` 不会重新还原 NuGet 包，改完 csproj 必须显式还原）。
- 验证：探针 exit=0；300 dpi 首页 73 块，平衡档 1.4 s、精度优先 2.4 s；识别文本抽查「100W」「applications」「via the」「Efile」等此前错字已正确。

**修复｜双栏页面左右两栏被拼成一句话**

- 现象：特性列表页识别出 `The MP4247 is a buck-boost converter with two●UL and IEC62368-1 Certified, Efile #322138` 这类「左栏半句 + 右栏半句」。
- 修复：行聚类时同一行内水平间隙大于 1.2 个字高即判定换栏，断开为新行；同一栏内间隙小于 0.3 个字高的碎块仍合并。
- 验证：同页左右栏分行的 40 余行文本逐行独立，纯文本顺序可读。
## 2026-11-20 V1.2.270

**改进｜安装版与绿色版并存时，.pdf 关联指向随「最后启动的副本」漂移**

- 现象：关联目标 exe 会变化。曾出现注册表被改成 `bin\Release\net481\XC PDF Reader.exe`（开发构建目录），Clean/Rebuild 期间该 exe 被替换或删除，双击 PDF 即打不开；而装了安装版时又可能被绿色版抢回绿色目录。
- 根因：`FileAssociation.Register()` 用 `Env.ProcessPath`（当前进程）写 `shell\open\command`；`RefreshIcon()` 与 `IsRegistered()` 也基于当前进程的目录/路径判断。于是"谁最后启动，关联就归谁"。
- 修复：
  - 新增 `PreferredExe`：优先卸载项 `InstallLocation` 指向的安装版 exe，其次 `%LOCALAPPDATA%\Programs\XC PDF Reader\XC PDF Reader.exe`，都没有才用当前 exe。
  - `PreferredIconPath` 取所选 exe 同目录的 `filetype.ico`（缺失时回落本目录图标）。
  - `Register` / `RefreshIcon` / `IsRegistered` 全部改用首选 exe 与首选图标。
- 验证：安装 1.2.270 安装版后，从绿色目录启动实例 → 日志 `启动关联检查 registered=True default=True`，注册表 `shell\open\command` 仍指向安装目录；卸载安装版后启动绿色版 → 关联回落绿色目录。

## 2026-11-20 V1.2.269

**修复｜已有实例时双击另一个 .pdf 误报「进程残留」，应作为新标签打开**

- 现象：开着一份文档，从另一个文件夹双击第二份 .pdf，弹出「XC PDF Reader 已在运行，但无法与之通信（通常是上次异常退出后进程残留，仍占用着启动锁）」，文档没打开。
- 定位（`%TEMP%\xc-pdfreader-boot.log` 时间线）：14:06:29 实例 A 启动并打开 SGM61610.pdf；14:06:33 第二个进程 `检测到已有实例，准备转发参数` → 2.04 秒后 `已有实例但无法转发`（50 次重试全败）；14:06:42 再次启动却成功成为首实例；14:06:51 又一次转发 30ms 成功。同一版本、同一代码，只有「A 刚启动那几秒」失败。
- 根因：
  1. `StartPipeServer(win)` 在 `win.Show()` 之后调用，内部用 `Task.Run`（线程池）。首帧渲染、缩略图 105×136px 批量生成、水印识别（22 页 4229 文本叶子）在启动后几秒占满线程池，管道 server 排队未创建 → 客户端连接全败。
  2. 客户端 `for` 循环复用同一个 `NamedPipeClientStream`，`Connect` 超时后对象不可再用，后续尝试立即抛异常（2.04s ≈ 50×40ms 退避，说明根本没有等满 100ms 超时）。
  3. 失败后无接管路径，只能提示用户杀进程。
- 修复（`App.xaml.cs`）：
  - 新增 `_pipeWindow` / `_pipeBacklog` / `PipeGate`；`StartPipeServer()` 无参、在 `new MainWindow` **之前**以独立 `Thread`（`PdfReader-PipeServer`）启动；窗口 `Show()` 后 `AttachPipeTarget(win)` 补开暂存请求。
  - `ForwardToRunningInstance` 每次尝试新建 client，30 次 ×（120ms 连接 + 80ms 退避），首次失败记录异常类型。
  - 转发失败后 `_mutex.WaitOne(3000)` 接管启动锁（`AbandonedMutexException` 视为成功接管），接管则继续作为首实例启动；仅当锁被不响应进程持有时才弹原提示。
  - 管道读取 3 秒超时 + 等待连接失败 50ms 退避。
- 验证：`Rebuild` Release exit=0；隔离实例实测（`.t1`）阶段 1 转发 30ms 成功并开出第二个标签，阶段 2 强杀首实例后 0.5s 重启直接正常启动、无提示。

## 2026-11-20 V1.2.268

**改进｜去保护副本默认文件名后缀 `_已解除保护` → `_rp`**

- 现象：去保护后另存的副本文件名带一长串中文后缀「_已解除保护」，英文模式下同样出现中文，且文件名偏长不便检索。
- 修复：后缀统一改为 `_rp`，两处生成点同步——`UnprotectTabToCopy` 里的 `GetFileNameWithoutExtension(src) + "_rp"`，以及「文件去保护」另存对话框的 `... + "_rp.pdf"`。
- 保留原有防覆盖行为：同目录同名时依次尝试 `(2)`、`(3)`…，最多到 99。
- 验证：全工程 grep 后「已解除保护」仅剩一条已更新的注释；Rebuild Release exit=0；exe 二进制 UTF-16 比对「已解除保护」=False、「_rp.pdf」=True、「已去除保护并另存」=True。

## 2026-11-19 V1.2.267

**修复｜所有标注的悬停动态环绕框与标注编辑功能全部失效**

- 现象：鼠标移到任意标注（高亮、下划线、方框、线、图章、自由文本）上都不再出现虚线环绕框与提示卡，双击标注也打不开编辑卡片。
- 根因：`PdfDocument.FindFormWidgetAt(pageIndex, pageX, pageY)` 遍历页面 annotation 时**只比较矩形、没有按 `/Subtype` 过滤**。页面上任何标注都有矩形，于是都被当成表单控件命中；而 `PdfPageView.OnMouseMove` 的 `Tool == Select` 分支和左键按下分支都是「表单优先」——一旦 `GetFormWidgetRectAt` 命中就设置光标并 `return`，后面的 `GetAnnotAt`、`ShowHoverBox`、`UpdateMarkupTooltip`、双击编辑全部被跳过。只要文档里存在任何 AcroForm 字段（`HasForm == true`），全文档所有标注都会失效。
- 修复：`FindFormWidgetAt` 改为只接受 `Pdfium.FPDFAnnot_GetSubtype(a) == Pdfium.FPDF_ANNOT_WIDGET`，其余标注立即 `FPDFPage_CloseAnnot` 关闭并继续下一个。
- 佐证（直接解析 PDF 对象，未依赖截图）：`印刷表单_表单识别测试.pdf` 含 10 个 `/Subtype /FreeText`、0 个 Widget（「自动识别可填写区域」生成的就是 FreeText 标注），修复前这些块全被表单优先分支吞掉；`表单填写测试.pdf` 为 175 个 Widget，修复后表单点选/输入链路不受影响。
- 验证：Rebuild Release 0 error 0 warning；隔离实例（`XC_PDF_INSTANCE_SUFFIX=.smoke2`）启动日志 `MainWindow 构造完成 → Show() 已调用`，窗口 `XC PDF Reader`。

**修复｜徽章与首行文字未垂直居中（偏低约 2.9px）**

- 现象：注释悬停卡里橙色 `A` 徽章比首行文字偏低（截图红线框出）。
- 根因：`WrapBadge` 里徽章固定 `Margin.Top = 0.5`。12 号字 `TextBlock` 实测行高 15.24px，20px 徽章的中心落在 10.5，而文字行中心是 7.62，差 2.9px。
- 修复：先对内容首行 `TextBlock` 做 `Measure(new Size(PositiveInfinity, PositiveInfinity))` 取真实行高，再令 `Margin.Top = (行高 − 20) / 2`：12 号字号 → −2.38（中心 7.62 与行中心重合）、14 号字号 → −1.11（中心 8.89 与行中心重合）。
- 影响面：注释悬停卡 `A` 徽章、取词卡 `T` 徽章、AI 划词翻译卡 `T` 徽章三处一次性对齐。

**修复｜「删除页眉/页脚」子菜单拆错了维度**

- 现象：上一版把删除拆成「删除本软件添加的页眉/页脚」与「识别并删除文档自带的页眉/页脚」，是按**来源**拆；实际需求是按**位置**拆成「删除页眉」「删除页脚」。
- 修复：菜单改为「添加页眉/页脚…」「删除页眉」「删除页脚」。删除页眉只处理页面上半、删除页脚只处理下半；每个操作内部先删本软件写入的 stamp（按注释矩形中心与页高比值判半区），再识别并删除文档自带的同类内容（确认后执行）。
- 底层：`BandHit` 增 `Top`；`RemoveHeaderFooters(bool top)`、`RemoveMarkedOf(page, key, bool top)` 新增；`RemoveForeignHeaderFooters(..., bool? topBand)` 在删除阶段按 `CY / 页高` 过滤，页码按所在半区归类。
- 验证：`Build` Release exit=0；旧方法 `OnRemoveOwnHeaderFooter` / `OnRemoveForeignHeaderFooter` 全工程零引用残留。

**工程｜移除 .NET 8 工程、目录更名、版本号升到 1.2.267**

- 只保留 `XC_PDFReader_Net481`（原 `Net481`）一个工程树，.NET 8 源码已备份为 `D:\SW with codebuddy\XC_PDFReader_Net8_backup_20261119.zip`。
- 版本号 1.2.266 → 1.2.267（`AssemblyVersion` / `AssemblyFileVersion` / `AssemblyInformationalVersion` 与 csproj 同名属性同步）。

## 2026-11-18 V1.2.251

**改进｜关于窗口只保留「关于」一页**

- 去掉「更新日志 / Bug 修复记录 / 性能压测」三个标签页及随之而来的 `MakeTab` / `LoadDoc`，正文直接放进带滚动条的 `ScrollViewer`；Docs 下的 md 仍在，只是不再从窗口里读。
- Net481 副本同一处「运行环境」文案由 `.NET 8` 更正为 `.NET Framework 4.8.1`，`UiText` 中英词条同步更新，避免英文界面回退中文。

**修复｜生词本音标列全是「—」**

- 现象：生词本 3 条词（manipulations / Overload / Selectable）音标列一律 `—`，导出的 MD 里也没有音标。
- 根因：全代码只有「AI 划词卡五角星」一处 `VocabularyBook.Add`，音标参数被硬编码传 `null`；卡片其实已解析出 `_aiTransPhoneText`。此外字典里 `ә`(U+04D9)、`'` 这类旧写法会被音标校验判成假音标而丢弃。
- 修复：`PdfPageView` 改传卡片音标；`VocabularyBook` 新增 `NormalizePhonetic`（统一 `/…/`、`ә→ə`、`'→ˈ`、`ˏ→ˌ`）、`LooksLikePhonetic`、`DictionaryPhonetic`（含 `-able/-ible` 派生拼接）、`ResolvePhonetic`、`BackfillPhonetics`（启动与打开生词本时各补一次）、`SetPhonetic`（AI 取词补单条）。
- 验收：探针 `--vocab` 输出 `backfilled=3`，三条音标 `/məˌnipjuˈleiʃən/`、`/ˈəuvəˈləud/`、`/siˈlektəbl/`；实机生词本窗口截图确认全部显示（`PerfResults\vocab-ui.png`）。

**改进｜划词翻译「点了没反应」：缺网络 / 缺 AI 配置现在会明确提示**

- 现象：没配 AI 模型或断网时点划词翻译，只有一个卡片里的小字 `未配置` / `翻译失败：…`，用户以为功能坏了。
- 修复：`TranslateSelection` 在发起请求前先走 `EnsureAiReady()`：
  - 未配置 → 弹主题化对话框「尚未配置 AI 大模型（接口地址、API Key、模型名）…是否现在去配置？」；确定即打开 AI 设置面板，关闭后自动再判一次，配置成功便直接继续翻译。
  - 无网络 → 弹「当前未检测到可用网络，划词翻译需要联网才能使用。是否重新检测？」；确定后重新检测，两轮仍不通则告知本次已取消。
  - 本地端点（localhost / 127.0.0.1 / 10.x / 192.168.x / 172.16–31.x）跳过联网检查，避免内网 Ollama 被误拦。
- 四条提示文案补齐英文；验收时备份 `prefs.json`、清空 `AiBaseUrl/AiApiKey` 实测弹出英文提示框，随后已还原用户配置。

**改进｜Windows「默认应用」显示名 CA PDF Reader → XC PDF Reader**

- `FileAssociation` 的 `RegAppName` 改为 XC PDF Reader，新增 `LegacyRegAppName` 仅用于清理；ProgId 显示串同步改为 `PDF 文档（XC PDF Reader）`。
- 新增启动期 `MigrateDisplayName()`：迁移 `Capabilities\ApplicationName`、`RegisteredApplications` 值名（删旧名）、ProgId 默认值三处，其他关联不动；已是新名时不写入。
- 清掉 `.pdf\OpenWithList` 里失效的 `CA PDF Reader.exe` 死条目并保持 `XC PDF Reader.exe` 在列表内。
- 导出 xlsx 的 `dc:creator` / `Application` 元数据一并改名。

## 2026-11-18 V1.2.250

**修正｜英文界面下 AI 划词卡整张仍是中文（弹层躲过了全局补翻）**

- 现象：拖选正文点快捷栏「译」，卡片标题仍是「AI 划词翻译」、状态「翻译中…/完成 · 可复制译文」、按钮「复制译文」、星标提示「翻译完成后可加入生词本」——明明是英文界面。
- 原因：全局补翻挂在主窗口 `Loaded` 上逐元素扫一次，而划词卡是独立 HWND 的 Popup、内容又在运行中才拼出来，钩子既扫不到也扫不到第二遍。
- 修复：`ShowAiTranslateCard` 里所有可见文字改成生成时 `Localization.UiText.T(...)`（标题、复制按钮、喇叭/星标提示），状态文案在调用点包 `T`（`正在翻译…`、`翻译中…`、`完成 · 可复制译文`、`失败`、`未配置`、`无选中文本`、未选中提示句、未配置提示句），`En` 字典补 11 条。

**修正｜文案改成英文后，卡内「失败/未配置」判定失灵**

- 朗读与「加入生词本」星标原来用中文前缀判断正文是不是占位提示（`StartsWith("翻译失败")` / `"尚未完成"` / `"未选中"`）。正文一旦随界面变成英文（`Translation failed:` 等），判断恒为 false：英文界面下会把错误提示当译文朗读，还会点亮星标、把错误文本写进生词本。
- 修复：抽出 `IsAiTransPlaceholder(string)`，中英两套前缀一起判，朗读与星标共用同一处判定。

**改进｜徽章「释」「译」→ 方框内大写首字母 A / T**

- 注释卡、取词译文卡、AI 划词卡标题行、选区快捷栏两格统一为 `A` / `T`；徽章沿用 20×20 方框（描边 1.5、圆角 1、11.5pt Segoe UI 粗体），与 18px 线性图标同高。
- 两个字母的 26×18 横矩形实测会把框拉扁、字显小，已回退，只保留大写首字母。
- 快捷栏 `Copy text` → `Copy Text`。

## 2026-11-18 V1.2.249

**修正｜英文界面下模板匹配全线失效，带变量句子一律中文（含「关于」框卡顿）**

- 现象：印章颜色、词典汇总行、朗读/掌握无障碍名、颜色 N、退出确认、批量保存、导出页提示等「运行中拼出来」的句子在英文界面始终是中文；给 `UiText.Templates` 补了键也不生效，`T("已删除 3 个水印")` 原样返回。
- 定位：`TranslatePattern` 用 `Regex.Escape(整条中文模板)` 再按 `\{0\}` 找占位符替换。实测 .NET 的 `Regex.Escape` 只转义 `{`，不转义 `}`，因此 `{0}` 变成 `\{0}`，`\{0\}` 永远查不到，`groups` 恒为 0，所有模板被跳过——模板引擎等于空转。
- 修复：改为按 `{n}` 切分后的「字面量段顺序扫描」（`TryMatch`），不依赖正则；同一占位符重复出现时复用第一次捕获。改完后 `T(...)` 5 条自检样例全部命中英文，批量弹窗复扫的中文条目由 100+ 降到只剩用户数据。
- 附带：旧实现在长文本上多个 `(.*?)` 会组合回溯，实测把「关于」对话框整段卡住（日志停在上一框）；换成线性扫描后该框 1 秒内正常出图。

**修正｜印章 / 印章样式 / 批量保存 / 文件对话框等仍中英混排**

- 印章格子的显示文字、UIA 名、帮助文本、写进 PDF 的印章文字统一走译文（英文界面为 APPROVED / DRAFT 等）；`印章颜色：红色`、`颜色0…20`、`共 N 个文档待保存。`、`保存全部(_S)`、`不保存(_D)`、`关闭(_O)`、`中断全部(_A)`、逐项「等待保存 / 保存中 / 已完成 / 失败：…」、`将导出选中的 N 个页面：` 全部补键。
- 打开/另存为/导出表格/导出注释/导入离线词典/选印章图片等系统文件对话框的 **Title 与 Filter** 改为 `UiText.T(...)`，英文界面下不再出现「PDF 文件|*.pdf|所有文件|*.*」。
- 运行中才赋值的状态文案（`请打开一个 PDF 文件`、`正在生成撤销点…`、OCR `正在取消…`、注释扫描 `正在读取标注…（a / b 页）`、AI 面板测试连接全流程）改为 `UiText.T/Format`，因为全局钩子只在元素 `Loaded` 时跑一次，事后赋值的文本它看不到。
- 新增 `ToolTip.Opened` 类处理器：悬停提示是独立弹层、内容常为运行中拼串，弹出时补翻。

**修正｜侧栏页签 UIA 名是「System.Windows.Controls.TabItem 标头: 内容:」**

- 侧栏三个页签是图标 + 文字的自绘 TabItem，没有可读的 Header。翻译流程里给每个页签显式 `SetName(文字)`，读屏与自动化脚本按 Bookmarks / Pages / Comments 就能找到。

## 2026-11-18 V1.2.248

**修正｜英文界面下「拓展」菜单整条仍是中文（AI 设置、水印、页眉页脚、术语高亮、复制为表格、翻译与生词 …）**

- **现象**：界面语言 en-US，主菜单已是英文，但「Extensions」下拉里 `对比 / 分屏查看`、`AI 大模型设置…`、`水印`、`页眉 / 页脚`、`术语全片高亮…`、`清除术语高亮`、`复制为表格`、`翻译与生词` 仍是中文；其它对话框里同类文案也零散残留。
- **根因**：翻译是「以中文原文为键」的词典查找，`En` 词典只有 579 条，覆盖不到这些菜单项与后来新增的面板/对话框文案；词典查不到就原样返回中文（设计上保证界面永远可读，代价是漏译时静默留中文）。
- **修复**：扫描全部 `.cs` / `.xaml`，抽出含中文且不在 `En` 里的 UI 字面量（336 条），补 264 条英文（`En` 现约 840 条），覆盖拓展菜单全部条目、AI 设置面板、批量保存、对比窗口、离线词典、全文翻译视图、页眉页脚、印章/图章、阅读统计、生词本、打印预览、水印对话框、首选项 OCR 页等。
- **附带修掉两处结构性漏翻**：
  - 迟生成控件（标签关闭按钮、书签树展开按钮、动态「打开最近」子菜单）不在窗口加载那次遍历范围内 → `AttachGlobalTranslation()` 增加 `FrameworkElement.Loaded`（补翻无障碍名称与 ToolTip）与 `MenuItem.Loaded`（补翻整项）两条类处理器。
  - `Apply()` 现在翻译 `AutomationProperties.Name`，读屏 / 自动化脚本在英文界面不再读到中文。
- **实测**：UIA 全窗口扫描（7 个顶层菜单 + 全部子菜单逐个展开）加首选项对话框扫描，UI 中文残留 **0 处**；仅剩「打开最近」列表与窗口标题里的**文件名**（用户文件名 `…_已解除保护.pdf`）和 1 条 UIA 自身描述串。截图 `PerfResults\v248-extensions.png`、`PerfResults\v248-extensions.txt`。
- **仍存**：运行时拼接的长句（「已导出 N 页到 X」「共 N 条 · 已掌握 M 条」等带变量的状态句）未整体译为英文；高频的两处（主题按钮 ToolTip、打开最近菜单）已改成静态片段 + 变量拼接。

## 2026-11-18 V1.2.248

**修正｜英文界面下「文档保护」对话框整片中文**

- **现象**：界面语言 en-US，打开带权限限制的 PDF 后弹出的保护提示框仍是中文（标题「文档保护」、结论「该文档限制了部分操作」、说明段、5 条受限项、勾选项「以后同类文档都这样处理，不再提示」、按钮「忽略，继续阅读(I)」「去除保护（另存副本）(R)」）。
- **根因**：`Dialogs\ProtectionDialog.cs` 是代码拼装的自绘窗口，全部文案是写死的中文字面量，没有经过 `UiText`；`PdfProtectionInfo.Blocked` 也是中文短语，被原样塞进 TextBlock。全局 `UiText.Translate` 只遍历已存在的控件树，这层自绘内容不会自动翻译。
- **修复**：文案全部改 `UiText.T(...)`（结论、三段说明、勾选、Tooltip、6 个按钮、密码错误提示三句、去保护后续提示、状态栏文案），受限项渲染改 `UiText.T(b)`；`En` 词典新增 20+ 条对应英文。
- **实测**：截图 `PerfResults\v248-prot-dialog.png`（标题 `Document protection`、按钮 `Ignore, keep reading (I)` / `Remove protection (save a copy) (R)`）。

**修正｜英文界面下所有文档「适应宽度」失效（缩放恒为 100%）**

- **现象**：工具栏缩放下拉显示 `Fit width`，但文档按 100% 排版、不铺满宽度；切换 `Fit page` / `Fit visible` 同样无效。
- **根因**：缩放下拉项文字在英文界面已被翻译成 `Fit width` 等英文，而 `MainWindow.xaml.cs` 的 `CurrentZoom`、`IsFitWidth/IsFitPage/IsFitVisible`、`OnFitWidth`、`SelectZoom`、`DefaultZoomIndex` 都用裸中文 `"适应宽度"` 等做等值比较，命中不了；`CurrentZoom` 因此落到末尾 `return 1.0`，`IsFitWidth` 等恒 false，适应计算不再生效。另外 `IndexToZoomName()` 返回的是**已翻译**名称，导致 `prefs.json` 的 `LastViews[].ZoomName` 在英文下被写成 `Fit width`，与中文原文比较不上。
- **修复**：新增 `ZoomItemName()`（`UiText.Source(Content)` 反向翻回中文原文）与 `ZoomItemIs()` 作为唯一判断入口，6 处比较全部改走它；`IndexToZoomName()` 改为固定返回中文原名，保证持久化名称稳定。
- **实测**：同一文档英文界面下状态栏 `Zoom 211%`、页面按宽度铺满（截图 `PerfResults\v248-fitwidth.png`）；日志 `页面渲染: 第 1 页 1294×1675 DIP → 1618×2094px @ 120 DPI（缩放 2.64×）`。

## 2026-11-18 V1.2.246

**修正｜换了图标文件但资源管理器仍显示旧图标（同路径不刷新缓存）**

- **现象**：把 `filetype.ico` 的内容换成留白版之后，`.pdf` 文件在资源管理器里还是原来的大图标。
- **根因**：`FileAssociation.RefreshIcon()` 只在**注册表值字符串**与期望值不同时才 `SetValue` 并 `NotifyShell()`。这次路径没变（还是同一个 `filetype.ico`），字符串相等，于是既不写注册表也不通知外壳，`SHChangeNotify` 一次都没发出去，图标缓存自然不更新。
- **修复**：`RefreshIcon()` 在「已注册且图标文件存在」时**总是** `NotifyShell()`（注册值不一致才写注册表）。启动时一次通知成本很低，换来升级后图标立即生效。
- **实测**：`SHGetFileInfo` 直接读系统给的图标 → 40×40、艺术区 `(3,2)-(35,37)`（四周有留白），与 `filetype.ico` 的 87.5% 艺术区一致；旧图标同一流程下是满幅。截图 `PerfResults\v245-shell-fileicon.png`。

## 2026-11-18 V1.2.245

**修正｜首选项把语言切到 English，点「确定」/「应用」后主窗口仍是中文（要重启才变）**

- **现象**：用户截图里首选项对话框整片英文（标题 `Preferences`、`Interface language`、下拉 `English`、状态行 `Current interface language: English · preference: English`），背景主窗口的菜单/工具栏/状态栏全是中文：「文件 编辑 视图 工具 拓展 窗口 帮助」「适应宽度」「查找文本」「总计 17」「缩放 217% 当前工具：选择」。改完必须重启软件才生效。
- **根因**：`UiText` 的翻译只由两个类级事件驱动 —— `Window.Loaded`（窗口首次显示时翻一次）与 `ContextMenu.Opened`（右键菜单弹出时翻一次）。主窗口在打开首选项之前就已经 Loaded 完了；`PreferencesDialog.OnLanguageChanged` 只对自己调 `UiText.Translate(this)`（所以「这个窗口立即预览」是对的），`OnOk` / `OnApply` → `ApplySettings()` 只把 `p.Language` 写进 prefs 就返回，**没有任何一条路径去重翻已打开的主窗口**。于是只有下次启动、`Loaded` 再跑一遍时语言才真正切过去。
- **修复**：
  1. `UiText.TranslateOpenWindows()`：`Application.Current.Windows` 全量 `Translate`，任何「运行中途换语言」都能一键铺满。
  2. `MainWindow.ApplyLanguage()`：翻整棵树之后**再重算运行期动态文案** —— 状态栏（`UpdateStatus`：`Zoom {n}%    Tool: {name}` / 「缩放 …%  当前工具：…」）、页码（`RefreshPageNav`：`of {n}` / 「总计 n」）、标签栏受保护后缀（`RefreshTabTitleDots`）。这些字符串是代码拼出来的，不在词典里，光靠递归翻译翻不到。
  3. `PreferencesDialog.ApplyLanguageEverywhere()`，挂在 **「确定」与「应用」** 两个入口；`OnClosed` 的「未应用就关闭」分支同样补一次，让「预览英文后取消」不会把主窗口留在英文。
- **同时修掉反切回中文时的半英文侧栏页签**：英文态为了塞进 66 DIP 把「页面」写成 `Pages`、「标注」写成 `Comments`，而 `En` 词典反向映射的键是 `Page` / `Annotations`，`T("Pages")` 查不到 → 切回中文后侧栏显示「书签 | Pages | Commen…」（第三格还被 `CharacterEllipsis` 截断）。改为在 `TabItem` 分支里先 `Pages→页面`、`Comments→标注` 再走 `T()`，并把英文态加的 `Padding` 用 `ClearValue(Control.PaddingProperty)` 还原成 XAML 值。
- **实测**（Release 1.2.245，`PerfBench\ui_lang_live_v245.ps1`，带 17 页文档启动、prefs 先置 `zh-Hans`）：
  - 首选项里选 `English` → 点「应用」：主窗口菜单**当场**变 `File (F) | Edit (E) | View (V) | Tools (O) | Window (W) | Help (H)`，状态栏 `Zoom 100%    Tool: Select`、页码 `of 17`、侧栏 `Bookmarks | Pages | Comments` → `PASS`。
  - 再选「简体中文」→「确定」：菜单回 `文件(F) | 编辑(E)…`、页码 `总计 17`、侧栏 `书签 / 页面 / 标注`（图标恢复）→ `PASS`。
  - 截图：`PerfResults\v245-lang-final-1-zh.png`、`-2-dlg-zh.png`、`-3-after-apply-en.png`、`-4-back-zh.png`。
- **教训**：这类「某窗口/某控件不跟着设置变」的问题，先问「这个翻译/刷新挂在哪个人生周期事件上」——挂在 `Loaded` 上的东西，运行期改设置必然漏；UI 设置的「立即生效」必须有一条显式的、对所有已打开窗口的刷新路径。

**修正｜语言下拉一选就把首选项自己变英文（用户要求改为「确定/应用」时才整体切换）**

- **现象**：在首选项里把语言选成 English，只有首选项窗口立刻变英文、主窗口仍中文；用户希望**下拉只记录选择**，点「确定」或「应用」后全应用一起换。
- **根因**：`OnLanguageChanged` 里调了 `UiText.Apply(code)` + `UiText.Translate(this)`（上一版为「所见即所得」设计）。
- **修复**：`OnLanguageChanged` 只保留 `UpdateLangStatus()`；状态行会显示「当前界面语言：简体中文（偏好设置：English），点「应用」或「确定」后切换」。切换统一走 `ApplyLanguageEverywhere()`（现在还会重算状态行、语言下拉选项、性能页 RAM/CPU、OCR 页状态与缓存路径、文件关联状态，并按语言把窗口宽度在 620 / 720 DIP 之间切换）。
- **实测**（`PerfBench\ui_lang_defer_v245.ps1`，Release 1.2.245）：只选不点按钮 → 首选项与主窗口都保持中文（`PASS`）；点「应用」→ 对话框与主窗口同时英文、状态行 `Current interface language: English · preference: English`（`PASS`）；选回简体中文再点「确定」→ 一起回中文（`PASS`）。截图 `PerfResults\v245-lang-defer4-A-select-only.png` / `-B-after-apply.png` / `-C-back-zh.png`。
- **顺带发现**：切换后对话框里「当前界面语言…」状态行仍是旧语言（它在代码里拼字符串，递归翻译翻不到）——已随上面一并重算，`-B` 截图确认变英文。

## 2026-11-18 V1.2.244（第二批）

**修正｜无文档时「文档表格」「选择工具」仍可点**

- **现象**：空窗口下工具栏只有「打开」该亮，但「文档表格」「选择工具」两个按钮是可点的；点「选择工具」还停在蓝色选中态，看着像已经选了工具。
- **根因**：`SetDocControlsEnabled(false)` 的文档级开关数组是按功能一个个列出来的白名单，后加的 `DocTablesBtn` 与 `ToolSelect` 没进列表，于是保持 XAML 默认的可用状态；`ToolSelect` 是 ToggleButton，`IsChecked=true` 的透明蓝底叠在禁用态上看不出被禁。
- **修法**：两个控件加入开关数组；无文档时把 `ToolSelect.IsChecked` 置 false（`CurrentTool` 保持 Select，行为不变），有文档时按 `CurrentTool` 把选中态补回。
- **实测**（Release 1.2.244，`PerfBench\ui_shell_state_v244.ps1`）：空窗口工具栏 29 个控件，启用 2 个 = 「打开」+ 主题切换，禁用 27 个；`DocTablesBtn IsEnabled=False`、`ToolSelect IsEnabled=False`，截图 `PerfResults\v244-shell-empty.png` 里选择工具已无蓝色选中底。

**修正｜文档已有水印时「添加水印」仍可用（会叠出两层水印）**

- **现象**：带斜排大字水印的 `SGM61231 … _TLED.PDF` 上，「拓展 ▸ 水印 ▸ 添加水印…」照样可点，点进去再加水印就变成两层互相压印。
- **根因**：水印菜单项是动态构建（`BuildExtendedToolsMenu`）后一直保持可用，从未按「当前文档是否已有水印」判断；水印识别（`DetectForeignWatermarks`）只在「删除水印」菜单里点开时才跑，打开文档时不检测。
- **修法**：`PdfDocument.CountWatermarks()` 数本程序加的水印标记；`DocTab.HasWatermark` 缓存「本程序水印 or 第三方识别」的结论，切到该文档时在后台线程跑一次（不进 UI 关键路径），命中即把「添加水印」置灰并改 ToolTip；加完水印立即置 true，删水印后清缓存重扫。
- **实测**：带水印文档 `添加水印 IsEnabled=False`、`删除水印 IsEnabled=True`（`PerfResults\v244-wm-doc-menu.png`，菜单项肉眼可见灰化）；无水印文档 `添加水印 IsEnabled=True`；两次检测耗时 164 ms / 295 ms，均在后台线程。

## 2026-11-18 V1.2.244

本版本给 AI 划词卡补「原单词 + 音标」，过程中修掉 3 个音标相关缺陷，均已在 Release 1.2.244 上重拍验证。

**修正｜单词卡音标行在正文里重复出现**

- **现象**：`voltage` 卡片标题下已显示 `/vəˈlɪdʒ/`，正文第一行又是 `/vəˈlɪdʒ/ n. 电压；电位差`（`PerfResults\v243-aiword-voltage-late.png` 旧版实拍）。
- **根因**：`TakePhoneticFromStream()` 在「卡片已有音标」时直接 `return raw`，不再剥离首行——流式第一块拿到音标后，后续每个数据块拼出的正文都把音标行带了回来。
- **修法**：拆开两件事——**剥行永远做**（首行是音标就整行丢掉，不管卡片上有没有音标），**填音标只在 `_aiTransPhoneText` 为空时做**。离线音标先到时也不会挡住剥行。
- **实测**：`capacitor` / `voltage` 两词正文分别只剩 `n. 电容器` / `n. 电压；电位差`，卡片上音标各一行（`PerfResults\v243-aiword-capacitor-late.png`、`v243-aiword-voltage-late.png`）。

**修正｜离线词典音标被「无音标词条」挡住，翻到的永远是空**

- **现象**：`dictprobe=voltage` 日志 `音标=[]`，而四本词典合计 54 万条已加载。
- **根因**：`OfflineDictionary.Lookup()` 按词典顺序返回**第一本命中**的词条；cdict 的英文词条只有释义（`Phonetic` 空），把后面 kdic / lazyworm / oxford 里可能存在的音标挡掉了。
- **修法**：新增 `OfflineDictionary.PhoneticOf(word)`，逐本词典找**第一条非空音标**再返回；`OfflinePhoneticText()` 改用它。
- **实测**：`dictprobe` 显示该词条确实只有 5 条释义、无音标（这批词库本身缺 IPA），因此单词卡第二路兜底改为「译文首行」而不是再发一次取词请求。

**修正｜AI 返回假音标（含西里尔字母）直接贴上卡片**

- **现象**：`voltage` 曾被填成 `/vələtɪдж/`（末尾是西里尔字母 `дж`），肉眼看着像音标、念不出来。
- **根因**：音标文本未做字符集校验，模型吐什么就显示什么。
- **修法**：新增 `LooksLikePhonetic()` 白名单（拉丁字母、IPA 扩展区、组合附加符号、`ˈ ˌ ː . , - ' ( ) [ ] / ~`），命中即丢弃并写日志「丢弃可疑音标」。两路来源都过这道校验。
- **实测**：日志出现 `丢弃可疑音标` 时卡片只显示原词、不显示音标；正常情况下 `capacitor → /kəˈpæsɪtər/`、`voltage → /vəˈlɪtɪʤ/`。

**修正｜命令行钩子参数 `aiword=` 被当成文档路径**

- **现象**：用 `aiword=voltage` 启动时弹「打开失败 Could not find file '…\aiword=voltage'」。
- **根因**：`MainWindow` 把所有非 `-` 开头的参数都当文件路径处理。
- **修法**：`IsCommandLineHookArg()` 的 switch 增加 `aiword`、`dictprobe` 两个键。
- **实测**：带这两个参数启动不再弹窗，`aiword` 直接把指定单词走一遍划词（`PerfBench\cap_aiword_card.ps1`）。

## 2026-11-18 V1.2.243

本版本新增首选项「语言」分类后做英文界面逐页目检（11 页全截图），发现并修掉 6 处英文态排版/漏译问题；把本地化铺到主窗口与各对话框后又修掉 2 处外壳裁切/漏译问题。均已在最新 Release 二进制上重拍验证。

**修正｜英文态侧栏页签被 66 DIP 等分宽度裁字**

- **现象**：切英文后侧栏底部三个页签读作 `Bookma` / `Page` / `Annotati`——每个词的头尾都被裁掉。
- **根因**：页签条用 `UniformGrid Rows=1` 等分侧栏（默认 200.4 DIP → 每页签 66.8 DIP），页签内容是「15 DIP 图标 + 4 DIP 间距 + 文字」，减去图标与内边距后只剩约 46 DIP；`Annotations`（11 字符）与 `Bookmarks`（9 字符）在这个宽度里放不下，`TabItem` 默认样式又没有省略号，于是中心裁切。
- **修法**：`UiText.Apply` 增加 `TabItem` 分支——Header 是一个 `Path` + 一个 `TextBlock` 时，英文态把图标 `Collapsed`（把宽度让给文字）、字号 11、`Padding` 收紧到 2，文字 `TextTrimming=CharacterEllipsis` 兜底；同时把该上下文专属的短词改写（`Annotations → Comments`、`Page → Pages`），中文态恢复图标与 12 号字。
- **实测**：英文态三页签完整读作 `Bookmarks | Pages | Comments`，无裁切（`PerfResults\v243-en-shell.png`）；中文态图标照常显示。

**修正｜页面右键菜单整列中文（菜单项在代码里按短文案构建）**

- **现象**：英文界面下页面右键菜单半中半英：`Find text / Open / Page / Preferences` 已英文，`手型工具 / 适合宽度 / 护眼模式 / 另存为 / 打印 / 工具 / 文档属性` 仍是中文。
- **根因**：该菜单由 `Controls\PdfPageView.cs` 在**右键时动态构建**（`AddDocItem(ctx, "适合宽度", …)`、`MenuIcons.Item("手型工具", …)`），构建发生在窗口 `Loaded` 之后，且这些短文案（`手型工具`、`适合宽度`、`文档属性`）与主窗口菜单里的长文案（`手型工具：按住拖动文档…`）不是同一份键，词典里没有对应条目，于是原样漏出。
- **修法**：`EnExtra` 补齐这批短键（手型工具 / 适合宽度 / 护眼模式 / 另存为 / 打印 / 工具 / 文档属性 / 复制 / 全选 / 复制全部表格 / 导出表格为 Excel / 清空剪贴板 / 复制译文 等 18 条）；动态菜单在 `ContextMenu.Opened` 的类级处理器里整棵树翻译，构建时机不影响结果。
- **实测**：同一个右键位置，菜单整列英文 `Hand tool / Fit width / Eye care / Find text / Open / Save as / Print / Page / Preferences / Tools / Document properties`（`PerfResults\v243-en-ctxmenu.png`）。

**修正｜英文长勾选文案被固定行高裁掉半行**

- **现象**：General 页 `Warn when opening a protected document (password / copy or print restricted)` 在 900 px 窗口里右端被面板裁掉；Animations 页首项 `Enable UI animations (sidebar, panels, page flip, single/two-page switching)` 折成两行后第二行只剩上半截，被下方分隔线压住。
- **根因**：① `CheckBox` 文案是普通字符串 `Content`，`CheckBox` 本身不换行，超宽只能被父面板裁掉；② `CbAnimations` 在 XAML 里写死 `Height="20"`（12 px 字体单行正好 20 px），换成两行后固定高度把第二行裁半，且行高不再参与布局，视觉上与分隔线重叠。
- **修法**：`Localization\UiText.cs::Translate` 对 `CheckBox` / `RadioButton` / `Label` 的 `Content(string)` 增加规则：英文态且译后长度 > 44 字符时，把 `Content` 换成 `TextBlock { TextWrapping = Wrap, MaxWidth = 430 }`，并同时 `Height = double.NaN`、`MinHeight = 20`、`VerticalAlignment = Center` 解除定高（中文态保持原字符串，布局不变）。
- **实测**（Release 1.2.243）：General 页保护提示完整两行（`restricted)` 可见、右端不越界）；Animations 页首项两行完整（第二行 `switching)` 全见、分隔线下移不遮挡）。截图 `PerfResults\v243-en-p0.png`、`v243-en-p2.png`。

**修正｜Performance 页 RAM/CPU 行仍是中文且贴右端**

- **现象**：Performance 页 `物理内存 (RAM): 总计 16107 MB，当前可用 4551 MB` 与 `系统包含 8 个 CPU` 在英文界面里保持中文，且 `HorizontalAlignment="Right"` 让长串顶到面板右边缘。
- **根因**：这两行是运行期用 `$"…"` 拼出来的（`RamInfo` / `CpuInfo`），不是 XAML 静态串，词典遍历覆盖不到。
- **修法**：`PreferencesDialog.xaml.cs::InitPerfPage` 按 `UiText.IsEnglish` 分支输出英文短串；首版 `Physical memory (RAM): 16107 MB total, 4540 MB available` 实测右端仍贴边（放大 2× 复查右端与面板边只差 2 px），缩短为 `RAM: 16107 MB total / 4540 MB free` 与 `8 CPUs in this system`。
- **实测**：`PerfResults\v243-en-p5.png` + 2× 放大 `v243-en-p5-ram.png`，英文短串右端距面板边留白充足。

**修正｜File association 状态行中文**

- **现象**：英文界面下 `Set XC PDF Reader as the default PDF reader:` 下面一行仍是「当前状态：已注册为本用户的 PDF 处理程序（是否默认由系统设置决定）。」。
- **根因**：`UpdateAssocStatus()` 直接赋中文字面量，绕过词典。
- **修法**：改为 `UiText.T("当前状态：…")` / `UiText.T("当前状态：未注册。")`，两条中文键进词典（英文 `Status: registered as this user's PDF handler (Windows decides whether it is the default).` / `Status: not registered.`）；顺带把注册成功、注册失败、移除关联三处 `Msg.Show` 文案（含标题「文件关联」）也本地化。
- **实测**：`PerfResults\v243-en-p7.png`，状态行两行英文完整、右端不被裁。

**修正｜OCR 页状态 / 按钮 / 缓存前缀中文**

- **现象**：OCR 页 `已就绪`、`检查更新`、`组件缓存位置：C:\Users\Frank\AppData\Local\XC PDF Reader\ocr\ppocrv4-mobile-1` 在英文界面下仍是中文。
- **根因**：`OcrStatus` 取 `OcrPluginManager.StatusText`（中文 switch），按钮文案与 `OcrHint` 也是运行期赋值，全部绕过词典。
- **修法**：`Ocr\OcrPluginManager.cs` 增加与 `StatusText` 一一对应的 `StatusTextEn`（`Ready` / `Downloading…` / `Download failed: …` / `Not installed (downloads on first enable, about X)`）；`RefreshOcrUi` 按 `UiText.IsEnglish` 选状态串，按钮文案走 `UiText.T("检查更新" / "下载组件")`，缓存前缀改 `Component cache: `；校验流程里「检查中…」「正在校验本地组件（大小与 SHA256）…」「已取消检查」「检查更新失败：」「OCR 更新检查」与「已是最新版本」弹窗一并本地化，词典补齐 5 条。
- **实测**：`PerfResults\v243-en-p9.png`，页面可见文本全英文（`Ready` / `Check for updates` / `Component cache: …`）。

**修正｜Page display 页 `Resolution` 下拉被裁成省略号**

- **现象**：`Resolution (R):` 右侧下拉显示 `Automatic (follow syst…`，选项文本被 160 DIP 固定宽度截断。
- **修法**：词典把 `自动（跟随系统）` 的英文由 `Automatic (follow system)` 缩短为 `Auto (system)`（此处 `Auto` 与 `Automatic` 语义等同，`(system)` 已表达「跟随系统 DPI」）。
- **实测**：`PerfResults\v243-en-p3.png`，下拉完整显示 `Auto (system)`，无省略号。

**修正｜英文态逐页截图脚本取不到窗口句柄（工具侧，非产品缺陷）**

- **现象**：`PerfBench\cap_lang_pages_v243.ps1` 偶发 `Cannot convert null to type "IntPtr"`（`GetWindowTextW` 按标题 `XC PDF Reader V1.2.243` 找不到窗口），以及 `$AU::FromHandle($hs[0])` 收到空串。
- **根因**：实际标题是 **两个空格** `XC PDF Reader  V1.2.243`，按单空格匹配必然失败；偶发取不到首选项 HWND 是「点菜单落空」（自绘菜单需 `ExpandCollapsePattern.Expand()` 后按 `BoundingRectangle` 真鼠标点击，首次点击偶尔被前景切换吃掉）。
- **修法**：窗口定位改为先取进程主窗口元素、直接用 `NativeWindowHandle` 调 `SetForegroundWindow`，不再依赖标题字符串；偶发失败时杀残留进程重跑（已连续 5 轮稳定出 11 张图）。
- **留档坑**：自绘标题栏 + 自绘菜单的程序，UIA 的 `FindAll(Children, ProcessId)` 常只返回主窗口，`InvokePattern` / `LegacyIAccessible` 对菜单项无效，必须真鼠标点。

## 2026-11-18 V1.2.241

本版本修复（详情见下列各条）：长文件名遮盖标签红点；书签跳转只到页首（两轮）；导出 PDF 默认文件名 n 不代表页数；另新增「文档表格」整文档识别 + 多选导出 Excel。版本号同步：csproj 四字段、`AssemblyInfo.cs` 三特性、安装脚本 6 处（原停留 1.2.225，一并升到 1.2.241，UTF-8 BOM 保留）。

**修正｜AI 划词每次启动只能触发一次：译文卡 Border 被旧 Popup 占着逻辑父子关系，第二次建卡抛异常又被丢弃的 Task 吞掉**

- **现象**：启动后第一次选中文本点快栏「译」正常出译文卡；此后无论选哪段、点几次「译」都不再出卡，必须重启软件。
- **根因 1（逻辑父子关系）**：`_aiTransCardBorder` 为动效稳定而复用（PopIn/PopOut 要作用在同一元素上），每次建卡却 `Popup.Child = _aiTransCardBorder` 挂到**新** `Popup`；旧 Popup 关闭只置 `IsOpen=false`、`Child` 未清空 → 第二次赋值抛 `InvalidOperationException：指定的元素已经是另一个元素的逻辑子元素。请先将其断开连接。`
- **根因 2（异常被吞）**：`TranslateSelection()` 是 `_ = RunAiTranslateAsync(...)`（fire-and-forget），建卡异常发生在首个 `await` 之前，异常挂在被丢弃的 Task 上，既不落日志也不弹提示 → 用户只看到「点了没反应」。
- **根因 3（钩子参数被当文件）**：`aiprobe` / `selprobe` 的 `key=value` 启动参数会逐个 `OpenFile`，每次跑自动化弹一串「打开失败」对话框，遮挡截图、污染日志。
- **修法**：① `ForceCloseAiTranslateCard()` 收卡时 `if (popup.Child != null) popup.Child = null`；新增 `_aiTransCardBorderHost` 记录 Border 当前宿主，`ShowAiTranslateCard()` 建卡前若旧宿主仍持有先解绑，再挂到新 Popup 并更新宿主；② 建卡包 `try/catch` 写日志，`TranslateSelection` 用 `ContinueWith(OnlyOnFaulted)` 记录 Task 异常；③ 启动打开文件前用 `IsCommandLineHookArg()` 过滤钩子参数。
- **验证**（Release 1.2.241，0 error 0 warning，无鼠标钩子 `aiprobe` = 选中 → 点快栏 `SelTranslate`，两轮）：修前第二轮停在 `强制收卡 gen=4`，紧接 `建卡失败 InvalidOperationException`；修后第二轮 `卡片已打开 IsOpen=True gen=6`，状态「完成 · 可复制译文」，译出「h 输入电压范围为4.5V至28V，输出电流额定值为3A。」。实拍 `PerfResults\v241-ai-round1.png` / `v241-ai-round2.png`（同进程内两次卡片，且不再有「打开失败」弹窗）。
- **留档坑**：`Popup.Child` 赋值会建立逻辑父子关系，复用子元素换 Popup 必须先解绑（与 Popup 是否 `IsOpen` 无关）；`_ = SomeAsync()` 的异常不会自己冒泡，异步入口要么 `await` 要么挂异常续延。


**取词卡与划词卡的操作入口收敛（最终态，取词卡恢复原样）**

- **过程**：曾尝试在**悬停取词卡**上加入「朗读 / ＋生词本」按钮，为此把取词卡 `Popup` 从 `IsHitTestVisible=false` 改为可命中、加 420ms 延迟关闭、再加 `_translateCardPinned` 钉住首词，才解决「鼠标一动卡片就消失、按钮点不到」。
- **最终决定**（用户反馈「就是为了取词加生词本导致的，目标就是去掉加生词本和朗读入口，恢复之前就行」）：悬停取词卡的所有操作行全部**删除**（`BuildLookupActions` 及调用），取词卡只显示释义；上述为点按钮而做的 `IsHitTestVisible=true` / `DispatcherTimer` / `_translateCardHovered` / `_translateCardPinned` / `ScheduleCloseTranslateTip` **全部回退**，`Popup` 恢复 `IsHitTestVisible=false`，`OnMouseMove` / `MouseLeave` 离开词立即 `CloseTranslateTip()`，回到原始「随鼠标移动消失」行为。
- **保留**：朗读与加入生词本统一收在 **AI 划词译文卡** 标题行右上角——`AiTransSpeakButton`（喇叭 `SpeakIconGeometry`）与 `AiTransAddVocabButton`（五角星：`CreateVocabStarButton` / `SetVocabStarState` / `VocabStarGeometry`，未加入空心、加入后 `#FFC107` 黄色实心，已加入由 `VocabularyBook.Contains` 挡住不重复写盘）；footer 只留状态与「复制译文」。
- **朗读顺序**：`SpeechService.SpeakSequence(params string[])` 在同一后台 Task、同一 `SpVoice` 里循环 `voice.Speak(part, 0)` 串行读原文+译文；译文卡按钮读 `(原文, 译文)`，翻译中/失败时只读原文。`Speak(string)` 转调它，生词本朗读不变。
- **修正｜取词卡窗口不跟随鼠标移动**（用户截图反馈）：`Popup` 用 `PlacementMode.MousePoint` 只在首次打开时按鼠标定位，复用 Popup 流式刷新时位置钉死——换词只切内容、窗口留在旧词处。改为 `PlacementMode.Relative` + 新增 `PositionInfoPopup()`（当前 `Mouse.GetPosition(this)` + 14px 偏移），在 `RefreshInfoCard()` 创建 / 复用分支与 `OnMouseMove` 取词分支每次更新 `HorizontalOffset` / `VerticalOffset`。截图对比：鼠标换词后卡片窗口跟着移到新词、内容同步切换；构建 0 警告 0 错误。
- **验证**：UIA 实测取词卡 `WordSpeakButton` / `WordAddVocabButton` 均 False，鼠标移到别的词时卡片随即消失（恢复原行为）；划词卡两按钮在标题行右上角相邻；星星空心→黄实心、写盘防重复、顺序朗读均通过；构建 0 警告 0 错误，lint 干净，临时数据已清理。

**取词只翻译英文单词到中文（中文不弹卡）**

- **现象 / 需求**：取词翻译的定位是「英文单词 → 中文释义」，但此前中文词悬停也会触发 AI 查询、弹出无意义卡片。
- **修法**：① `WordLookup.SystemPrompt` 固定为 `English-to-Chinese dictionary`，明确只接受英文单词 / 短语，按「音标 + 词性中文义 + 可选例句」输出；② 新增 `WordLookup.IsEnglishWord(string?)`——逐字符判定，必须含 ASCII 字母，只允许空格 / 连字符 `-` / 撇号 `'`/`’` / 句点 / 数字，出现 CJK / 假名 / 其它符号即否决；③ `PdfPageView.OnMouseMove` 取词分支改为 `text != null && WordLookup.IsEnglishWord(text)` 才 `RequestWordLookup`，否则 `CloseTranslateTip()`（中文上不弹卡、立即关旧卡）。
- **验证**：GUI 截图实测——悬停中文段落无取词卡；悬停英文词 `VSS` 正常出卡、内容为英译中（`/vi: ess/` + 「缩写：虚拟实现系统」+ 例句）；构建 0 警告 0 错误。

**划词译文卡没有出入口动效 + 缩写专业术语不翻译**

- **现象**：划词翻译的译文卡出现 / 消失都是瞬开瞬关，没有像取词卡那样的 PopIn / PopOut；且 IGBT / ADC / BOM 等缩写术语常原样保留、不译。
- **根因**：① `ShowAiTranslateCard` 每次 `new Border` + `new Popup` 直接 `IsOpen=true`，关闭直接 `IsOpen=false`，全路径没有 `LayoutAnim` 调用；且 `StaysOpen=false` 由 WPF 瞬时关闭，无法插入退场动画。② 划词 prompt 写着 `Preserve paragraph breaks, numbers, units, formulas and proper nouns`，模型把缩写当专名保留，也没有「展开缩写」指令。
- **修法**：① 卡片外框提升为字段 `_aiTransCardBorder` 长期复用，`_aiTransCardGen` 代次守卫 + `_aiTransCardClosing`；打开时显式 `LayoutAnim.PopIn(0.96,6,180ms)`，关闭走 `CloseAiTranslateCard()` 播 `PopOut(0.96,6,150ms)` 后再真正关 Popup；新请求先 `ForceCloseAiTranslateCard()` 瞬时收旧卡、作废旧回调，避免叠加。② `StaysOpen=true` + 窗口级 `PreviewMouseDown`（用 `IsDescendantOf` 排除卡片内部点按）/ `Deactivated` 处理器触发带动画关闭，`ForceCloseAiTranslateCard` 里反注册。③ prompt 改为「缩写/首字母缩写不是专名，必须展开翻译、首次出现中文全称 + 原缩写括注」，仅公司名 / 品牌 / 产品型号保留原样。
- **验证**：UIA 定位 `SelTranslate` 徽标触发划词翻译，GUI 实测译文卡正常显示且把 `BOM` 译为 `bill of materials (BOM)`（缩写展开生效）；放大退场时长到 1200ms 打点实测 `POPOUT gen=3 → DONE gen=3` 间隔 1203ms，确认点卡片外真的走 PopOut、时长受控、done 才关；恢复 150ms 后构建 0 警告 0 错误。
- **踩坑**：选区徽标条在弹层里，像素坐标受 DPI 缩放 + 焦点影响不可靠，改用 UIA `AutomationId=SelTranslate` + `InvokePattern` 调用；验证脚本务必 `MinimizeAll + ShowWindow + SetForegroundWindow` 把 PDF 窗口置前，否则拖选打到 IDE 上。

**取词优先级：AI 优先、离线词典兜底（原为离线优先）**

- **现象 / 需求**：此前 `RequestWordLookup` 先查 `OfflineDictionary`，命中就直接显示离线释义、完全不发 AI 请求——装了离线词典后 AI 取词永远没机会用。需求改为「有网络 AI 取词优先，没有网络才用离线词库」。
- **修法**：① 去掉同步的离线优先分支，改为先查进程内 AI 缓存（只存成功 AI 结果，零等待），再判断 `LlmClient.IsConfigured && (本地端点 || NetworkInterface.GetIsNetworkAvailable())` 决定是否走 AI 流式查询；② AI 返回非 transient 结果即采用（即使离线词典也收录该词）；③ 仅当 AI 未配置 / 无网络 / 请求返回 transient 失败时，才 `OfflineDictionary.Lookup` 回退，离线也未命中则沿用 AI 的错误提示；④ 新增 `IsNetworkAvailable()`（取状态异常按有网络处理，交由请求自身报错回退）；⑤ 本地端点（Ollama 等 loopback / 私网）跳过网络开关，保证离线本机推理可用。
- **验证**：GUI 实测同一词 `TIDA`（离线词典已收录）——AI 配置有效时卡片显示「来源 AI 智能翻译」（AI 优先）；把顶层 `AiBaseUrl` 指向不可达地址后显示「来源 离线词典 · CDICT5英汉词典」（回退成功）。构建 0 警告 0 错误。
- **踩坑**：`prefs.json` 的 AI 配置以**顶层镜像字段** `AiBaseUrl` / `AiApiKey` / `AiModel` 为准（`LlmClient` 直接读），改 `AiModels[]` 里的预设不影响运行时，模拟 AI 不可用必须改顶层字段；且 PowerShell 5.1 的 `ConvertTo-Json` 整体重写会破坏中文编码，验证时用 .NET 精确字符串替换 + UTF8 无 BOM 写回，测完从备份按字节还原。

**取词 popup 没有弹出 / 收回动效**

- **现象**：悬停取词卡（与标注悬停卡共用）出现与消失都是「瞬开瞬关」，没有任何缩放 / 淡入淡出动效，与项目其它 Popup / 对话框的 PopIn / PopOut 手感不一致。
- **根因**：① `RefreshInfoCard()` 每次刷新（流式 partial、换词）都 `new Border` 替换 `Popup.Child`，动画目标元素当帧即被丢弃；② `_infoPopup` 是代码 `new` 出来、未进视觉树，全局 `LayoutAnim.ApplyPopup` 挂在 `Popup.LoadedEvent` 上的钩子不会触发，入场动画根本没注册；③ 关闭路径 `RefreshInfoCard` 的 `stackPanel==null` 分支直接 `IsOpen=false`，无退场动画。
- **修法**：① 抽出字段 `_infoCardBorder`，外框只建一次长期复用，刷新只换 `Child`（StackPanel），PopIn/PopOut 始终作用于稳定元素；② 首次 `IsOpen=true` 后显式 `LayoutAnim.PopIn(border, Dur("Popups",180) / 0, null, 0.96, 6.0)`；③ 新增 `CloseInfoCardAnimated()`：播 `PopOut(card, Dur("Popups",150), done, 0.96, 6.0)`，done 里才 `IsOpen=false` 并清空 `_infoPopup` / `_infoCardBorder`；④ `_infoCardGen` 代次 + `_infoCardClosing` 守卫——退场途中又取词则 `gen++` 作废旧 done、重新 PopIn，连续 MouseLeave 不重复起退场。
- **验证**：放大退场时长到 1200ms 打点实测 `enter → POPOUT gen=1 → DONE gen=1`（间隔 1235ms），确认 PopOut 真正在跑、时长受控、done 才关卡；恢复 150ms 后 GUI 复核——离线词典词（TIDA）悬停正常出卡、移开正常收卡，取词功能无回归；构建 0 警告 0 错误。
- **踩坑**：① 截图连拍（每帧 `CopyFromScreen` 上百 ms）抓不到 180ms 动画中间帧，改用「放大时长 + 打点计时」确证；② 验证脚本必须 DPI-aware（屏幕物理 1920×1080，未 aware 时逻辑 1080×615 导致 SetCursorPos 全部错位）；③ 项目是单实例（Mutex），启动前不 `Stop-Process` 旧进程则新进程转发参数后退出、测的还是旧 exe。

**优化｜「删除水印 / 删除页眉页脚」要等 4–5 秒且界面假死：重复扫描白做 + 重活压在主线程**

- **现象**（52 页 GD32A511 数据手册）：点「删除水印」或「删除页眉页脚」，窗口整片灰掉、鼠标转圈 4–5 s 才出结果；17 页的文档也要 0.3 s 左右但没有反馈。
- **根因 1（重复扫描）**：识别与删除是两趟独立遍历，两趟都要逐页 `GetPageHandle` + 解析字符叶子。第一趟为了判定「跨页重复」已经拿到全部结果，第二趟又重算一遍——52 页实测重复付 **132 ms（水印）/ 280 ms（页眉页脚）**，纯浪费。
- **根因 2（尺寸反复取）**：删除循环里每页都 `GetPageHandle` + `FPDF_GetPageWidthF/HeightF` 只为判边带，约 5.5 ms/页；识别的汇总循环又取一次。
- **根因 3（重活在主线程）**：整个删除跑在 UI 线程上，4.1–4.5 s 里 Dispatcher 完全停止泵消息，所以「假死」。真正的成本是 pdfium 的逐页 `FPDFPage_GenerateContent`（实测 86–155 ms/页，占删除时长 95%+），这部分无法消除，只能挪到后台并给进度。
- **修法**：① 新增 `_wmScanCache` / `_bandScanCache` + `ScanWatermarkPage` / `ScanBandPage`，识别侧改走缓存版本、删除侧直接命中，删除成功后 `DropScanCaches()` 作废；② 新增 `PageSizeAt`（`FPDF_GetPageSizeByIndex` 不加载 page handle，失败回退 `GetPageHandle`）并缓存，`CollectBandTexts` / `CollectTopWatermarkTexts` 顺手回填尺寸；③ 新增 `MainWindow.RunPagedEdit`：**>20 页**走后台 `Task` + `OcrProgressDialog`（模态、60 ms 轮询自动关窗、`ShowCancel=false` 关掉取消按钮因为内容流改动不可回滚，文案「正在删除水印… n/52 页」），≤20 页保留同步快路径避免闪窗。
- **验证**（Release，0 error 0 warning）：删除阶段收集文本 **132 / 280 → 0 ms**；页眉页脚识别 **459 → 315 ms**；删除总时长 水印 **4284 → 4101–4123 ms**、页眉页脚 **4785–5116 → 4447–4657 ms**。进度窗实拍 `PerfResults\v240-progress-a.png` / `v240-progress-b.png`：1.1 s 内由 `12/52` 推进到 `28/52`。回归 **SGM 页眉页脚 20/20、GD32 页眉页脚 21/21、水印 19/19** 全 PASS，原件 SHA256 未变。
- **留档坑**：`hfremove` 的识别侧一开始仍调 `CollectBandTexts` 而不是 `ScanBandPage`，缓存根本没被填 → 删除阶段 collect 依旧 280 ms（「改了但没生效」的典型）；`RunPagedEdit` 里 `work(_ => { })` 对 `Action<int,int>` 报 CS1593，必须写 `work((_, _) => { })`。

**修正｜删除页眉页脚在 SGM61231 上删不净：单字符碎片被长度过滤、页码带过窄、运行页眉被 40% 阈值挡掉**

- **现象**（17 页 SGM61231 数据手册）：删除页眉页脚后边带仍散落零散字符、页码、`PACKAGE INFORMATION`，要二次操作才干净。
- **根因 1（单字符碎片）**：排版把 `SGM61231` 拆成多对象，末位 `8` 与标题块里的 `B` 是**独立单字符对象**；识别/删除都要求 `norm.Length >= 2` → 直接漏掉（首版识别 146 处、残留 59 span）。
- **根因 2（页码带）**：`InPageNumBand` 写死距页顶 84%~92%，本文档页码在 **94.5%** → 无一进候选；验收脚本复用同一条带，出现「页码残留 0」的假 PASS。
- **根因 3（阈值一刀切）**：`PACKAGE INFORMATION` 在 14/16/17 页是整串、第 15 页被拆成 `PAC` + `KAGE INFORMATION`，整串仅 **3/17 页**，低于统一 40% 阈值 → 4 页运行页眉删不掉。
- **修法**：① `zoneShortFreq`（1 字符碎片 + 非页边数字碎片，阈值 ≥70% 页）并放宽删除侧 `targetNorms` 到 ≥1 字符（数字仅在 `Zone=="页码"` 时跳过）；② 「碎片包含」规则（已确认 ≥3 字符文案覆盖同带更短碎片，含单字符标点 `-`）；③ 页眉带阈值 `max(3, ceil(0.15×抽样页))`、页脚带留 40%；④ `PageNumHi` 0.92 → **0.985**；⑤ 新增 `IsBadgeShaped` 让 `TX00013.002` 这类每页不同的图纸编号走位置锚点；⑥ 确认框单字符碎片收成汇总行。
- **验证**（Release，0 error 0 warning，纯 UIA 脚本零键鼠注入）：识别 **146→172→211→216→222 处**、删除对象 **146→173→211→224 个**、产物 **892095→891755→891289→890772 字节**、边带残留 span **59→34→11→7→5→1**（仅封面独有 `ADVANCE DATASHEET` 保留）。UIA **20/20 PASS**：17 页、原件 SHA256 未变、图片 20 张保留、页码残留 0、正文命中 4 处仍在。回归 GD32 页眉页脚 **21/21**、水印 **19/19**。
- **取证**：`PerfResults\v239-sgm-hf-p2.png`、`v239-sgm-hf-p14.png`；新增无界面钩子 `hfremove`（识别→删除→保存→日志），便于「命中却不删」的实测定位。

**修正｜选文只能整词吸附、单击不落光标：去掉整词吸附改字符边界，补可见插入点与 Shift 扩选**

- **现象**（用户截图，GD32 第 28/52 页、217%）：在 `output` 中部拖一小段，整词被高亮；单词中间按下鼠标根本放不下光标，也选不出半个单词。
- **根因 1**：`PdfDocument.GetVisualSelection` 同排分支两端调 `SnapRowWordEdges(map, frags)` **硬吸附整词**（早期为对齐 Acrobat 双击整词手感），多排分支起止行用 `WordRange` 扩整词 → 无论鼠标落在哪，选区两端永远落在词边界，出现「只能选整个单词」。
- **根因 2**：`PdfPageView.OnMouseLeftDown` 选择工具分支单击只 `ClearSelection()`，没有记录光标位置也没有绘制插入点，用户看不到「光标在哪」。
- **修法**：① 新增 `PdfDocument.GetCaretBoundary(index, x, y, out Rect)`——按落点在字符框左半/右半给出边界索引（0..CharCount）与 1pt 宽、字高的光标矩形；同排取最近字符（`dy > max(6, 字高×1.2)` 排除）。② 新增 `BoundaryInFragment(map, f, x)` 把片段内横坐标映射成字符边界。③ `GetVisualSelection` 同排按 `[bLo, bHi)` 取字符、起止行按 `anchorFirst ? b..End : Start..b-1`，删掉 `SnapRowWordEdges`/`WordRange`。④ `PdfPageView` 增加 `_caretAnchor/_caretAt/_caretPage/_caretRectPage` 与 `DrawCaret()`（1pt 宽蓝线 `ARGB(230,38,132,255)`，`ClearSelection()` 一并清除、有选区时不显示光标）。⑤ 按下时先落光标（落不到字符再退 `GetCharIndexNear`），`Shift` + 已有光标从 `_caretAnchor` 扩选。
- **验证**（Release，0 error 0 warning）：`output` 中部起选 272→281 得边界 1108→1111、文本「utp」3 字（原整词 7 字）；`voltage` 中部 274→285 得 140→143、文本「lta」3 字；屏幕实拍 `PerfResults\v238-caret-halfword.png` / `v238-caret-zoom.png` 可见 `vol` 之后蓝色高亮带 + 边界竖线光标（半个单词选中）。视图坐标实测：选区 `598.28,169.55,18.67,14.45`、光标 `595.16,173.25,2.17,10.75`、画布 `1294x1831`、缩放 2.175；overlay 3 项且 `RenderSize` 非 0。
- **验收坑（留档）**：`PrintWindow(...,2)` 抓不到 WPF overlay，`CopyFromScreen` 抓到的是最上层窗口；探针加图元后必须 `UpdateLayout()`，否则 `RenderSize` 恒为 `0,0`（表现为「overlay 有子项但屏幕上什么都没有」）；`DrawSelection()` 在 `_selStart/_selCurrent` 为负时提前返回，探针只填 `_selRects` 是画不出选区的。

**修正｜「删除页眉/页脚」先是「未识别到」，改好后「页码删不掉」：包围盒重复乘矩阵 + 页码带被 zone 空值提前跳过 + 页码数值不可信**

- **现象**：用户截图显示点「删除页眉/页脚」弹「未找到本程序添加的页眉/页脚」；补齐第三方识别后页眉页脚能删净，但**页码一处没删**（245 命中只删 196）。
- **根因 1（决定性）**：`FPDFPageObj_GetBounds` 返回的**已经是页面坐标**。`WalkBandTexts` 又做了一次「父矩阵 ∘ 子矩阵」复合，页脚被推到 `CY≈106`（87%，落进版心）、页眉被推到 `CY≈1574`（−87%，负值碰巧落在页眉带）——页眉能认是巧合、页脚全漏。修法：直接用包围盒 `(l+r)/2`、`(bt+t)/2`、`|t−bt|`，不再乘矩阵。
- **根因 2**：识别与删除两处都有 `if (zone.Length == 0 || size > 24) continue;`，而页码位于 84%~92% 带、`ZoneOf` 对该带返回空串 —— 页码在校验前就被跳过。修法：改成 `(zone.Length==0 && !InPageNumBand(...))` 才跳过（删除循环同一处一并改）。
- **根因 3**：页码原判据「数字值 == 页号或页号+1」在该文档不成立——印刷页号与 PDF 页号不一致（第 3 页印 2、第 15 页印 5、第 25 页印 15），中段还分节重排。修法：改用**跨页位置锚点**（包围盒右边界 `X1` + 纵向中心 `CY`，需出现在 ≥70% 抽样页），命中/删除按 `X1±8pt、CY±5pt` 匹配；`BandText` 增加 `X0/X1`。
- **验证**：`ui_hf_remove_v1238.ps1` → `PerfResults\hf_remove_v1238.csv`，**21/21 PASS**：识别 245 处（4 组文案 ×49 页 + 页码 ×49），`删除页眉页脚: 第三方 245 个对象 / 49 页`，产物边带小字 span 0、页码残留 0、正文 83、图片 74、52 页，2439156 → 2484268 字节；水印回归 19/19 PASS。脚本侧同时修了三处口径（确认框按单词断言、残留只在边带内计数、新增「样本原件未被改写」SHA256 断言并把样本固定到 `PerfBench\data\GD32A511_src.pdf`）。

**修正｜删除水印按索引**升序**删对象，索引位移导致每页漏删一处（用户复现「第一次删不干净、再点一次才行」）**

- **现象**：GD32 样本（52 页 × 3 处斜排水印）点一次「删除水印」，状态栏「已删除 104 个水印（52 页）」，页面上仍残留粉色斜排字；再点一次才彻底干净。
- **根因**：`RemoveForeignWatermarks` 收集 `kill`（每页命中对象的 `TopIndex`）后**升序**逐个 `FPDFPage_GetObject(page, idx)` + `FPDFPage_RemoveObject`。`FPDFPage_RemoveObject` 成功后，同页后续对象索引整体前移 1，列表里下一个 `idx` 已经指向别的对象（或取到 0）→ 每页 3 处只删掉 2 处（104 = 52 × 2）。第二次点击时剩余对象重新编号成可命中，所以「再点一次」能清完。
- **修法**：`kill.Sort()` 后从末尾**倒序**删除，保证每个 idx 被取时仍对得上原对象；每页删完照旧 `FPDFPage_GenerateContent` 重建内容流。
- **验证**：`ui_wm_remove_v1238.ps1` 用 GD32 样本**单次操作** 19/19 PASS —— `删除水印: 第三方 156 个对象 / 52 页`（修复前 104）、状态栏「已删除 156 个水印（52 页）」、产物残留水印 0、斜排文本行 0、正文命中 83、图片 74 不变、52 页；SGM61231 回归同样 19/19 PASS（17 个对象 / 17 页，残留 0）。顺带把脚本三条日志断言由固定 `sleep 1.5s` 改成 `Wait-Log` 轮询（删除 52 页实测 ~6 秒）。

**修正｜水印识别只收「按词拆分」的归一化，整行水印识别 52 处却删掉 0 个对象**

- **现象**：GD32 样本（52 页，整句水印 `GD Confidential Preliminary For`，54pt、−55° 斜排）识别阶段正常报 52 处，点「是」之后日志写「删除 0 个对象」，产物字节数只少了几十 KB（图片重写所致），水印一处没少。
- **根因**：`targetNorms` 只把识别到的文案按 `Split(' ')` 拆成**单词**塞进集合，而删除阶段比对的是**整个文本叶子去空格后的整行**。整句水印在内容流里是一个叶子、没有词边界，`Set.Contains(整行)` 永远为 false → 匹配不上 → 删 0 个。
- **修法**：`targetNorms` 同时收**整行归一化**与**逐词归一化**（两者都要求 ≥3 字符），删除阶段仍按叶子整行比对；单词形态保留是为了兼容「水印被拆成多个叶子、每个叶子只有一个词」的样本（SGM 的 `TLED` / `BILATERAL` 属于这种）。
- **验证**：`ui_wm_remove_v1238.ps1` 用 GD32 样本复跑 19/19 PASS，`删除水印: 第三方 52 个对象 / 52 页`，2546432 → 2447172 字节，产物里整句水印残留 0。

**修正｜`FPDFPageObj_GetMatrix` 按「6 个 float\*」声明，导致第三方水印识别结果恒为空（本轮自查发现）**

- **现象**：第三方水印识别写完、编译通过，`删除水印` 弹出的确认框里一条命中都没有，日志里连「水印识别」行都不出现，产物里 `BILATERAL`/`TLED` 34 处一处不少。
- **根因**：`Native\Pdfium.cs` 把 `FPDFPageObj_GetMatrix` 声明成 `(nint, float* a, float* b, float* c, float* d, float* e, float* f)`，而 pdfium 原生签名是 `FPDFPageObj_GetMatrix(FPDF_PAGEOBJ*, FS_MATRIX*)`——**一个 24 字节结构体指针**。原生侧按结构体写入 6 个 float，实际落到调用栈上的是 6 个指针槽，矩阵值不可信（`a/b` 读成 0），文本叶子的角度/缩放全被算成 0 → 面积与字号判定一起失真 → 命中集为空。同一文件里 `FPDFPageObj_SetMatrix(nint, FS_MATRIX*)` 本来就是对的结构体写法，是可直接对照的旁证。
- **修法**：改为 `FPDFPageObj_GetMatrix(nint pageObject, FS_MATRIX* matrix)`（`FS_MATRIX` 就在 Pdfium.cs 第 46 行，a/b/c/d/e/f 全 float），`WalkWatermarkTexts` 改用 `Pdfium.FS_MATRIX m` 取 `m.a`/`m.b` 算角度与缩放。
- **验证**：修完首次复跑即从「识别 0 处」变成 `水印识别: 抽样 17 页，文本叶子 3362，跨页重复文案 16，命中对象 236`。

**修正｜只按「字号 + 跨页重复」识别，会把页眉页脚当成水印删掉（同一轮实测暴露）**

- **现象**：矩阵修好后命中 236 处、17 组，确认框里是 `BOOT` / `SGM61231` / `SG Micro Corp` / `micro.com`——全是每页都有的页眉页脚与型号名；点「是」会删 112 个对象，等于把页眉页脚清掉。
- **根因**：判定条件只有「归一化文案 ≥ 4 字 + 字号 ≥ 15pt + 出现在 ≥ 40% 抽样页」。正文里的厂商名、型号、页脚网址天然满足这三条；而字号是用包围盒高度 × 矩阵缩放近似（本机 pdfium 的 `FPDFTextObj_GetFontSize` 在 FORM 子对象上会 access violation，不能用），页眉里的大字会被算成 43~53pt，照样过门槛。
- **修法**：新增 `IsWatermarkLike()`——除字号 ≥ 15pt、文案 ≥ 4 字外，还要求 **「斜排 12°~75°」或「顶层对象包围盒占页面积 ≥ 15%」**；`CollectTopWatermarkTexts` 顺带返回每个顶层对象的 `AreaRatio`（`FPDFPageObj_GetBounds` 面积 ÷ `FPDF_GetPageWidthF * FPDF_GetPageHeightF`）。同时把「斜排」限制在 12°~75°，90° 竖排（`DD0001`/`DD0002` 这类表头竖排字）不再进候选。
- **验证**：命中从 236 处 / 17 组 → **17 处 / 1 组**；`水印识别页样例(第1页): #390 面积占比37% 字符「TLED」26pt…` 与其它对象（面积 0~1%）一眼可分辨。

**修正｜删完水印「保存」按钮仍是灰的，改动保存不下去（同一轮实测暴露）**

- **现象**：`删除水印: 第三方 17 个对象 / 17 页` 已打进日志，但 `SaveBtn` 仍是 `IsEnabled=False`，文件字节数一点没变（1005561 → 1005561），产物里水印还在。
- **根因**：`RemoveForeignWatermarks` 确实置了 `IsModified=true`，但收尾里 `OnAnnotChanged()` 会走 `TryClearDirtyIfBackToBaseline()`——水印不是标注，标注集合为空且「回到基线」，于是把 `IsModified` 复位成 false；`RefreshSaveButton()` 按 `_doc.IsModified` 取到 false，按钮保持灰。日志里 `水印刷新完成: IsModified=False SaveBtn=False` 是直接证据。
- **修法**：`RefreshAfterWatermarkChange()` 在 `OnAnnotChanged` **之前**就把 `tab.NonAnnotDirty = true` 且 `tab.Doc.IsModified = true`（与「旋转页面」「删除页面」同一口径），刷新后再 `RefreshSaveButton()`；并加一行 `水印刷新完成: IsModified=… SaveBtn=…` 便于回归断言。
- **验证**：`SaveBtn 启用=True`，保存后 1005561 → **897022 字节**，产物 `BILATERAL`/`TLED` 残留 0。

**修正｜验收脚本读 `StatusLeft` 的 UIA `Name` 永远拿到文件路径，状态栏断言假 FAIL（脚本自查）**

- **现象**：应用内状态栏确实显示「已删除 17 个水印（17 页）」（日志 `状态栏文本: 已删除 17 个水印（17 页）` 为证），但脚本每 100ms 轮询 `ById 'StatusLeft'` 的 `Current.Name`，抓到的始终是文件路径。
- **根因**：WPF `TextBlock` 的 `Text` 改了，UIA 侧元素句柄的 `Name` 缓存/身份不跟随（同类现象此前也踩过：主窗口按标题找窗口拿到的 `GetWindowText` 与实际 UIA `Name` 不一致）。
- **修法**：该断言改为读应用日志里的 `状态栏文本:` 行（应用自己报告的真实控件文本），UIA 读到的值只作为旁证写进证据列。
- **验证**：`ui_wm_remove_v1238.ps1` 18/18 PASS，证据列 `应用内状态栏=…状态栏文本: 已删除 17 个水印（17 页）；UIA 读到的 Name=`（空）。

**修正｜密码框「出路说明」与错误行挤在同一段红字里，读起来像第二个报错（自己看截图发现）**

- **现象**：密码错两次后，密码框里出现「密码不正确，请重新输入（区分大小写）。本程序不提供密码破解；如果这份文档来自他人，请向提供方索取打开密码。」——整段都是 `Th.Danger`，三行红字，用户理解成「又有两处错误」。
- **根因**：`ProtectionDialog` 的密码形态只有一个 `desc` TextBlock，`wrongPassword != null` 就把整段刷成红色；文案增加第二句后，两种语义（错误 / 说明）共用了一个颜色。
- **修法**：`wrongPassword` 按 `\n` 拆成错误行与说明行——错误行留在 `desc`（`Th.Danger`），说明行新建 `TextBlock`（`Th.TextMuted`、`FontSize 12`、`LineHeight 19`、`Margin 0,2,0,0`）插在密码框之前；`_passwordBox.Margin` 仍 `(0,6,0,0)`（说明行自己承担 2 DIP 间隙），对话框高度不变。
- **验证**：`ui_pw_hint_v1238.ps1` 8/8 PASS；截图 `PerfResults\v238-pw-hint.png` 575×335，一行红字 + 两行灰字。

**修正｜说明句过长，在 460 DIP 宽的密码框里折成三行、末行只剩「码。」（首版截图发现）**

- **现象**：说明写成「本程序不提供密码破解；如果这份文档来自他人，请向提供方索取打开密码。」时，第 3 行只剩「码。」，视觉上像排版错位。
- **根因**：一句话 30 余字，`TextWrapping=Wrap` 在对话框内容宽 460 DIP（字号 12）里放不下一行；折行落点又恰好切在「密/码」之间。
- **修法**：拆成两句独立短句「本程序不提供密码破解。」「如果文档来自他人，请向提供方索取密码。」，各占一行、都在边界内（放弃弹窗同样改这两行）。
- **验证**：重截 `PerfResults\v238-pw-hint.png`，两行灰字各一整行、无折行；`ui_pw_hint_v1238.ps1` 8/8（含「向提供方索取密码」子串断言）。

**修正｜串行回归里 `ui_stats_v1237` 假 FAIL：文件菜单一次 Expand 静默失败（自查发现）**

- **现象**：14 脚本串行回归出现 `ui_stats_v1237.ps1 8/12`，之后「手动已读落盘 / 最近菜单前缀 / 重启后手动已读」跟着连挂；单独复跑却 17/17。
- **根因**：上个脚本刚被强杀进程，主窗口还没拿到前台焦点时 `ExpandCollapsePattern.Expand()` 是空操作，`MenuReadingStats` 取不到；后续用例依赖菜单里点的那次「标记已读」，于是级联失败。
- **修法**：脚本在展开「文件」菜单前先 `SetFocus()`，并循环最多 3 次「SetFocus → Expand → 找 MenuReadingStats」，每次失败间隔 400 ms。
- **验证**：加固后单独复跑 17/17，14 脚本全量回归 `ui_stats_v1237` 17/17 PASS（总计 14/14、198/198）。

**修正｜打印预览把 2 页/张 压成细长条，看起来像打印会拉变形（用户截图反馈）**

- **现象**：打印设置对话框右侧预览，选「2 页/张（左右）」后两页变成两条竖长的窄条，观感像打印出来会被拉变形。
- **根因**：`PreviewPaper` 是 `private static readonly` 的 A4 **纵向** 794×1123 DIP，2×1 网格只能把两页挤进 210mm 宽。
- **修法**：改为 `PreviewPaperFor(PrintJob job)`——`Columns > Rows` 用横向 1123×794，否则纵向；小册子固定 2×1 自动横向。`TxtPreviewTip` 文案带方向，日志 `打印预览: … A4 横向/纵向 …（比例 r）`。
- **验证**：`ui_print_preview_v1238.ps1` —— 2 页/张 日志 `A4 横向 1123×794 DIP · 每张 2×1 · 位图 560×396px · 比例 1.414`（PASS）；截图 `PerfResults\v238-print-preview.png` 两页并排、比例正常。

**修正｜预览里页内被非等比拉伸：VisualBrush 未给 Viewbox**

- **现象**：纸面方向改对后，页内正文仍然横向/纵向压扁，与阅读器里看到的排版不一致。
- **根因**：`dc.DrawRectangle(new VisualBrush(page.Visual), null, ...)` 没设 `Viewbox`，VisualBrush 默认以**内容外接框**为源矩形映射到目标矩形；源比例（页边距内的正文）与目标比例（整张纸）不同即被拉伸。
- **修法**：`Stretch = Fill` + `ViewboxUnits = BrushMappingMode.Absolute` + `Viewbox = new Rect(0, 0, page.Size.Width, page.Size.Height)`，严格按整张纸等比映射。
- **验证**：`ui_print_preview_v1238.ps1` 每档断言「控件宽高比 = 位图比例 ±0.02」：1 页/张 `457×647px 比例 0.706`（位图 0.707）、2 页/张 `457×323px 比例 1.415`（位图 1.414），全部 PASS。

**修正｜横向预览纸右边被裁掉：Image 写死 `Height=430` + 外层 ScrollViewer 禁横滚**

- **现象**：选横向版式后预览只剩纸的左半，右侧被切平。
- **根因**：预览 Image 固定 `Height="430"`（宽 560 > 预览列 488），外层 `ScrollViewer` 又禁了水平滚动，超出部分直接看不见。
- **修法**：改成 `Grid x:Name="PreviewHost" ClipToBounds` + `Image Stretch="Uniform" StretchDirection="DownOnly"` 居中 + `HighQuality`，竖/横纸都整体缩放进可用空间；位图宽 `pw` 520→560。
- **验证**：每档断言 Image 矩形落在对话框内——实测 Image 右缘 **1483** / 对话框右缘 **1523**，下缘 548~817 均不越界（PASS）。

**修正｜多页合一 + 「实际大小（100%）」把大半页裁掉，打印出来同样被切**

- **现象**：「2 页/张 · 实际大小」的预览里左页正文左侧被切（第一版截图里 "GENERAL DESCRIPTION" 只剩 "RAL DESCRIPTION"）；这不是预览的错觉，真实出纸也一样。
- **根因**：`PrintSheetPaginator.DrawPage` 原 `fit = (Fit == ActualSize) ? 1.0 : min(...)`。格子 545 DIP 宽、Letter 页 816 DIP，100% 塞进格子后每页只剩约 60% 宽度，再由 `PushClip` 裁掉溢出部分。
- **修法**：`ActualSize` 且 `Columns * Rows > 1` 时 `fit = Math.Min(1.0, cellFit)`——不放大、可等比缩小、绝不裁切；1 页/张 仍严格 100%（超出纸面照旧裁切），`FitPage` 分支不变。
- **验证**：日志新增 `打印排版: … fit=… 落点 W×H DIP · 页面 W×H · 格子 W×H`（`Dpi <= 96` 才打），脚本逐页断言「落点比例 = 页面比例、落点不溢出格子」：2 页/张 `fit=0.703 落点 558×790（0.706/0.707）· 格子 558×794`、2 页/张上下 `fit=0.497 395×558`、4 页/张 `fit=0.496 394×557`（4 条全 PASS，合计 27/27）。

**修正｜预览横向版式与实际出纸方向不一致：打印时没写纸张方向**

- **现象**：预览按 A4 横向排版，实际打印仍按打印机默认纵向出纸，两页各占一半、位置全错位。
- **根因**：`MainWindow.OnPrint` 只写了双面（`ApplyDuplex`），从未把横向写进 `PrintTicket`。
- **修法**：新增 `ApplyOrientation(dlg, landscape)`，`Columns > Rows` 时把 `System.Printing.PageOrientation.Landscape` 写进 `PrintTicket` 并回写 `dlg.PrintTicket`；失败只记日志、按打印机默认方向继续，不阻断打印。
- **验证（局限）**：本机无实机打印，只能验到代码层与日志层（`打印: 纸张方向写入 横向（可打印区 W×H DIP）`）；虚拟打印机的实际出纸方向未逐台核验。

**修正｜`取消` 按钮没有 AutomationId，关闭用例假 FAIL（自测发现）**

- **现象**：`ui_print_preview_v1238.ps1` 首轮 21/22，唯一 FAIL 是「取消关闭对话框 仍存在=True」，手工点「取消」却正常。
- **根因**：`取消` 按钮在 XAML 里只有 `Content`、`IsCancel`，没有 `x:Name` 也没有 `AutomationId`，脚本 `ById 'BtnCancel'` 取到 `$null`，`Invoke-El` 静默返回 false。
- **修法**：补 `x:Name="BtnCancel"` + `AutomationProperties.AutomationId="BtnCancel"`。
- **验证**：复跑 22/22，`取消关闭对话框 PASS 仍存在=False`。

**修正｜高分屏 / 副屏上整窗被系统当位图拉伸，页面永远按旧比例渲染（本批适配发现）**

- **现象**：125% 屏上页面文字偏软；把窗口拖到另一块缩放不同的显示器后，整窗像贴图一样被拉大，页面位图不重新渲染。
- **根因**：工程**没有任何应用清单**（`xcPDFReader.csproj` 无 `ApplicationManifest`、根目录无 `.manifest`），.NET 桌面程序按「系统 DPI 感知」启动（`GetProcessDpiAwareness = 1`）。系统把窗口整体位图缩放，WPF 因此收不到 `DpiChanged`。
- **修法**：新建 `app.manifest`（`PerMonitorV2,PerMonitor` + `true/PM` + `longPathAware` + supportedOS），csproj 加 `<ApplicationManifest>`；`MainWindow` 订阅 `DpiChanged`，比例真变时重渲染已实现页视图并作废缩略图缓存。
- **验证**：`ui_dpi_v1238.ps1` —— exe 字节含 `PerMonitorV2`、`GetProcessDpiAwareness = 2`、`GetDpiForWindow = 120 = 系统 120`（PASS）。

**修正｜缩略图在高 DPI 下发虚：按 DIP 渲染却被物理像素显示**

- **现象**：125% 缩放下侧栏缩略图字迹糊成一片，页面清晰、缩略图不清晰。
- **根因**：`RenderThumbAsync` 用 `scale = ThumbWidth / 页宽`、`RenderPage(..., 96.0, ...)`，位图只有 84 像素宽，却显示在 84 DIP（125% 屏 = 105 物理像素）的位置上，固定被放大 1.25 倍。
- **修法**：按 `VisualTreeHelper.GetDpi(this).DpiScaleX` 放大 `scale`，位图 DPI 同步写 `96 * dpiScale`（Image 仍按 DIP 布局，尺寸不跳）。
- **验证**：日志 `缩略图渲染: 84 DIP → 105×149px @ 120 DPI（缩放 1.25×）`，px/DIP = 1.25（旧实现为 0.8）。

**修正｜对话框一律按主显示器工作区定位，主窗口在副屏时被拽回主屏（本批适配发现）**

- **现象**：主窗口放在副屏（尤其是主屏左侧的负坐标副屏）时，印章面板 / 文档属性 / 对比窗口会跑回主屏，甚至算出屏幕外坐标。
- **根因**：`DialogCentering`、`StampDialog`、`DocumentPropertiesDialog`、`CompareWindow` 四处都用 `SystemParameters.WorkArea`——它恒返回**主显示器**工作区；夹紧时还拿 `workArea.Width/Height` 当右/下边界、`Math.Max(0, ...)` 归零。
- **修法**：新建 `Ui\MonitorWork.cs`（`MonitorFromWindow` + `GetMonitorInfoW` + `GetDpiForWindow`），提供 `WorkAreaDip / WorkAreaDipOfHwnd / DpiScaleOf / ClampInto / CenterOnOwner`；四处对话框改用它，`ClampInto` 以 `work.Right/Bottom` 为边界且工作区小于窗口时贴左上。
- **验证**：`test_monitor_work.ps1` 5/5（副屏在右 3900→3440、副屏在左 -2200/-40→-1920/0、工作区小于窗口→0/0、可见不动 2100,700、副屏在上方 -1200→-1040）；`ui_dpi_v1238.ps1` 印章面板 `1180,118 400×342` 完整落在 `0,0 1920×1020` 工作区内。

**修正｜启动期同比例 `DpiChanged` 把页面与缩略图整批重渲染一遍（本次自测发现）**

- **现象**：日志里每次启动都出现一条「DPI 变化: 1.25×1.25（120 DPI）」，紧跟一次页面重渲染 + 缩略图重渲染；打开文档的首屏因此白多花一次渲染。
- **根因**：`DpiChanged` 在窗口首次显示到目标显示器上时也会触发，首次基线（`SourceInitialized` 时 `GetDpi` 还可能返回 96dpi）与真实比例不一致，被当成「变化」；启动期实测连发两次同比例事件。
- **修法**：`OnDpiChanged` 第一个事件只记基线直接返回；之后用 0.001 容差挡掉同比例事件；基线改在 `Loaded` 里记录（那时窗口已进入真实 DPI 上下文）。
- **验证**：复跑日志中启动后不再出现「DPI 变化」，页面与缩略图各只渲染一次。

**修正｜`autopopup` 启动 hook 从不执行，选区快栏验收是稳定的假 FAIL**

- **现象**：UIA 脚本用 `autopopup` 启动程序，永远看不到选区弹层。
- **根因**：hook 在 `Loaded` 里判 `_doc?.PageCount > 0`，而文档是异步加载的，`Loaded` 时还是 0 页 → 条件恒假，`DebugSelectFirstWord()` 一次都没调过。
- **修法**：改为 200ms `DispatcherTimer`（`Background` 优先级，最多 30 次≈6s）轮询到有页再 `Stop()`，先 `Activate()` 把窗口提到前台（后台进程的 `Popup` 以 `StaysOpen=false` 会把「失焦」当点击外部自关），再取第 1 页视图触发选词。
- **验证**：`probe_selbar.ps1` 探到 `Popup rect=1455,404,394×58`；`ui_selbar_copy_last_v1238.ps1` 8/8。

**修正｜`复制本页表格` 只写纯文本，粘到 Word / 飞书里不是表格**

- **现象**：菜单写着复制表格，粘出来是 Tab 隔开的纯文本，没有边框与单元格。
- **根因**：`OnCopyPageTable` 只 `Clipboard.SetText(tsv)`，剪贴板里没有 `HTML Format`。
- **修法**：一次写三格式——`DataFormats.Html`（CF_HTML，偏移按 UTF-8 字节计）、`UnicodeText`（TSV）、`Text`；新增 `Table.ToHtml()` + `EscapeHtml`，`BuildCfHtml()` 生成 `Version:0.9` + 4 个 10 位定宽偏移头。
- **验证**：`ui_table_html_v1238.ps1` 8/8（`<table>` 1、`<th>` 6、`<td>` 120、`StartHTML=105`、`StartFragment=174`、`EndFragment=9288`）；`ui_table_word_paste_v1238.ps1` 6/6（Word `Tables.Count=1` 21×6、Excel `UsedRange 21×6`、首格 `SGM2036S-0.75`）。

**修正｜旧脚本日志正则里的 `HTML+TSV` 没转义，`+` 被当量词 → 假 FAIL**

- **现象**：`ui_term_table_v1236.ps1` 明明功能正常，日志断言却红。
- **根因**：正则 `HTML+TSV` 里 `+` 是「前一个字符重复一次以上」，实际日志是字面 `HTML+TSV`，匹配不到。
- **修法**：转义成 `HTML\+TSV`；同时把菜单名断言从「复制本页表格」改为「复制为表格」。
- **验证**：复跑 12/12 PASS。

**修正｜`工具 ▸ 文字印章` 只切了工具，没弹「选择印章」，放不出章（自测发现）**

- **现象**：工具栏 `ToolStamp` 点下去会弹选择面板；从菜单 `工具(O) ▸ 文字印章` 进去却什么都不弹，之后在页面上点一下也没有章落下去。
- **根因**：`OnMenuTool` 直接调 `SelectTool(tag)`，只把 `CurrentTool` 置成 `ToolMode.Stamp`，既没弹 `StampDialog`，也没写 `_pendingStampText` / `_pendingStampColor`。页视图拿不到印章文字，落章路径走空。
- **修法**：`OnMenuTool` 改调 `ActivateToolFromTag(tag)`——它内部对 `Stamp` 特例走 `OnToolClick(按钮, new RoutedEventArgs(Button.ClickEvent))`，与工具栏点击完全同一条链路（包含取消时回落 `ToolMode.Select`）。
- **验证**：`ui_a11y_v1238.ps1` 通过菜单 `工具(O) ▸ 文字印章` 打开「选择印章」面板，8 个印章格子名/Id/初始焦点全部 PASS。

**修正｜印章面板打开后键盘焦点不在第一个印章（键盘可达需求引入，自测发现）**

- **现象**：面板弹出后按 Tab 不知道从哪开始，读屏只念一句窗口名「选择印章」。
- **根因**：第一版在构造函数里 `Loaded += ... => firstStampButton.Focus()`。`ShowDialog` 期间 `Loaded` 可能早于窗口真正激活，此时 `Focus()` 静默失败（返回 false，不抛异常），焦点留在窗口本身。
- **修法**：`Loaded` 里改成 `Dispatcher.BeginInvoke(..., DispatcherPriority.Input)` 延后到输入优先级执行，并在 `Activated` 里再补一次「若第一个印章还没拿到键盘焦点就 `Keyboard.Focus`」。两处幂等，窗口只能激活一次，不会重复抢焦点。
- **验证**：`ui_a11y_v1238.ps1` 的「印章面板打开后焦点落在第一个印章」PASS（聚焦 Id `StampItem_1`）。
- **教训（写进脚本注释）**：UIA 侧断言这个用例时，**Invoke 菜单项之后不要 `Collapse()` 父菜单**——收起菜单会把键盘焦点拽回菜单项，面板初始焦点就丢了，是一条稳定的假 FAIL（本机复现 4 次）。

**修正｜侧栏「页面」页签没有 `x:Name`，自动化脚本切不过去（脚本侧暴露的可用性缺口）**

- **现象**：`ByName '页面'` 先命中的是页签头里的 `TextBlock`（没有 `SelectionItemPattern`），`Select()` 静默失败，缩略图列表永远找不到。
- **根因**：另外两个页签 `OutlineTab` / `CommentTab` 都有 `x:Name`，只有第三个（页面/缩略图）是裸 `<TabItem>`，UIA `AutomationId` 为空。
- **修法**：`MainWindow.xaml` 给它补 `Name="ThumbTab"` 与 `AutomationProperties.Name="页面"`。
- **验证**：`ThumbList` 与 `ThumbItem_1/2` 全部 PASS（名称「第 1 页 / 第 2 页」、`IsKeyboardFocusable=True`）。

**修正｜图标按钮在 UIA 里没有名称（39 个可见控件名字为空）**

- **现象**：全局扫描主窗口，可见的 Button/ListItem/TreeItem 里有 39 个 `Name` 为空，读屏只会念「按钮」；典型如 `SaveBtn`、`SaveAllBtn`、`CommentFilterBtn`。
- **根因**：这些按钮「Content 是自绘 `Path`」，WPF 自动名称推导拿不到文本；工具提示（`ToolTip`）是有的，但 `ToolTip` 不会自动变成 `AutomationProperties.Name`。
- **修法**：新增 `ApplyToolTipAsAutomationName(root)`，启动 `Loaded` 时遍历可视树把 `ToolTip` 升格为 `Name`（已显式设过 Name 的不动，例如缩略图项、标注卡片）；切侧栏页签后再由 `ScheduleA11yNameSweep()`（600ms 一次性 `DispatcherTimer`）补一轮，因为页签内容是切过去才实例化的。
- **验证**：同一条全局扫描用例由「空名称=39」→「空名称=0」。
- **注**：扫描刻意排除 `DecBtn` / `IncBtn`（`ScrollBar` 模板里的 PageUp/PageDown 透明命中层）——它们属于 `ScrollBar` 控件模式的内部骨架，不需要单独命名，把它们算进「无名按钮」是脚本的误报。

**修正｜10 个 UIA 脚本把版本号写死，换个版本就集体变红（工程化问题）**

- **现象**：`ui_stats_v1237` 之类脚本断言 `-match '1\.2\.237'`，跑 1.2.238 时启动用例直接 FAIL；再加上脚本里固定的 `Start-Sleep`，本地跑一轮结果不可信。
- **修法**：① 断言统一放宽成 `1\.2\.\d+`（10 个脚本）；② 新建 `PerfBench\uia_common.ps1` 收敛「杀残留 / 启动等窗口 / 按名或 Id 轮询查找 / Invoke·Select·Toggle / 打开菜单 / 读 `TitleBarText`」；③ 新建 `run_ui_acceptance.ps1` 串行 runner：每脚本前清 `XC PDF Reader` 残留、子进程执行、超时杀进程、汇总 CSV。
- **验证**：runner 跑默认验收集，逐脚本输出 `PASS  n/n`，汇总见 `PerfResults\ui_acceptance_summary.csv`。


**修正｜StarDict 释义把内嵌例句全挤进释义，气泡里看不到「典型用法」（库级自测发现）**

- **现象**：导入自建 StarDict 后，`Lookup('voltage')` 返回的 `Definitions` 里既有释义也有 `例 …` 行，整段挤在一起；「典型用法」一栏永远为空。29 条库级用例因此红 2 条（27/29）。
- **根因**：`.dict` 的 `m` 段是纯文本，原词条里「释义」和「例 …」靠换行分隔，第一版直接把整段当释义（`Definitions = 全部分行`），没做拆分。
- **修法**：新增 `SplitMeaning`，一次拆三段：以「例 / 例句 / e.g. / eg. / ex. / example」开头的行归「典型用法」；首行是 `[...]` 或 `/.../` 且长度 ≤48 字符时识别为音标；释义最多 6 行、用法最多 3 行，超出截断（气泡高度有限）。
- **验证**：同一条用例由 27/29 → **29/29**，`电压 (V)` 释义不再带 `例` 行，用法一栏出现 `例 3.3 V 到 5.5 V 输入`。

**修正｜打开查找栏的瞬间，「清除输入」刷子会先闪一帧（自测发现）**

- **现象**：输入框里还留着上次的搜索词时，按 `Ctrl+F` 打开查找栏，刷子先可见、随后才被隐藏，能看到一次闪烁。
- **根因**：`OpenSearchBar()` 先把 `SearchBar.Visibility = Visible`，此时 `SearchBox` 里的旧文本已经存在，但 `UpdateSearchClearButton()` 只在 `TextChanged` 里调用——文本没变就不会触发，要等 `SelectAll()` 之后那一次手动刷新才纠正。
- **修法**：`OpenSearchBar()` 在置为可见**之前**先调一次 `UpdateSearchClearButton()`（末尾 `SelectAll()` 之后再调一次兜底），这样第一帧就是正确的可见性。
- **验证**：`ui_search_clear_v1238.ps1` 的「空输入时按钮不在 UIA 树」用例 PASS（`Collapsed` 控件不进 UIA 树），12/12 全绿。

**限制｜Win11 保存对话框不能靠 `WM_SETTEXT` 填自定义路径（测试脚本问题，非产品 Bug）**

- **现象**：脚本导入词典能成功，导出却总写到默认路径 `桌面\生词本.md`，即便已经把绝对路径 `WM_SETTEXT` 到文件名框（`SetPath` 也返回了 True）。
- **根因**：Win11 通用对话框的文件名是 `ComboBoxEx32 > ComboBox > Edit`，UIA 侧既没有 `ValuePattern`（只有 `Pane autoid=1148`），`GetWindowText` 回读还总是空串，无法判断是否真的写进去了。实测结论：`WM_SETTEXT` 对「打开(Open)」对话框有效，对「保存(Save)」会被组合框回退成默认名。
- **处置**：不为了测试去改产品。导出用例改为**默认导出路径端到端**（备份/删除桌面 `生词本.md` → 点导出 → 只点「保存」→ 断言文件与内容 → 删除并还原备份）；自定义路径能力由库级 `ExportMarkdown(path)` 用例覆盖。用例总数由 19/22 → **22/22**。
- **复跑注意**：脚本会备份并还原 `%AppData%\PdfReader\{vocab.json,prefs.json}` 与桌面 `生词本.md`，跑之前先确认没有残留的 `XC PDF Reader` 进程。

**修正｜打印带批注时，文本框批注只印出边框、没有文字（新功能自测发现）**

- **现象**：打开「打印批注」后打出来的页面，高亮、墨迹、图章都在，但自己加的文本框只剩一个空框，里面的字没了。
- **根因**：本程序在渲染页面位图时**临时隐藏 freetext 标注**（本地 pdfium 缺外观流生成，不隐藏就会画出一个不受控的默认边框），文字与边框改由页面视图的 WPF 覆盖层绘制。打印走的是同一条渲染路径，却没有覆盖层，所以文字自然丢失。
- **修法**：`PrintSheetPaginator` 在画完页面位图后，用 `PdfDocument.GetFreeTextOverlayText` 拿到该页所有文本框的「页面坐标 + 文字 + 字体 + 字号 + 颜色」，按打印缩放/翻转换算后自己画一遍（复用 `FreeTextFonts.Map`，与屏幕同字体）。单个文本框绘制失败只跳过该框，不影响整页。
- **验证**：`test_print_layout_lib.ps1` 的批注透传用例 `PrintAnnotations=False`；界面用例里「取消勾选打印批注」后摘要变为「不含批注」。真实纸张输出无法自动化比对，已在更新日志里标注。

**修正｜打印设置每次都要重新点一遍（体验缺陷）**

- **现象**：同一份文档连打两次，第二次还得把每张几页、边距、质量重新选一遍；双面更是每次都要进打印机属性。
- **根因**：`PrintSettingsDialog` 每次构造都把控件重置成固定初值，没有任何持久化。
- **修法**：`AppPrefs` 增加 10 个 `Print*` 字段；对话框 `OnClosed`（确定与取消都走这里）统一保存当前控件状态并 `Save()`，构造时 `RestoreFromPrefs()` 还原。写着失败被 try/catch 兜住，绝不阻断打印。
- **验证**：`ui_print_v1238.ps1` 改完设置点「取消」，重新打开后 5 项设置全部还原，`prefs.json` 里 7 个关键字段实测落盘（24/24 PASS）。

**限制｜双面只能验到 PrintTicket 层（硬件相关）**

- **说明**：`ApplyDuplex` 把 `Duplexing = TwoSidedLongEdge / TwoSidedShortEdge` 写进 `PrintDialog.PrintTicket`，写入失败时提示「当前打印机不支持所选的双面模式，将按单面输出」并继续打印。真实翻转由打印机驱动与硬件完成，自动化只能验到这一步；`ApplyDuplex` 的异常分支没有实机复现（本机驱动无法构造不支持双面的场景）。

**修正｜中文文字拖选只能整段选，鼠标点不到单个字（用户实测反馈）**

- **现象**：在中文正文上按住拖动，无论从哪里起、到哪里放，一整句都被选中（截图里恰好是「栅极驱动器以及隔离式电」这一整段）；想只选其中三四个字、或者把光标式的选区收窄，做不到。西文正常。
- **根因**：视觉选区的两端做了「整词吸附」（`SnapRowWordEdges` / `WordRange`），词边界只按**空白字符**判定。中文没有空格，一整句中文在字符序列里就是一个「词」，于是吸附把选区两端都拉到句子边界——拖选精度退化成整行/整段。
- **修法**：`WordRange` 增加中日韩判定（新增 `PdfDocument.IsCjkChar`，覆盖 CJK 统一表意文字基本区/扩展 A/兼容区、假名、注音、谚文、CJK 标点与全角 ASCII）：命中汉字/假名/谚文时**该字自己就是一个词**，不做横向扩展；西文仍按空白整词吸附。`PageTextMap` 增存每字符码位（`Uni`），判定不需要再回到 pdfium 取字符。
- **效果**：中文拖选精确到字，两端不再外扩；西文双击/拖选仍按整词，行为不变。
- **验证**：`PerfBench\test_selection_cjk.ps1`（库级，直接调 `GetVisualSelection`，用 `GetSelectionRects` 取每个字中心构造拖拽带）→ `PerfResults\selection_cjk_v1238.csv`，**7/7 PASS**：中文第 2 页 19 字长句里从第 2 字拖到第 5 字，实测只选中 4 字「压和电流」（旧行为会整段 19 字）；单字起落实测选中 1 字「和」；跨行（首「重」→ 尾「成」）实测 41 字且首尾都精确到字；西文 `Dropout` 从中间起拖仍吸附成整词。
- **没验的部分**：本机铁律禁止鼠标/键盘注入，所以没有在真实窗口里用鼠标拖一遍；库级用例走的是与鼠标拖拽完全相同的入参（起点/终点页面坐标 + `GetVisualSelection`），选区算法一致。

## 2026-11-17 V1.2.237

**修正｜阅读计时用 `IsActive`，多屏 / 非前台阅读被统计成 0 秒（自测发现）**

- **现象**：第一版计时条件是 `IsActive && 未最小化`。自动化跑 24 秒后 `TotalSeconds=0`（对话框里也只有 10 秒），但用户确实把它开着读。
- **根因**：`IsActive` 只看键盘焦点。用户把阅读器放在第二块屏、或一边读一边在别的窗口操作时，窗口 `IsActive=false`，计时器一个周期都不计。**这不是自动化特例，是真实使用场景**：任何人「分屏读 PDF」都会得到 0 秒统计。
- **修法**：判据改为「窗口可见 + 未最小化」（`WindowState != Minimized && IsVisible`）。
- **代价（已写进更新日志）**：窗口被压住时也计时，口径变成「文档打开时长」而非「专注阅读时长」；相比「读了半小时显示 0 秒」，这个偏差用户更容易接受。
- **验证**：同一脚本 24 秒后 `TotalSeconds=25`，页标记也恢复正常（`bit0=True`）。

**修正｜落盘节流 20 秒 + 打开不落盘，进程被强杀时丢记录（自测发现）**

- **现象**：第一次跑完重启，`OpenCount` 还是 1（应为 2），`ManualRead` 为空——前一次运行的打开记录整条丢了。
- **根因**：打开只把 `OpenCount` 加在内存里，依赖 20 秒节流的 `SaveSoon()`；脚本（以及用户直接关掉进程 / 崩溃）在 20 秒内结束进程，改动就没落盘。
- **修法**：① `RecordOpen` 之后立即 `Save(force:true)`（打开是低频事件，一次多写一个小文件可忽略）；② 节流窗口 20s → 5s，与计时周期对齐，最坏丢 5 秒。
- **验证**：`Stop-Process -Force` 强杀重启后 `OpenCount=2，TotalSeconds=35，ManualRead=True` 全部保留。

**修正｜UIA 找不到带 Owner 的「阅读统计」窗口（脚本自身问题，非产品 Bug）**

- **现象**：脚本按「桌面根节点的子窗口 + 标题=阅读统计」查找，6 秒超时；手动看窗口明明弹出来了。
- **根因**：WPF 里 `Owner` 已设置的窗口，在 UIA 树中**不单独成为顶层窗口**，而是作为 `ControlType.Window` 嵌在**主窗口的子树**里（与 `TextInputDialog` 那类自绘窗同样的坑）。
- **修法**：改为「主窗口子树 + `Name=阅读统计` + `ControlType=Window`」定位；截图改用该元素的 `NativeWindowHandle` 单独 `PrintWindow`（主窗口的 PrintWindow 不含子窗口）。另：菜单被 `Invoke` 用过一次后 UIA 的 `ExpandCollapseState` 可能与真实 Popup 脱节，展开前先 `Collapse()` 再 `Expand()`。
- **验证**：17/17 PASS，对话框截图 `v237-stats-dialog.png`（950×675）。

## 2026-11-17 V1.2.236

**修正｜增量保存的体积闸门过严，等于白白扔掉 3~4% 的体积收益（开发中自测发现）**

- **现象**：`SGM2036S.pdf` 加一个小矩形后保存，日志写 `回退全量（增量结果 1451.0KB 超出闸门 1391.8KB…）`，最终落盘 1516.7KB。但增量结果 1451.0KB 其实**比全量更小**——闸门把更好的解给否掉了。
- **根因**：`IncrementalSizeTolerance = 1.10` 只拿「原文件 + 10%」当唯一标准，没有和「整份重写会多大」比较。增量 = 原字节 + 追加，必然 ≥ 原文件；而对压缩过的源文件，整份重写往往 +20%，两者的大小关系是**增量可能更大也可能更小**。
- **修法**：超闸门时再序列化一次全量，**二者取小**（并且选中的那份必须过 `ValidateSnapshotLength` 可开性校验）。
- **验证**：改前 `+251.4KB（+19.87%）`，改后 `+185.7KB（+14.68%）`，少写 65.7KB；MPS 样本从整份重写变成 `+88.0KB（+5.75%）`。

**修正｜表格识别把双栏正文和竖排文字也当表格（自测发现，输出全是噪声）**

- **现象**：第一版算法在 `SGM2036S.pdf` 第 1 页输出 `39 行 × 11 列`，内容是 `S G M 2036S` 这种单字母拆列 + 双栏正文；第 10 页的竖排特性图输出成每行一个字。
- **根因**：① 用「平均字宽」定切词阈值，实际 pdfium 的字框比字形紧，字间距 1~1.8pt 被误判成词间距，字母被空格拆开；② 只要「有列间隙」就算表格，双栏排版天然有两列、竖排文字天然逐字对齐，都会命中。
- **修法**：① 切词 / 切列阈值改为按**字高中位数**取比例（0.45 / 1.6），并先切词再切单元格；② 增加**列对齐**要求（单元格左边界聚类，至少 2 列、且在 ≥30% 成表行重复出现）；③ 两条反例闸门：`≤2 列且单元格中位 ≥35 字` 判双栏正文，`单元格中位 ≤2 字` 判竖排。
- **验证**：同一文档第 1 页 → `疑似双栏正文（2 列，单元格中位 44 字）`；第 10 页 → `疑似竖排 / 单字排版（单元格中位 1 字）`；第 2 页 → 21 行 × 6 列，首格 `SGM2036S-0.75`（序号、封装、温度、订购编号、打标、包装 六列齐全）。

**修正｜UIA 验收脚本定位不到自绘对话框 / 主窗口（脚本自身问题，非产品 Bug）**

- **现象**：`ui_term_table_v1236.ps1` 首轮 7/9，报「6s 内未见输入对话框」「清除术语高亮 FAIL」；另一轮报「25s 内没找到主窗口」。
- **根因**：① `TextInputDialog` 是 `WindowStyle=None + AllowsTransparency` 的自绘窗口，在 UIA 里**不单独成为顶层窗口**，它的 Edit / Button 挂在**主窗口的子树**里，按「进程的第一个顶层窗口」取会取到主窗口，写进去的是查找框；② 主窗口标题只显示文件名（`SGM2036S`），用 `XC PDF Reader` 匹配标题必然失败，判定主窗口只能靠 `AutomationId=TitleBarText`。
- **修法**：对话框改为「等 `确定` 按钮 + Edit 数量 ≥2 出现」，并按 `BoundingRectangle.Height` 取最大的那个 Edit（内容框 78px / 作者框 24px）；主窗口按 `TitleBarText` 的 AutomationId 探测；跳页改用底栏 `NavNextPage` 的 `InvokePattern`（缩略图 `SelectionItemPattern.Select()` 不触发 `SelectionChanged`，页不跳）。
- **验证**：同一脚本 12/12 PASS。

## 2026-11-17 V1.2.235

**修正｜「禁止复制 / 打印」的限制提示从不弹出（权限位按有符号数读，P1）**

- **现象**：打开 `no_copy.pdf`（无密码、禁止复制打印）和 `print_only.pdf`（无密码、仅禁止打印），文档直接打开，**没有任何「去除保护 / 忽略」提示**，日志也没有 `文档保护提示:` 行。而「需要密码」的文档能正常弹密码框，看起来像「只有密码路径通了」。
- **根因**：`Native\Pdfium.cs` 把 `FPDF_GetDocPermissions` 声明成 `int`，而 pdfium 返回的是**无符号**权限位：权限全开是 `0xFFFFFFFC`，受限是 `0xFFFFF7E0` / `0xFFFFF7F8`。按 `int` 读全部变负数，`Pdf\PdfProtectionInfo.From` 里「`perm >= 0` 才解析，否则当作全部允许」的保底逻辑因此对**所有受限文档**生效，`Blocked` 恒为空 → `HasRestrictions == false` → `MainWindow.CheckProtectionOnOpen` 在限制分支直接 `return`。
- **修法**：`FPDF_GetDocPermissions` 与 `PdfDocument.Permissions` 改 `uint`；未加密哨兵由 `-1` 改为 `0xFFFFFFFF`；`PdfProtectionInfo` 用 `perm != 0xFFFFFFFFu` 判断并按 `(uint)bit` 做位与。
- **验证**：先写 `PerfBench\probe_pdfium_perm.py`（ctypes 直连 `pdfium.dll`）量出四个样本的真实权限位（`pw_simple 0xFFFFFFFC` / `pw_restricted` 与 `no_copy 0xFFFFF7E0` / `print_only 0xFFFFF7F8`），确认是符号问题而非样本问题；修后 `ui_protect_v1235.ps1` 11 用例 11 PASS，`no_copy.pdf` 列出 4 项禁止（含「禁止复制 / 提取文字」），`print_only.pdf` 只列 2 项打印类限制。

**修正｜验收脚本的密码输入方式（脚本自身问题，非产品 Bug）**

- **现象**：脚本用 `SendKeys` / 剪贴板 `Ctrl+V` 往密码框打字后，日志仍是「第 2 次尝试：此文档已加密，需要输入密码才能打开」（即密码为空），第 3 次则变成「密码不正确」——看起来像密码校验逻辑坏了。
- **根因**：本机前台长期被用户其它应用占用，即使 `SetForegroundWindow` 校验通过，注入的字符也会被 Windows 输入法候选窗截走（本项目此前也遇到过「文本框第一次 ESC 被输入法吞掉」）。真正的问题是**测试手段**，不是被测代码。
- **修法**：WPF `PasswordBox` 在 UIA 里是 `ControlType.Edit` 且支持 `ValuePattern.SetValue`，改用 `ValuePattern` 写入密码，整轮验收不再发鼠标、不再注入按键、不再抢前台。

## 2026-11-17 V1.2.232

**修正｜拖选起手不取键盘焦点 → 选中后 Ctrl+C 复制不到（验收中新发现，P1）**

- **现象**：在页码框输入页码跳页（或刚用完查找框）后，直接在正文拖选文本并 `Ctrl+C`，剪贴板不动；重新单击一下正文区域再选又能复制。表现为「复制时好时坏」。
- **根因**：`Controls\PdfPageView.cs` `OnMouseDown` 的 `ToolMode.Select` 分支建立选区时只调用 `CaptureMouse()`，没有把键盘焦点收回到页视图。焦点仍留在 `PageNumberBox`（`TextBox`，`SetFocus()` 由跳页流程设置），`Ctrl+C` 被该编辑框内部消费，`MainWindow.OnKeyDown` 中 `Ctrl+C → CenterPageView.CopySelectionToClipboard()` 分支从未进入。
- **修法**：`_dragging` 成立时先 `Focus()` 再 `CaptureMouse()`。
- **验证**：`PerfBench\ui_verify_v1232.ps1` 选区扫描用例，修前同条件 15 个起点 **0 个**能复制（剪贴板一直为哨兵值），修后 **14/15** 成功，首个样本 `GENERAL DESCRIPTION`（截图 `v232-sel-scan.png`）。

**修正｜拖选起点落在行间空白即「完全没反应」（容差 5pt，操作不便第 1 条）**

- **现象**：在行间空白 / 图注间隙按下拖动，不产生选区也无任何提示，用户第一反应是「不能选字」。
- **根因**：起点命中走 `Document.GetCharIndexAt(..., 5.0)`（5 个页面点，224% 下约 11px），返回 -1 时 `_dragging = false` 并直接 `ClearSelection()`。
- **修法**：`Pdf\PdfDocument.cs` 新增 `GetCharIndexNear(index, x, y, maxDx = 8.0, maxDy = 14.0)`：扫描该页字符框，按 `score = dy*3 + dx` 先保行、再保水平距离取最近字符（>2 万字符时截断保护）；`OnMouseDown` / `OnMouseMove` 的 Select 分支改为 strict → loose 两级回退，越过行间空白不再断档。同时补两条诊断日志（宽松命中 / 完全未命中）。
- **验证**：第 1 页 y=585~800 步长 15 的 15 个起点，14 个拖出选区，其中 **4 次**日志命中 `选区起手: 严格命中失败 → 宽松命中 charIndex=…`，证明宽松路径确实在起效（不是所有起点本来就能命中）。

**修正｜选区浮动工具条在 UIA / 读屏里全是无名元素（操作不便第 2 条，无障碍）**

- **现象**：7 个格子（复制文本/高亮/下划线/删除线/波浪线/添加注释/AI 划词翻译）读屏念不出、脚本也无法驱动。
- **根因**：`SelTile` / `SelIconTile` / `SelNoteTile` / `SelMenuTile` 返回 `Border`，只设 `ToolTip`，没有 `AutomationProperties.Name`、没有可聚焦语义。
- **修法**：统一改为 `Button` + 自建扁平模板 `SelTileTemplate()`（圆角 Border + ContentPresenter，`IsMouseOver` 换 `PopupHoverBrush`，`IsKeyboardFocused` 白色 1px 边框），`ToolTip` 同步 `AutomationProperties.SetName`，`Focusable/IsTabStop = true`、`FocusVisualStyle = null`；`SelMenuTile` 把 label 作为 name 传入（原先传 null）。
- **验证**：UIA 按 Name + ControlType.Button 枚举，7 个格子全部命中（截图 `v232-sel-tiles.png`）。

**修正｜文本框浮层压正文、无宽度不换行、`/Rect` 按单行算导致文字被裁（操作不便第 7 条）**

- **现象**：编辑框半透明，取词卡/选区浮条压在正文上；文字越长框越宽不换行；保存后 `FreeText` 的 `/Rect` 仍是单行高度，回看时文字被裁掉。
- **根因**：① 浮层背景半透明且未关闭翻译卡与选区浮条；② `tb` 没有设置 `Width`，放进 `Canvas` 后测量为无限宽，永不换行；③ `CloseFreeTextEditor` 先 `Children.Remove` 再读 `ActualWidth/Height`，此时测量值已被清空，`/Rect` 退化成按单行估算。
- **修法**：打开编辑器时先 `CloseTranslateTip(); CloseSelectionPopup();`；背景改不透明（夜间/护眼 `#1E1E1E` + `InvertColor()` 反色字）；单击建框时按 `boxW = max(pageRect.Width, 100)` 且钳到「页宽 − 左边距」显式设 `tb.Width = boxW * _zoom`；收尾**先量尺寸再摘画布**，`boxW = max(_ftBoxWidthPt, 实测)`、`boxH = max(rect.Height, 实测)`、`top = max(0, bottom - boxH)` 防出页。
- **验证**：单击建框 → 输入 39 字符 → 三行换行（截图 `v232-textbox-typed.png`）；保存后用 PyMuPDF 读回 `FreeText Rect(167.9, 46.1, 267.9, 68.2)` = **100 × 22.1pt**（两行高度），`/Contents` 文本完整。

**修正｜文本框工具下 ESC 既没提交也没切回选择工具（操作不便第 8 条）**

- **现象**：在文本框里按 ESC，编辑框消失但文字没提交、状态栏仍是「当前工具：文本框」。
- **根因**：`tb.KeyDown` 原先用数值比较按键且未处理 ESC；另外 Windows 输入法在组合输入期间会先吞掉第一个 ESC（用于取消联想候选），这一层应用层拦不到。
- **修法**：`tb.KeyDown` 改为具名 `switch (e.Key)`：`Key.Enter` → `CloseFreeTextEditor(commit: true)` 留在工具；`Key.Escape` → 提交 + `Tool = Select` + `Cursor = Arrow` + `RequestSelectTool`；`CancelDrawing()` 尾部也补 `CloseFreeTextEditor(commit: true)`（页视图回收路径同样提交）。
- **验证**：标注 `0 个 → 1 个`、工具 `文本框 → 选择`；自动化连续按两次 ESC（第一次被输入法候选窗消费），真人在输入法组合态下同理。

**复查｜「链接工具没有目标编辑入口」为误判（操作不便第 9 条）**

- `MainWindow.AskLinkTarget` 一直存在：模态 `Window`、标题「链接目标」、宽 360 高 220、`WindowStartupLocation=CenterOwner`，含「跳转到页码（1–N）」「或网址（URI）」两个输入框与确定/取消。上一轮判为缺失，是 `PrintWindow` 抓不到独立 HWND 造成的取样错误。
- 本轮补了诊断日志：`链接工具: 第 N 页拖出 WxH pt 选区，弹出「链接目标」对话框` / `链接工具: 选区过小（…pt），未弹出目标对话框` / `添加链接: 第 N 页 → …`。
- **验证**：第 1 页拖出 85.7×21.4pt → 独立窗口「链接目标」出现（截图 `v232-link-dialog.png`）。

**记录｜「文本框第一次 ESC 无效」不是缺陷**

- Windows 输入法在组合输入中收到 ESC 会先取消联想候选，事件不进入应用层；再按一次即可提交并切回选择工具。实测两次 ESC 后标注正常落地。真实用户若用中文输入法打字，同样按两次即可；若在英文输入法状态下，一次即可。

## 2026-11-17 V1.2.231

**修正｜放大按钮在 224% 时把缩放改小（缩放档位方向判断错误）**

- **现象**：适应宽度 224% 下点「放大」→ 200%，画面反而变小；再点「缩小」→ 150%，连续两次都朝反方向走。
- **根因**：`NudgeZoom` 的取档逻辑是「当前 +25% 后取最近档」，方向信息在取档这一步丢失。档位表最近档计算：`249 → 200`（差 49）优于 `249 → 300`（差 51），于是「放大」得到更小的档位。凡是当前值落在两档中点偏左的位置都会反向。
- **修法**：`NudgeZoom` 不再取最近档，改为方向性取档：放大 = 档位表中所有 `> cur + 0.5` 的最小值，缩小 = 所有 `< cur - 0.5` 的最大值；无匹配时取端点档（1600/3200/6400 或 8.33）。
- **验证**：`PerfBench\ui_verify_v1231.ps1` 真实鼠标点击 `ZoomInBtn`/`ZoomOutBtn`，224% → 300% → 400%，400% → 300%，状态栏 `缩放 xxx%` 逐档核对。

**修正｜切换夜间 / 护眼模式后页码跳回 1、本页标注按第 1 页统计**

- **现象**：书签跳到第 8 页后开夜间模式，页码框变 1，「本页标注 0 个」也按第 1 页算；但画面仍停在第 8 页（此时点「下一页」得到 9，证明内部 `CurrentPageIndex` 一直是 8）。
- **根因（两层）**：
  1. `RecolorPages()` 换色后重建 `ThumbList.ItemsSource`，重建瞬间 `SelectedIndex = -1`；`RefreshPageNav`/`UpdateStatus` 以 `SelectedIndex + 1` 作为页码来源 → 算成 1（越界兜底）。
  2. 选中恢复放在 `Dispatcher.BeginInvoke(DispatcherPriority.Loaded)`，且恢复期间 `_suppressThumbScroll = true` 使 `OnThumbSelected` 首行早退；恢复动作本身不刷新状态栏，于是错误页码再也不会被纠正。
- **修法**：恢复选中的 `BeginInvoke` 回调尾部、`finally` 复位 `_suppressThumbScroll` 之后补 `SyncCurrentPageFromViewport(); UpdateStatus();`；并新增 `sel < 0` 分支（列表刚重建那一帧）同样刷新一次。页码与「本页标注」都以视口真实位置为准。
- **验证**：第 8 页 → 开夜间 8 → 关夜间 8；开护眼 8 → 关护眼 8。截图 `PerfResults\pos-2-night.png`（修复前）与 `v231-night.png`（修复后）。

**修正｜双页（对开）模式下「下一页 / 上一页」点了没反应**

- **现象**：双页模式页码显示 5，点「下一页」仍显示 5，连续点也不动，看着像按钮失效。
- **根因**：两个翻页入口一律 `CurrentPageIndex ± 1`。对开模式一个视口覆盖两页（`VirtualizingPagePanel` 按行排布 `i0 = 2r, i1 = 2r + 1`），+1 仍落在同一屏内，不触发滚动；页码按「视口顶部页」显示，于是数字也不变。
- **修法**：新增 `private static int SpreadStep(int index, int dir)`：单页模式 ±1；对开模式 `row = index / 2`，`dir > 0` 返回 `(row + 1) * 2`，`dir < 0` 返回 `Math.Max(0, (row - 1) * 2)`。`OnGotoPrevPage` / `OnGotoNextPage` 均改为 `GoToPage(SpreadStep(CurrentPageIndex, ∓1))`。语义同 Adobe：翻页 = 翻一屏。
- **验证**：双页开 = 5 → 下一页 = 7 → 上一页 = 5；截图 `PerfResults\v231-twopage.png`。

**记录｜全功能验收中确认「不是缺陷」的三项（避免后续误改）**

- **批量打开首个文档「超时」**：30 份串行启动时第一份 `Chipanalog-CAIS3214…pdf`（1.48MB / 30 页）被轮询判超时；同条件单独复测 698ms / 633ms，日志 `打开成功…共 30 页`、`版面度量: 30 页，缩放 2.061…`，进程 `Responding=True`。属冷启动（首次触摸 exe / Defender 扫描 / JIT）假阳性。
- **拖不出文本选区**：`ToolMode.Select` 的起点命中走 `GetCharIndexAt(PageIndex, x, y, 5.0)`，**5pt 容差是点单位**，在行间空白 / 图注间隙按下时返回 -1，整次拖拽不产生选区也不给任何反馈（`OnMouseUp` 见 `_selRects.Count == 0` 直接 `ClearSelection()`）。把起点挪到字形内（同一页面 y 移动 5px 即命中）后选区、`Ctrl+C`、剪贴板全部正常（实测复制到 78 个字符原文）。功能本身可用，容差偏紧列为改进项（见 `Docs\产品改进与迭代建议.md`）。
- **文本框「丢字」**：`/Contents` 的写入链路正常（剪贴板粘贴 `P Q R` 保存后 PDF 字节为 `/Contents(P Q R)`，空格完整）；自动化键盘注入空格时 `/Contents` 里空格消失，属注入侧的按键语义差异，不作为产品缺陷，但列为人工复核项。

## 2026-11-17 V1.2.225

**修正｜文档标签框线断裂、宽度固定、选中与未选中形状不一致**

- **反馈链**：深色下角黑缺口 → 要像 Edge 外张 → 框线是垂直的 → 框线要连到底 → 框线没有连续跟随填充外围 → 焦点标签宽度固定 → 未选中标签形状要和当前标签一样。
- **根因 1（框线断裂）**：主体 `Border` 与两只独立脚 `Path` 各画各的描边，衔接处无法形成一条连续闭合线；更早的背景色咬角方案在深色下呈黑缺口，独立圆块成凸耳朵，负 Margin 外伸被 `ScrollViewer` 裁掉。
- **根因 2（宽度固定）**：标题 `TextBlock` 硬编码 `MaxWidth=170` + `CharacterEllipsis`，叠加 TabItem `MinWidth=104`，短名顶下限、长名顶上限；且轮廓 `Path` 参与父级测量，选中时几何宽恰等于 `ActualWidth`，形成正反馈把标签一路锁到 `MaxWidth=230`。
- **根因 3（形状不一致）**：几何生成按 `IsSelected` 分支，仅选中态长脚；浅色 `TabIdleBg #EDF1F7` 与 `TabBarBg #E9EDF3` 极接近，未选中的脚虽已生成却融进栏背景看不见。
- **修法**：新增 `TabOutlineConverter.cs` 生成单一闭合 `StreamGeometry`（填充与描边共用同一几何），圆角/脚宽固定不随宽度拉伸；删标题固定上限、下调 MinWidth；把 `Shape`/`Tint` 包进 `Canvas` 阻断测量反馈；几何去掉 `IsSelected` 分支、所有标签统一脚形，未选中态改用 `Th.TabBorder` 勾边。
- **验证**：深/浅色放大截图描边从顶角、侧边到脚底连续闭合；短/中/长标签宽度 117/169/288px，短名选中/未选中一致；浅色三标签形状统一；Release 构建 0 警告 0 错误。

**修正｜长文件名把标签栏未保存红点裁掉**

- **现象**：打开文件名很长的 PDF 并修改后，标签上的未保存红点看不见（被长文件名遮盖）。
- **根因**：`MakeTabItem()` 把红点做成文件名 `TextBlock` Inlines 里的最后一个 `Run`（`"  ●"`），而该 `TextBlock` 设了 `TextTrimming=CharacterEllipsis`。文件名超过 `TabItem.MaxWidth=230` 触发省略号截断时，位于末尾的红色圆点 Run 与多余文字一起被裁掉。
- **修法**：`DocTab` 新增 `TabLabel` 字段持有标题 `TextBlock`，`DirtyDot` 由 `Run` 改为独立 `TextBlock`；两者放进 Grid 两列（文件名 `*` 可收缩、圆点 `Auto` 固定），文件名截断不影响圆点；`RefreshTabDirtyDots()` 圆点文本从 `"  ●"` 改为 `"●"`（间距交给 Margin），`RefreshTabTitle()` 改为只更新 `TabLabel` 的 Run，不再重建圆点。
- **验证**：UIA 用超长中文文件名 PDF + 矩形标注制造未保存态，检测到圆点元素 `●`（U+25CF）边界 `(224,140,11,21)`，标签放大截图显示「这是一个非常非常长的…●✕」红点完整可见；构建 0 警告 0 错误，lint 干净。

**新增｜工具栏「文档表格」整文档识别 + 多选导出 Excel**

- 复用已有 `TableExtractor.DetectAll`（文字层几何识别，不依赖表格线；图片表格需先 OCR）与 `XlsxWriter`。
- 新增文件 `Dialogs/TableListDialog.xaml(.cs)`：`Entry` 记录（页码 / 表格 / 显示标签 / 勾选态 / sheet 名），ListBox + CheckBox 列表、`JumpRequested` 回调、全选/全不选、确定校验至少一张。
- `XlsxWriter`：新增 `WriteMany` 多 sheet 写盘（`ContentTypes`/`Workbook`/`WorkbookRels` 改为按 sheet 数生成，sheet 名清洗 + 大小写不敏感去重 + 后缀留 31 字空间），单表 `Write` 转调它。
- `MainWindow.xaml.cs`：新增 `OnDocumentTablesClick`（全文档识别 + 弹窗 + 等待光标 + 失败页记日志）、`JumpToTable`（行带矩形 → `ScrollToSearchRect`）、`ExportTablesToXlsx`（`SaveFileDialog` 默认名 `文档名_Table.xlsx` → `XlsxWriter.WriteMany`）、`MakeSafeFileName`；`App.xaml` 新增 `Geo.Table`，`MainWindow.xaml` 工具栏加 `DocTablesBtn`。
- 验证：38 页 PDF 识别 22 张表，点击列表项渲染到目标页；导出 xlsx 读回 22 个 sheet、命名/去重正确；构建 0 警告 0 错误，lint 干净。

**调整｜导出 PDF 默认文件名中的 n 改为实际页数**

- 原先 `ExportPagesDialog.DefaultPdfName()` 返回 `原文件名 + "_np_exp.pdf"`，`n` 是字面量字符，不随导出页数变化。
- 改为 `原文件名 + "_{导出页数}p_export.pdf"`：构造函数新增 `_pageCount` 字段保存已有 `count` 参数（= `SelectedPageIndices()` 的选中页数），`DefaultPdfName()` 用 invariant 数字拼入；无来源路径回退「导出页面_{页数}p_export.pdf」。仍可在另存为对话框手动改名。
- 验证：构建 0 警告 0 错误，lint 干净；默认名逻辑为确定性字符串拼接，页数与导出内容同源。

**修正｜清除标注后「红点还在 / 保存灰 / 保存全部亮」三处状态互相矛盾**

- **现象**：用户在文档上标记时，标签红点、保存按钮、保存全部按钮都有变化；清除标注后红点仍在、保存按钮变灰、保存全部却仍亮起。
- **根因**：`RefreshSaveButton()` 内部对三个 UI 元素用了**三套不同的脏判定**：
  - `SaveBtn`：`IsModified && (HasAnyAnnotations() || OutlineDirty)`（复合判定）
  - `SaveAllBtn`：`_tabs.Any(t => t.Doc.IsModified)`
  - 标签红点 `DirtyDot`：`Doc.IsModified ? "  ●" : ""`
  清除标注走 `PdfDocument.DeleteAnnot()`，成功分支把 `IsModified` 置 true 且从不复位；但 `OnAnnotChanged` 同步把 `PagesWithAnnot` 移除该页，全部清除后 `HasAnyAnnotations()` 翻转为 false。于是恰好命中「保存按钮 false、另两者 true」的不一致组合。
- **修法**：
  1. **统一口径**：`SaveBtn` 也改为只看 `_doc?.IsModified == true`，三控件共享同一权威标志，永不再互相矛盾。
  2. **精确复位**：`DocTab` 新增 `AnnotAtBaseline`（打开/保存时是否已有标注）与 `NonAnnotDirty`（旋转/删页/文档信息等非标注修改）记账；`TryClearDirtyIfBackToBaseline()` 在「页集合权威且为空、基线本无标注、又无非标注修改」时把 `IsModified` 复位为 false——即用户所选语义「添加后又清除 = 无未保存改动」。判定放在 `OnAnnotChanged` 与后台标注页扫描完成两处，覆盖扫描时序。
  3. **防误清**：打开文档时 `DocHasAnnotations()` 建立基线；保存成功后刷新基线并清 `NonAnnotDirty`；旋转、删页两处显式置 `NonAnnotDirty`，避免清标注时把它们的改动一起抹掉；原有文档自带标注时清除会保持脏状态（确实删除了内容）。
- **验证**：UIA 加 BOM 后用 TogglePattern 激活矩形工具 + 鼠标拖拽，实测 `INITIAL` 三控件全灭、`AFTER_ADD` 全亮且标签出现红点；清除路径经逐行审查（删除与扫描完成均触发复位、非标注改动有防误清），Release 构建 0 警告 0 错误。自动化清除按钮因默认筛选条件被禁用，未走完 UI 全链路。

**修正｜书签点击只跳到页首，未定位到书签所指的页内位置**

- **现象**：用户点击「2.3.2 直流总线电压检测」书签后，视图停在该页页首（「系统概述」），而目标段落实际在页面中下部。
- **根因（两层坐标丢弃）**：① `PdfDocument.ReadBookmark()` 取得 `FPDF_DEST` 后只调用 `FPDFDest_GetDestPageIndex` 取页码，`/XYZ x y zoom` 里的目标坐标直接丢弃——`OutlineItem` 本身也只有 `PageIndex` 一个目标字段；② `MainWindow.OnOutlineSelected()` 只调 `GoToPage(item.PageIndex)`，后者固定滚到 `PagePanel.TopOf(index) + Margin.Top - 10`（页顶）。两层叠加，任何书签都只能到页首。
- **修法**：
  1. `Native/Pdfium.cs` 新增 `FPDFDest_GetLocationInPage` P/Invoke（`hasX/hasY/hasZ` 用 `out int` 接 FPDF_BOOL，避免编组差异）。
  2. `OutlineItem` 增加 `TargetX/TargetY/TargetZoom`；`ReadBookmark()` 在拿到 dest 后解析三者，未指定的轴保持 null，老版 pdfium 缺该 API 时 try/catch 回退纯页码。
  3. `MainWindow` 新增 `GoToOutlineItem()`：目标 Y 有效且版面就绪、页面无旋转时，按 `(页高pt - targetY) / 页高pt` 换算页内比例（`HeightOf` 已含 Zoom，不再乘一次），滚到视图区首部；无坐标 / 旋转 / 版面未就绪回退 `GoToPage()`。
  4. `PdfOutlineWriter.NodeBody()` 由固定 `/Dest [pageRef /Fit]` 改为有坐标时写 `/Dest [pageRef /XYZ x y zoom]`（未指定轴写 `null`），防止用户编辑保存书签后坐标被降回 `/Fit`。
- **验证**：构建 0 警告 0 错误（首次因 `is double` 模式变量在 `||` 短路下未赋值报 CS0165，改为显式 `double?` 后通过）；UIA 递归展开书签树选中「2.3.2 直流总线电压检测」并截图，视图定位到该章节的 AMC1311 电路与图 6，不再停在页首。

**修正｜书签定位第二轮：`/XYZ` 坐标不可靠，仍停页首 / 正文散词处**

- **现象**：按 `/XYZ` 坐标修完后点「2.2.1 AMC1311」仍停在「系统概述 / 2.2.3」区域，没有到章节标题。
- **根因（实测诊断日志确认）**：
  1. 该 PDF 书签目标是 `/Fit`（无页内坐标），`FPDFDest_GetLocationInPage` 对这类目标不写 out 参数，日志里 `TargetY = 5.6341067E-315`（次正规垃圾值），坐标兜底无效。
  2. 改用标题文本搜索后，书签标题用 en-dash「2.2.1–AMC1311」，页面文本用普通空格「2.2.1  AMC1311」，`Search("2.2.1–AMC1311")` → `hits=0`。
  3. 退而求其次搜短词「AMC1311」→ `hits=7`，取第一处却落在正文段落（视图里标题跑到中下部）。
- **修法**（`MainWindow.GoToOutlineItem` 三级定位）：
  1. 新增 `FoldTitle(string, List<int>?)`：把标题 / 页面文本折叠成「只保留字母数字汉字」的紧凑串，同时记录每个紧凑字符在原文的索引；`FindOutlineTitleOnPage()` 在紧凑串中整条匹配标题（「2.2.1–AMC1311」与「2.2.1  AMC1311」折叠后同为 `221AMC1311`），再映射回原文字符区间取矩形——直接命中章节标题本身，不会落到正文散词。
  2. ①-b 折叠匹配失败时，用 `BuildOutlineQueries()` 生成的归一化查询词（完整标题 → 去章节号 → 长词）逐条 `Search` 兜底。
  3. ② `/XYZ` 目标 Y 增加 `[0, 页高]` 合法性校验，滤掉 pdfium 残留的次正规垃圾值；③ 最后回退 `GoToPage()` 页首。
- **验证**：UIA 选中「2.2.1 AMC1311」截图，标题精确位于视图区首部（诊断日志 `FoldTitle match start=758 len=13`）；移除临时诊断日志后 Release 构建 0 警告 0 错误，lint 干净。

## 2026-11-16 V1.2.224

**重构｜全软件图标统一为一套 24×24 线性图标（并修掉几张「认不出来」的）**

- **现象**：图标散落在 `MainWindow.xaml`（97 处内联 `Path.Data`）、`App.xaml`（4 处）、`PreferencesDialog.xaml`（2 处）以及 C# 字符串里（`ContextToolCatalog.cs` 12 条、`MainWindow.xaml.cs` 若干处）。画布尺寸、边距、端点样式、描边粗细各不相同，同一屏里能看出好几代画法并存。
- **做法**：先用脚本按 XAML 树解析出「每个 Path 归属哪个菜单项/按钮」的完整清单，再按已有的规范（24×24、描边无填充、主体 4…20、圆头端点）重画一套共 66 枚，落地方式为 `ResourceDictionary` 资源 + `{StaticResource}` 引用，避免逐处手改。
- **踩坑 1**：`App.xaml` 的几何区用非贪婪正则 `.*?</Geometry>` 只吃掉第一条就收工，导致 `MC3020 字典密钥重复`。改用锚点「到最后一条 `</Geometry>`」后正常。另有一次替换的起点取文件里第一个 `<!--`，把上方的 `MenuIconVisibilityConverter` 资源一并删掉 → 启动即 `XamlParseException: 无法找到名为 MenuIconVisibility 的资源`（这次是运行时报出来的，不是编译期），已改为以「紧挨第一条几何之前的注释」为起点。
- **踩坑 2**：`ContextToolCatalog` 里「添加链接」只匹配了旧串的前缀，替换后变成「新数据 + 旧尾巴」的拼接串，已手工修正为纯新 Link 几何。
- **修掉的识别问题**：`SaveAll`（原「半张软盘 + 方块」，16px 下糊成一团 → 改为「右下完整软盘 + 右上露出第二张纸」）、`SaveAs`（软盘叠铅笔 → 带折角文档 + 右下方斜放铅笔）、`Comment`（空气泡与便签撞脸 → 气泡内加三个点）、`Strikeout / Underline / Squiggly`（统一为「T + 装饰线」）、`FitWidth`（两侧竖线外扩到 3.2/20.8）、`Ocr`（收窄行距）、`Expand / Collapse`（由「单线上下箭头」改为「朝外 / 朝内四角括号」）、`对比/分屏` 与 `双页显示` 撞图（前者改双向对照箭头）。
- **另附说明**：下拉菜单图标此前一直不显示，是因为首选项 `ShowMenuIconsDropdown` 默认关（`MenuIconVisibilityConverter` 三值控制），与图标数据无关。本轮已打开该首选项验证全部七套菜单，用户可在「首选项」里随时关回。
- **验证**：Release 构建 0 警告 0 错误；启动无异常；工具栏 / 文件 / 编辑 / 视图 / 工具 / 拓展 / 窗口 / 帮助菜单与侧栏三枚图标全部显示正确；16px 真实尺寸渲染逐一校对。

**优化｜文档标签与「+」图标按主题风格美化**

- 标签选中态从「仅换底色 + 2px 通栏线」升级为「10% 主题色晕染 + 3px 圆头焦点条 + 加粗文字」；高度 / 圆角微调到 32 / 8，四种标签样式统一。
- **修正标签高度塌缩**：Office / Classic / Flat 三种样式的根 `Border` 原设 `VerticalAlignment="Bottom"`，标签实际高度只有内容高度（约 20px），文字被上下挤裁（用户截图所见）；去掉后四种样式都按 `TabItem` 的 32px 完整绘制。用户当前首选项正是 `Classic`。
- **标签下脚（多版返工最终定稿：单一整体 Path 轮廓）**：用户连续反馈"深色黑色缺口→还是不对→要和 Edge 一样→框线是垂直的→框线要连到底→框线没有连续跟随填充外围"。对照 Edge 截图逐像素采样得到真实几何：标签上部侧边内缩约 8px、底部约 10px 高度内标签色平滑外张到槽边界。逐版排除的错误：①背景色小方块咬角（方向反了，深色成黑缺口）；②独立圆块（成"凸耳朵"，与侧边不连续）；③带负 Margin 的 Path 外伸（被 ScrollViewer 裁掉，完全不显示）；④**主体 `Border` + 独立脚 `Path` 各自描边**——给两只脚补 `Stroke` 后仍不对：脚是各自闭合的 Path（画了内侧竖边 + 底边 + 外侧弧），主体 Border 又单独画自己的边框，两段线在衔接处各画各的，无法形成一条沿填充外围连续走的闭合线，用户截图放大后框线在底部两角依然断开。**根因**：填充与描边不来自同一几何。**最终修法**：新增 `TabOutlineConverter.cs`（`IMultiValueConverter`），以 `TabItem.ActualWidth` + `IsSelected` 为输入、`"corner,foot"` 为参数（默认/Classic 8,8；Office 4,6；Flat 0,8），生成一条闭合 `StreamGeometry`——顶部圆角 + 左右垂直侧边 + 底部外张弧（控制点保证起点切线竖直、终点切线水平）+ 底边；圆角/脚宽为固定像素、不随宽度拉伸（否则宽标签会被拉成椭圆耳朵）。把原 `Root` Border 与 `LeftFoot/RightFoot/LeftTint/RightTint` 全部删掉，换成 `Shape`（Fill + Stroke 同一 Path）与叠加的 `Tint`（同轮廓、10% 晕染），内容 / 指示条浮在其上，Trigger 选中时换 `Shape.Fill`/`Shape.Stroke`。四种样式统一，深/浅色截图放大确认描边从顶角、侧边到脚底连续闭合、无黑缺口无耳朵、浅色轮廓清晰。参照色纠正：标签栏下方紧邻的是工具栏 `Th.PanelBg`（#25272C），不是文档区 `Th.DocAreaBg`。
- **修正｜浅色模式标签背景看不清**：选中标签原用全局 `Border`（浅色 #DDE3EB）勾边，白底标签压在浅灰标签栏上边界几乎消失。新增 `Th.TabSelectedBorder`（浅色 #93A9C4、深色 #3B3E44），四种样式选中态整体 Path 的 `Stroke` 改用它，自定义标签色时仍跟随自定义边框色。
- **修正｜选中标签宽度被撑成固定值（跟随文件名自适应）**：
  - **现象**：用户反馈"获取焦点的标签宽度固定，要按文件名长短自动调节，只有超过目前显示长度才截断"。实测：短名 `a` 未选中约 117px、选中后却被撑到 288px（=TabItem.MaxWidth 230 DIP）；中名 `SGM431V` 169px；长名 288px 且省略号截断。
  - **根因 1（历史遗留）**：`MakeTabItem` 里标题 `TextBlock` 硬编码 `MaxWidth=170` + `CharacterEllipsis`，叠加 TabItem `MinWidth=104`、header `MinWidth=88`，绝大多数文件名都被截到 170px，标签不是顶在下限就是顶在上限，看起来宽度固定。
  - **根因 2（上一轮改轮廓引入的回归）**：`Shape`/`Tint` 的 `Path.Data` 由 MultiBinding 按 `TabItem.ActualWidth` 生成，Path 直接放在 Grid 里会参与父级测量。未选中几何横向范围 `[8, ActualWidth-8]`（比 `ActualWidth` 小 16），每轮测量缩 16 最终收敛；选中几何范围 `[0, ActualWidth]`（恰等于 `ActualWidth`），形成**正反馈**——ActualWidth 一旦偏大就被几何锁定，一路锁到 `MaxWidth=230`。
  - **修法**：删掉标题 `MaxWidth=170`；TabItem `MinWidth` 104→80、header `MinWidth` 88→60；把 `Shape`/`Tint` 两条 Path 包进 `Canvas`（Canvas 不测量子元素，DesiredSize 恒为 0），宽度改由 ContentPresenter/标题全文宽度决定，几何只跟随不再驱动布局。
  - **验证**：短/中/长三个文件名同时打开，宽度 117 / 169 / 288px（长名省略号截断）；用 UIAutomation `SelectionItemPattern.Select()` 把短名切到选中，宽度仍为 117px，选中/未选中一致；轮廓描边与脚弧未受影响。Release 构建 0 警告 0 错误。
- **优化｜未选中标签形状与当前标签不一致**：`TabOutlineConverter` 原以 `IsSelected` 分支，仅选中态生成底部外张脚，未选中为内缩圆角矩形，视觉上像两种不同控件。用户要求"没有获取焦点的标签形状和当前标签一样"。改法：几何生成去掉 `IsSelected` 分支，所有标签统一同一条外张脚轮廓；XAML 移除 8 处 `IsSelected` 绑定（Path 已在 Canvas 内，几何全宽不再有测量反馈问题）。因浅色 `TabIdleBg #EDF1F7` 与 `TabBarBg #E9EDF3` 极接近，未选中标签的脚虽已生成却融进栏背景看不见——把未选中态 `Shape.Stroke` 从 `#00FFFFFF` 透明改为 `Th.TabBorder`（选中仍用更深的 `Th.TabSelectedBorder`），脚形立即可见。浅色截图：三个标签轮廓形状完全一致，选中态靠深描边 + 顶部强调条区分；构建 0 警告 0 错误。
- **验证**：Release 构建 0 警告 0 错误；深色 + 浅色分别打开用户同一份 `zhcu384a.pdf` 截图放大：深色标签圆角干净、无黑色缺口，浅色白底标签有清晰蓝灰轮廓。
- 标签标题去掉 `.pdf` 扩展名（`DocTab.TabTitle` 改用 `GetFileNameWithoutExtension`）。
- 标签名末尾新增未保存小实心圆：`Doc.IsModified` 为真时显示，与「保存全部」/ 退出确认同一口径，挂在 `RefreshSaveButton()` 上统一刷新；用 Inline `Run` 实现才能紧跟文件名，另存为重建 Inlines 时保留该 Run。
- 「+」按钮从灰色细十字改为 28×28 圆角容器 + 14×14 圆头加号，默认主题色描边，悬停浮出主题色底、按下用选中底色；加号移入控件模板以支持 Trigger 换色。
- 颜色全部走主题资源，深浅 / 护眼模式自动跟随；实机两种主题均确认协调。

## 2026-11-16 V1.2.223

**修正｜「打开最近」菜单没有任何历史记录**

- **现象**：`文件 → 打开最近(_N)` 展开是空的（菜单项还是灰的，点不动）。
- **排查**：先确认数据没丢——`%AppData%\PdfReader\prefs.json` 里 `RecentFiles` 有 10 条、`MaxRecentFiles=10`，`AddRecent()` 每次 `OpenTab` 都正常写入并 `Save()`。问题在「展示」这一侧。
- **根因**：`RecentMenu` 在 XAML 里写死 `IsEnabled="False"`；`BuildRecentMenu()` 只有「应用首选项」和 `SubmenuOpened` 两个调用点。「应用首选项」只在用户点首选项对话框确定后执行；`SubmenuOpened` 是禁用菜单根本收不到的事件。**禁用 + 无子项 → 永远收不到展开事件 → 永远建不出子项**，一个自锁。
- **改动**：构造函数里启动即 `BuildRecentMenu()`；XAML 去掉硬编码 `IsEnabled`；`AddRecent()` 末尾即时重建；空列表给「（暂无记录）」占位。
- **顺带修可读性**：菜单项由整条路径改为文件名（路径进 ToolTip）；失效文件标注「（文件已不存在）」；末尾加「清空最近记录」。
- **验证**：启动后菜单可展开、10 条记录齐全、点击可打开并置顶；退出后 prefs 顺序正确；Release 构建 0 警告 0 错误。

## 2026-11-16 V1.2.222

**修正｜标签切换 / 翻页过渡的固定暗栏与页缘细黑边（V1.2.221 的回归 + 残留）**

- **现象**：标签切换时文档区右边缘整段缺一条深色竖列；翻页时页缘仍有一条很细的黑线随画面移动；绽开过渡能看到两页文字叠在一起。
- **根因 1（回归）**：`CaptureViewport` 里「裁掉滚动条列」对静止快照也生效了。翻页的运动快照需要裁（否则暗列随图横移），但标签切换的整屏快照是「屏幕此刻的样子」，裁掉右列等于过渡层右边缘永远缺一列（深色模式近黑）。**改动**：裁切条件加 `motion`；静止快照保持全宽，且不再把滚动条置透明（过渡层里的滑块不再凭空消失）。
- **根因 2**：页面比视口窄（254% + 适应宽度）时，内容区右侧还留 3~5 DIP 文档底色，被一起抓进快照后随图横移 = 细黑线。**改动**：新增 `TrimDarkRightEdge`，按「连续暗列 + 停止列必须是亮页面 + 暗条 ≤14px」三条同时满足才裁（实测再裁 5px），深色页面不误伤。
- **根因 3**：滑动层盖住整列滚动条。**改动**：滑动层按内容宽度加 `Clip`，翻页全程真实滚动条可见，收层时清空。
- **根因 4**：绽开遮罩内外色标间距 12%，混合环过宽 → 两页文字大面积叠加（重影）。**改动**：收到 6%（`-0.06/0.94`），并把绽开时长下限提到 150ms（极速档 80ms 只有约 5 帧，像闪一下）。
- **验证**：标签切换快照恢复 1919px 全宽；运动快照两级裁切 1919→1902→1897；翻页中途帧右缘剖面与静止态逐列一致（255/107/19/32），暗条不再随画面移动；横移 197ms/1518px；构建 0 警告 0 错误。

## 2026-11-16 V1.2.221

**优化｜页面切换 / 标签跳转 / 文档内跳转的过渡「有闪动和黑边」（深色模式）**

- **现象**：整页横移翻页时有一条近黑竖带扫过；标签切换（径向「绽开」过渡）开场会闪一下（白斑 / 黑洞）；极速档下翻页像「闪过去」而不是滑动。
- **先量后改**：加临时探针 `AnimTrace`（`XC_ANIM_TRACE=1` 时把每段过渡的分段耗时、真实帧间隔、窗口总时长写进 `%TEMP%\xc-pdfreader-boot.log` 的 `[trace]` 行；未设置环境变量时所有方法立即返回）。实测：一次翻页 361~392ms，其中抓旧快照 56~72ms、抓新快照 87~88ms（`RenderTargetBitmap.Render` 同步阻塞 UI），横移只有 **70ms**（`AnimSpeed=3` 把 320ms 压到下限），全程 7~11 帧、帧间隔最大 33~35ms。
- **根因与修改（`MainWindow.xaml.cs`）**：
  1. **接缝其实是"缝"**：`travel = w + SlideOverlap` 让两张快照各多走 3px，位置方程算出的是恒定 3px 空隙（注释写的"重叠"不成立），缝里露出 `PageSlideLayer` 的深色背景。改为旧页走到 `-w`（恰好离场）、新页从 `(w-4)` 走到 0，间隙 `4(1-p) ≥ 0` 全程重叠；`SlideOverlap` 3 → 4。
  2. **滚动条那一列被一起抓进快照**：只把 `PART_VerticalScrollBar` 置 `Opacity=0` 没用，那列的底色是 ScrollViewer 自己的 `Th.DocAreaBg`（近黑）。落盘实测 1919×820 快照右边缘 `x=1897..1918` 共 22px（17.6 DIP）近黑。改为按 `PART_ScrollContentPresenter` 宽度裁掉该列（用位图自身像素/DIP 密度换算，降采样时不会裁多）；裁后剩 3~4px 是页面旁真实背景，保留。
  3. **径向遮罩一挂上就挖洞**：透明色标初始在 `0.0`，赋值瞬间画面正中透明，而新文档还没渲染完 → 白闪 / 黑洞。改为透明色标从 `-0.12` 起步（初始整体不透明），`reveal` 时才外推；并加保险丝定时器（`ms + 900`）兜底清理，防止 `reveal` 未执行时文档区被旧快照永久盖住。
  4. **极速档丢帧**：翻页按位移补下限 `w × 0.13`（本例 198ms），封顶 320ms；只约束大位移，其它小动效仍按速度档位。
- **验证**：真机（125% DPI、暗色、2002 页、254%）三次翻页：横移 198ms、窗口内 15~18 帧、帧间隔 avg 16.8~17.3ms、快照 1902×820（裁 17px）；标签往返切换（single_1p ↔ many_2002p）内容正常显示、无黑屏、日志无异常；构建 0 警告 0 错误。

## 2026-11-16 V1.2.219

**优化｜任务栏显示当前焦点文件名，而不是软件名**

- **需求**：任务栏上该窗口的按钮显示当前焦点文档的文件名（不含扩展名），而不是「XC PDF Reader  V版本」；标题栏维持软件名不变（V1.2.179 起的要求）。
- **根因（Windows 平台限制）**：任务栏按钮显示的文本就是窗口 caption（`Window.Title`），与系统标题栏同源，二者无法分别设置。试过 Windows 10 1709+ 专为「任务栏显示名 ≠ 窗口标题」提供的 `IApplicationView.SetShortTitle` / `SetTitle`，**实测任务栏按钮主文本不变**（仍显示窗口标题），该通道在此场景无效。
- **改动（`MainWindow.xaml` / `MainWindow.xaml.cs`）**：
  - 移除系统标题栏：根 Window 改 `WindowStyle="None"` 并挂 `WindowChrome`（`CaptionHeight=0` / `ResizeBorderThickness=6` / `GlassFrameThickness=0`），标题栏区域不再由系统绘制。
  - 新增自绘标题栏 `TitleBar`（Dock=Top，高 34）：左侧应用图标（复用 `filetype.ico` 解析出的帧）+「XC PDF Reader  V版本」文本，右侧最小化 / 最大化 / 关闭三按钮（Segoe MDL2 字形，关闭按钮悬停系统红）。
  - 交互补齐：左键拖动（`DragMove`，最大化时先还原）、双击切换最大化、右键弹系统菜单（`GetSystemMenu` + `TrackPopupMenu`，「移动 / 大小」置灰）、三按钮事件；最大化 / 还原时中间按钮字形切换（ChromeMaximize ⇄ ChromeRestore）。
  - 窗口 caption 改为当前焦点文档的文件名（`Path.GetFileNameWithoutExtension`），在切换标签、关闭全部文档、另存为后同步刷新；无文档时退回软件名。
  - `WM_GETMINMAXINFO` 按窗口所在显示器的工作区钳住最大化尺寸与位置，避免自绘标题栏下最大化溢出工作区。
- **不变量**：标题栏始终显示「软件名 + 版本号」，与 V1.2.179 的要求一致；各类对话框仍使用系统标题栏，未受影响。
- **验证**：实机任务栏按钮文本由 `XC PDF Reader  V1.2.218` 变为 `single_1p`（无扩展名），标题栏不变；标题栏三按钮、拖动（dx=180 / dy=70 精确跟随）、双击最大化均正常；最大化时窗口与工作区边界完全重合（溢出 0 px）；构建 0 警告 0 错误。

## 2026-11-15 V1.2.218

**优化｜动效：弹簧动画慢半拍、淡出拖泥带水、帧内轨道过碎**

- **弹簧动画实际耗时是请求时长的 2.01 倍**（手感主因）：临界阻尼弹簧 `x(t)=To+(A+Bt)·e^(-ωt)`，误差带 `e(t)=(1+ωt)·e^(-ωt)`。原参数 `ω=4600/ms`，而 `Track.IsDone` 的完成判定同时要求「位置误差 ≤ 0.1%·Δ」与「速度 ≤ 0.1%·Δ·ω」，两者都要 `ωt≈9.08` 才成立 → 收敛时长 `t = 9.08/ω = 1.97×Ms`。表现：按钮回弹、弹层缩放、侧栏/列宽、面板滑入全部比预期慢近一倍，点下去像「没反应」。
  - 修正：`ω` 由 `4600/ms` 调到 `7000/ms`，精度带放宽到 0.5%（1% 时 `ωt≈6.64`，0.5% 时 `≈7.52`，两者肉眼均不可见）→ 收敛时长 `≈1.06×Ms`。速度接续语义不变（被打断仍继承初速度继续走）。
  - 数值验证：150/190/240/300ms → 旧 301/381/482/602ms（2.01×），新 159/202/255/318ms（1.06×）。
- **淡出拖泥带水**：`Fade` 固定用 EaseOut（起步快、收尾缓），淡出时表现为「先淡掉一半、再慢慢消失」。改为按方向选曲线：淡入 EaseOut、淡出 EaseIn（新增 easeInQuart），淡出收尾更利落；`PopOut`（对话框/弹层退场）同样改用 EaseIn。
- **帧内轨道过碎**：同一次动画里多个属性各占一条轨道（`PopIn` 4 条、`Pulse` 2 条、`StaggerRows` 每行 3 条），帧内遍历与委托调用翻倍。改为「同曲线同元素的多属性合并为一条轨道」：`PopIn`/`PopOut` → 2 条（缩放 X/Y 合一条、透明度 + 位移合一条），`Pulse` → 1 条，`StaggerRows` 每行 → 1 条（透明度 + 位移 + 纵向缩放一起推进，缩放曲线由 Spring 改 EaseOut，振幅仅 1.5%，视觉无差别）。
  - 槽位约定统一：透明度一律走 `opacity` 槽（`Fade`/`SlideIn`/`PopIn`/`PopOut`/`RotateIn`/`StaggerRows` 共用），缩放走 `scale` 槽，位移走 `shiftX` 槽 —— 同一属性只有一条轨道，不会互相争写。
- **帧内每帧分配**：`OnRendering` / `Sweep` 每帧 `new List<Track>()`，改为复用静态缓冲。
- **死代码**：删除无任何调用点的 `SlideY`（internal），避免将来与 PopIn 的合并位移轨道争写 `TranslateTransform.Y`。
- 验证：数值求解误差带如上；UI 逐帧抓取确认对话框入场中间帧半透明+缩放中、终帧无残留，退场后窗口真正关闭，书签树波浪入场后子节点完全可见；构建 0 警告 0 错误。

## 2026-11-15 V1.2.217

**修复｜表格内拖选文本会串到相邻单元格（Adobe 式视觉选区）**

- 现象：在 PDF 表格页内从某个单元格起拖，选区溢出到同行/相邻列（截图里左列的 `Power`、`I` 被一并选中），复制出来的文本也是连片的一段。
- 根因 1（旧选区模型）：旧实现按**内容流字符索引区间**选字。表格里相邻单元格的文字索引同样相邻，且真实 PDF 常按列优先排列，索引顺序与视觉顺序不一致 → 一拖就把整行/整页单元格都算进去。
- 根因 2（表格边框字形）：onsemi 数据手册一类 PDF 用 **15.4pt 的方块字形（`Á`）拼出表格网格线**。这些字形与单元格正文被并进同一个片段（实测 `"DESAT ÁÁÁ"` 的包围盒从 x=73 横跨到 x=153，正好压到下一列），于是「选 DESAT 却把边框和隔壁区域一起框住」，复制文本里还冒出 `ÁÁÁ`。
  - 新增边框字形判定：字形明显大于正文（高 > 1.5×中位行高 或 宽 > 2.5×中位字宽）**且**为同样字形连续排布（避免把 `000` / `ll` 误判）→ 边框单独成段（`TextFragment.IsRule`），不参与行聚类、不参与选区、不进复制文本。
- 根因 3（终点吸附越列）：终点落在空白处时按「加权最近」会吸附到横向很远的另一列（说明列），连带把说明文字整片选入。现改为**走廊**语义：走廊 = 拖拽带水平范围 ∪ 起点片段水平范围，终点只在走廊内吸附；中间行也只取走廊覆盖到的片段。
- 根因 4（选中状态跨调用残留）：片段的 `SelStart/SelEnd` 是缓存字段，上一次拖选的结果会残留到下一次（表现为竖拖一次后，同行横拖仍多出几行）。现已在每次 `GetVisualSelection()` 开头统一重置。
- 另修：`FindFragmentAt` 垂直距离符号写反（`f.T - y` 应为 `y - f.T`），导致点击上方行时命中下方行；新增整词吸附（Acrobat：起止点落在词中间时带上整个词）与片段首尾空白剔除。
- 验证：
  1. 合成表格 + 正文探针 7 项全通过（单元格内横拖、竖拖一列、同行横拖、正文竖拖整行入选 / 矩形数、正文同行拖选）。
  2. 真实文档 `NCD57100-D.pdf` 第 4/7 页 PIN DESCRIPTION 表：单元格内横拖 → `Power`（1 矩形）；I/O 列竖拖 → `Power | I/O`（2 矩形）；长距离竖拖 → `Power | I/O | Power`（3 矩形，全在本列）；同行横拖 → `VEE2A \t 1`（2 矩形）。
  3. 构建 0 警告 0 错误。

**移除｜AI 文档分析 与 文档分析技能库**

- 入口：删除 `MainWindow.xaml.cs` 拓展菜单的「AI 文档分析…」与「文档分析技能库…」两项、`MainWindow.xaml` 工具栏的 `AiAnalyzeBtn`（及 `MainWindow.xaml.cs` 无文档置灰列表里的引用）、`CompareWindow.cs` 的「AI 分析左 / AI 分析右 / AI 对比」三个按钮。
- 代码：删除 `Dialogs/AIAnalysisDialog.cs`（含 `AiMode` 枚举）、`Dialogs/SkillLibraryDialog.cs`、`LLM/DocSkillLibrary.cs`，以及仅供 AI 文档分析「预览」视图使用的 `Dialogs/MarkdownRenderer.cs`（`MarkdownRenderer` 仅被 `AIAnalysisDialog` 引用）。
- 保留：`AiSettingsDialog` / `AiSettingsPanel` / `LlmClient` / `FreeModelCatalog` 全部保留，`LLMClient` 仍服务于取词翻译、划词翻译与全文翻译；「拓展 → AI 大模型设置…」与各翻译界面的「AI 设置」入口不变。
- 文案同步：`AiSettingsDialog` 顶部说明、`AiSettingsPanel` 的「工作模型」与「温度」提示、`LlmClient` 与 `AppPrefs` 注释中的「规格书分析 / 版本对比」改为「取词翻译、划词翻译与全文翻译」。
- 验证：构建 0 警告 0 错误；UIAutomation 枚举「拓展」菜单，结果为 添加链接 / 填写表单 / 识别文字 (OCR) / 取词翻译 / 对比 / 分屏查看 / **AI 大模型设置…** / 水印 / 页眉页脚 —— 无 AI 文档分析与技能库项。

## 2026-11-15 V1.2.216

**修复｜「选中文本 → 添加注释」入口的收尾（承接 V1.2.214）**

- 入口区分（此前混淆）：选区快捷栏第一项「添加注释」= `ShowSelectionPopup` → `SelIconTile("Geo.Note", "添加注释", EditNote)` → `EditNote()` → `AddTextMarkup(page, 9, selRects, color, 内容)`，是**文本标记 + 备注**；右键「工具 → …」原「添加注释」= `ActivateToolFromTag("Note")` → 点页面 `CreateNoteAt()` → `AddFreeText(...)`，是**自由文本框**。两者不是同一个功能。
- 两者共用 `TextInputDialog` 与 `ShowDialog() == true`，因此 V1.2.214 对 `LayoutAnim.OnDialogClosing` 的修复同时覆盖：动效挂载后 `ShowDialog()` 不再返回 null。
- 内容格式：`EditNote()` 新建分支原先传 `string.Join("\n", dlg.Entries)`，即内部序列化串「作者␁时间␁正文」。改为新增的 `dlg.NoteTexts`（纯正文）；`AnnotInfo.Title` 也已改为取最后一个 `\u0001` 之后的部分，双保险。
- 命名：`ContextToolCatalog` 的 note 项 `Header` 由「添加注释」改为「添加文本框」，右键菜单与实际落地对象一致（id / Tag 不变，配置 `CtxTools["note"]` 兼容）。
- 验证：
  1. WPF 探针（`_noteprobe`）：`LayoutAnim.AttachGlobal()`（反射调用同一入口）+ 真实 `TextInputDialog`，DispatcherTimer 里设 `DialogResult = true` → `SHOWDIALOG_RESULT=true`、`CONFIRMED_TEXT=probe-text`。修复前同样的动作返回 null。
  2. 数据层探针：`AddTextMarkup(0, 9, …)` → `Save` → 重开回读 `sub=9 contents=probe-markup-note`。
  3. UI 层（文本框入口，同一弹窗机制）：`PerfBench\ui_note_probe.ps1` 实测 `dialog=True`、`SaveBtn=True`、保存后文件回读 `sub=3 contents=ZZ probe note`。
  4. 选区快捷栏入口的鼠标自动化在脚本里不稳定（快捷栏是 `Border`，UIA 无 InvokePattern，只能按像素定位点击），故用探针 1 + 数据层 2 覆盖其判定与落盘逻辑。
- 构建 0 警告 0 错误。

## 2026-11-15 V1.2.215

**调整｜右键菜单去掉「导出注释」**

- `Controls/PdfPageView.cs` 的 `AddToolContextItems`（文档右键菜单）删除 `AddDocItem(ctx, "导出注释", …)` 一行；主菜单「文件 → 导出注释(_E)…」保持不变。
- 清理死代码：删除 `PdfPageView.RequestExportAnnotations` 事件声明，以及 `MainWindow` 里对它的 `+=` / `-=`（此前它已无任何触发点）。
- 验证：`PerfBench\ui_ctxmenu_check.ps1` 枚举文档右键菜单 —— 修复前 12 项含「导出注释」，修复后为「手型工具 / 适合宽度 / 护眼模式 / 查找文本 / 打开 / 另存为 / 打印 / 首选项 / 工具 / 粘贴 / 清空剪贴板 / 文档属性」；`CONTAINS_EXPORT=False`。构建 0 警告 0 错误。

## 2026-11-15 V1.2.214

**修复｜「添加注释」点确定后什么都没发生（内容全部丢失）**

- 现象：右键「工具 → 添加注释」或在选区上点「注释」→ 弹出批注卡片 → 输入文字点「确定」→ 页面上没有注释、保存按钮也不亮。
- P0-1 弹窗返回值被动画抹掉：`LayoutAnim.RegisterWindow` 对所有非主窗口挂 `Closing += OnDialogClosing`，里面 `e.Cancel = true` 先播 160ms 退场动画、动画结束再 `window.Close()`。WPF 在 Closing 被取消时会把 `DialogResult` 清成 null，于是 `TextInputDialog.ShowDialog()` 一律返回 **null**，`CreateNoteAt` / `EditNote` / `EditAnnotContents` 里的 `ShowDialog() == true` 判断必然失败 —— 用户输入被整份丢弃。日志实测：`[note-dialog] ok clicked textLen=13` → `closing DialogResult=True` → 90ms 后 `closing DialogResult=null`（第二次来自 `PopOut` 收尾的 `InternalClose`）→ `[note] dialog=False`。
  修复：`OnDialogClosing` 拦截前用局部变量记下 `window.DialogResult`，`Finish()` 里若结果非空则 `window.DialogResult = 结果`（赋值即关闭并带回原值），否则走原来的 `Close()`。
- P0-2 右键菜单「工具」项语义错位：`ActivateToolFromTag` 把 tag 交给 `OnToolClick`，而 `OnToolClick` 对 `Note/Highlight/Underline/Strikeout/Squiggly` 走 `ApplySelectionTool`（把标注打到选区）。没有选区时 `ApplySelectionTool` 直接 return → 工具没切换、页面上也点不出便签，表现为「点了没反应」。修复：菜单路径一律 `SelectTool(tag)`（图章例外，仍走按钮链路弹选章对话框）；`OnToolClick` 里若 `ApplySelectionTool` 返回 false 则改为切工具。
- P0-3 右键同一入口直接闪退：`ActivateToolFromTag` 用 `new RoutedEventArgs()`（无 `RoutedEvent`）调 `OnToolClick`，其中 `e.Handled = true` 抛 `System.InvalidOperationException: 每个 RoutedEventArgs 都必须有一个与其关联的非空 RoutedEvent`（Windows 事件日志 id 1000/1026，12:10:31 APPCRASH）。修复：传 `new RoutedEventArgs(Button.ClickEvent)`，并新增 `MarkHandled(RoutedEventArgs?)` 只在 `RoutedEvent != null` 时置位。
- P1-1 工具栏「注释」按钮原先要求先选中文字（`UpdateMarkupToolButtons` 把它和高亮等并在一起），但注释工具本身支持「点页面放便签」。改为 `_doc != null` 即可用（菜单项同理）。
- P1-2 `CreateNoteAt` 原先没有 try/catch，`AddFreeText` 抛异常会以未处理异常闪退；补 `Msg.Show` + `App.Log`。
- P1-3 `AnnotInfo.Title` 只取 `/Contents` 首行，而内部批注串是「作者␁时间␁正文」，列表标题会显示成「Frank2026-11-15 12:03:10.503正文」。改为取最后一个 `\u0001` 之后的部分。
- 验证：`PerfBench\ui_note_probe.ps1`（UIAutomation + 真实鼠标点击）在 PDF 副本上跑完整链路 —— 弹窗 `ShowDialog()=True`、页面出现 `ZZ probe note` 文本框、`SaveBtn=True`；Ctrl+S 后用 `PdfDocument` 直接读回 `p1#0 sub=3 contents=ZZ probe note`，关闭重开仍在。修复前同脚本为 `dialog=False` + `SaveBtn=False`。
- 受影响面提示：`OnDialogClosing` 是全局弹窗逻辑，除批注卡片外，凡是用 `ShowDialog() == true` 判断的对话框（自定义页面范围、页码/日期格式、水印预设命名等）此前都拿不到「确定」，本次一并修复。

## 2026-11-15 V1.2.213

**调整｜侧栏默认宽度 −2 px**

- `MainWindow.xaml`：`SidebarColumn` 布局默认宽度 202.4 → 200.4（未展开时的列宽口径）。
- `MainWindow.xaml.cs`：`_sidebarWidth` 初值 174 → 172（无记忆宽度时首次展开使用的默认宽度）；顺带修正过时注释（原写「沿用 XAML 默认 178」，实际早已不是该值）。
- 记忆值不受影响：`Loaded` 仍按 `AppPrefs.SidebarWidth > 0` 覆盖、拖分隔条仍写回 `_sidebarWidth` 并在退出时保存。
- 验证方法：把 `%APPDATA%\PdfReader\prefs.json` 的 `SidebarWidth` 置 0 后启动并打开文档，侧栏展开宽度应为 172；恢复该字段即可沿用原自定义宽度。

## 2026-11-15 V1.2.212

**优化｜「保存全部」图标换成叠层档案造型**

- 原图标为「两层软盘」，在 17.28px 工具栏尺寸下两片软盘的斜角贴得太近，容易读成「一个软盘多出一条折角」，与左侧「保存」的软盘也难区分。
- 换成叠层档案：`M4,8.6 L15.4,8.6 L19,12.2 L19,20.6 L4,20.6 Z`（主体，右上切角）+ 两条内容线 + `M8,5 L18.4,5 L21.4,8.1 L21.4,9.8`（顶部叠层折角）。参考 iconfont「保存全部」的叠层风格手绘为矢量描边路径（`ToolIcon` 样式，线宽 2.16、圆角端点），随主题前景色与禁用透明度自动变化。
- 验证：UIA 取 `SaveAllBtn` 的 BoundingRectangle 后按 12× 放大截图目检（正常/禁用两态形状一致、无粘连），工具见 `PerfBench\ui_icon_shot4.ps1`。

## 2026-11-15 V1.2.211

**修复｜「AI 分析」与「手型工具」在空状态下未禁用**

- 现象：未打开任何文档时，工具栏「AI 分析」（`AiAnalyzeBtn`，星形图标）与「手型工具」（`ToolHand`，抓手图标）仍呈可用态。点前者无意义，点后者会把光标切成抓手但没有页面可拖。
- 原因：`SetDocControlsEnabled(bool)` 的 ① 文档级开关清单里漏了这两个控件（`ToolTextBox`/`ToolRect`/`OcrBtn` 等都在，唯独缺它们），而两者的 code-behind 都没有自己的启用逻辑。
- 修复：清单补入 `AiAnalyzeBtn, ToolHand`；并在「无文档」分支里加 `if (CurrentTool != ToolMode.Select) BackToSelectTool();`（构造函数里 `CurrentTool` 已是 `Select`，不会在初始化阶段触发）。
- 验证：UIA 读 `IsEnabled` —— 无文档 `AiAnalyzeBtn=False ToolHand=False`（`ToolTextBox/OcrBtn/ZoomInBtn/SearchBtn` 同为 False）；打开文档全部 `True`；关闭后再次 `False`。

## 2026-11-15 V1.2.210

**修复｜内存压测（多文档 / 超多页 / 大容量）暴露的两处 P0 与两项高水位**

- P0-1 页句柄全量驻留：`MainWindow.LayoutSizes()` 逐页调 `Doc.GetPageRotation(i)`，而 `PdfDocument.GetPageRotation()` 内部 `GetPageHandle()` 加载后**不释放**（旋转值已进 `_pageRotations` 缓存，句柄却一直挂着）。`LayoutSizes` 在打开 / 缩放 / 双页切换 / 旋转时都会跑 → 2002 页手册打开即常驻 2001 个页句柄，工作集 1378 MB（数据层同文档仅 203 MB）。修复：`GetPageRotation` 读完即 `ReleasePage(index)`；新增 `GetAllPageRotations()`（单次加锁、逐页读完释放）；`LayoutSizes` 改用批量接口。复测：句柄 2001 → 2，工作集 1378 → 733 MB。
- P0-2 AutomationPeer 保活导致的文档泄漏：`close.Click += (_,_) => CloseTab(tab)`、`item.PreviewMouseDown`、`item.MouseDoubleClick` 三处闭包捕获 `DocTab`。`gcroot` 实测引用链 `UIA ref-counted handle → ElementProxy → TabItemAutomationPeer → ButtonAutomationPeer → Button → EventHandlersStore → 闭包 → DocTab → PdfDocument`。屏幕阅读器 / UIA 客户端在场时每开合一轮泄漏一份文档（435→628→786→974→1168 MB）。修复：改为实例处理器 `OnTabCloseClick / OnTabPreviewMouseDown / OnTabDoubleClick` → `CloseTabFromElement(sender)`，由元素经视觉树反查 `TabItem` 再用 `_tabs` 找 `DocTab`（不把 tab 放进 `Tag`）。对照实验（`ui_mem_cycle2.ps1` 不加载 UIA）证明修复前无 UIA 时第 2 轮即稳态 575 MB，修复后 UIA 在场也是 421/421/380/435/406 MB 稳态。
- P1-1 换下的页面位图等 GC：像素在非托管 MIL 层、托管包装仅几十字节，缩放重建 `WriteableBitmap` 后旧位图进 LOH 需 Gen2 + 终结器才归还（每档缩放 +400~550 MB，回缩不降）。修复：`PdfPageView.NoteRetiredBitmap()` 在三处（`ReleaseBitmap` / `WriteableBitmap` 重建 / `_bitmap` 换新）累计被换下的字节，≥96 MB 且距上次 ≥1.5 s 时后台 `GC.Collect(2, Forced, false)` + `WaitForPendingFinalizers` + 再收一次。复测：回缩后 2447 → 1821 MB，关完文档 452 → 415 MB。
- P1-2 `PerfLimits.MaxPagePixels` 上限 24M（96 MB/页）→ 12M（48 MB/页）。3 档缩放峰值 2455 → 2007 MB。
- 诊断过程中确认（非缺陷）：托管堆在关闭全部文档后仅 13.3 MB / 218k 对象，`PdfPageView` 0 个，`BitmapSourceSafeMILHandle` 18 个且 `gcroot` 均为窗口图标；数据层同一文档开合 6 轮仅 +3.5 MB。关闭后约 400 MB 常驻属 pdfium 库级缓存（字体/图像解码）+ WPF 渲染池，稳态不增长。
- 完整报告：`PerfResults\压测与内存分析报告_V1.2.210.md`；原始数据 `PerfResults\multidoc_20261115.csv`、`multidoc_cycle.csv`、`ui_mem_cycle_uia_fixed.csv`、`ui_mem_cycle_nouia.csv`、`ui_mem_stress_final.csv`、`dumpheap_stat.txt`。

## 2026-11-15 V1.2.209

**优化｜全量动效回归与过渡打磨**

- 回归方式：UIAutomation 驱动主窗口（侧栏开合 / 连点、查找栏开合、整页横移、Ctrl+滚轮缩放 HUD、右侧吸附栏开合与连点）逐帧截图比对；日志无异常。
- 缩放 HUD：`HideZoomHud` 用的是「查找栏」开关（`AnimKey.SearchBar`），改为 `AnimKey.Zoom`；`ShowZoomHud` / 拉杆拖动处原先 `ZoomHud.BeginAnimation(OpacityProperty, null)` 撤不掉引擎轨道（引擎只写本地值），淡出轨道会继续把 HUD 写到全透明而仍保持 Visible —— 改为零时长 `LayoutAnim.Fade(ZoomHud, 1, 1, 0)` 接管同槽轨道并落定。首次唤出额外加 170ms 轻微滑入。
- 缩放反馈回弹：`OnZoomChanged` 每滚一格都会重播 `Pulse`，连续缩放时缩放框一直停在缩小态。加 350ms 节流。
- 文档过渡遮罩（`BeginDocCrossFade` / `ResetDocCrossFade`）：新增 `_docOverlayToken` 代次；遮罩透明度改用引擎轨道（直接赋 `Opacity` 会被上一轮淡出轨道逐帧覆盖）；被接管的绽开遮罩不再执行 `Cleanup`（原来会把新一轮的 `OpacityMask` 与快照一起清掉）；新一轮过渡开始前清掉旧径向遮罩。
- 吸附栏（`SetAdvancedVisible`）：补 `StopPageAnimation()`；搜索词带入改为 `Settle()` 后再以 `DispatcherPriority.Background` 执行；宽度记忆加 `>= 220` 判定；新增 `AdvancedSplitter.DragStarted` —— 拖动前把列宽动画落定为当前宽度（`FinishColumn`），否则引擎每帧写回的列宽会压住 GridSplitter。
- 侧栏 / 吸附栏过渡状态：`_layoutAnimating` 布尔改为按容器计数的 `_layoutAnimBusy` + `_sidebarAnimGen` / `_advAnimGen`（`StartLayoutAnim` / `FinishLayoutAnim` / `CancelLayoutAnim`）。原来共用 `_layoutAnimToken`，两侧动画在 250ms 内接连触发会互相作废对方的收尾，导致面板宽度交不回列定义、适应缩放被永久挂起。
- 高级搜索结果（`RunAdvSearch` / `OnAdvPageExpanded`）：页节点只统计命中数，命中片段在展开该页时才生成；命中 ≤120 处且 ≤4 页时仍默认展开。2002 页文档搜 "fox 10"（113 页 / 2241 处）实测扫描 0.50s，面板滑入后结果立即出现，界面保持响应。
- 首选项分类切换：`OnCategoryChanged` 末尾按 `AnimKey.PrefsPages` 播放 `SlideIn`（12px、190ms），补齐此前无效果的开关。
- 验证：构建 0 警告 0 错误；上述场景逐帧截图复核，收尾无残留（无侧栏空带、无吸附栏残条、HUD 正常消失）。

## 2026-11-15 V1.2.208

**改进｜深色模式图标换成「半明半暗圆」**

- 需求：深色模式的图标改为系统「深色模式」同款：一个圆，左半浅、右半深。
- 处理（`MainWindow.xaml`）：`IconThemeMoon` 由单条弯月 `Path` 改为一个 `Grid`，内含
  1. 整圆描边 `Path`（沿用 `ToolIcon` 样式：17.28px、描边 2.16、颜色随按钮前景）；
  2. 右半圆填充 `Path`（`M12,4 A8,8 0 0 1 12,20 Z`，半径比外圈小 1px 留出细缝，`Fill` 绑定按钮 `Foreground`）。
- 代码零改动：`UpdateThemeQuickButton()` 只操作 `IconThemeMoon.Visibility`，容器改成 `Grid` 后依然成立。
- 验证：构建 0 警告 0 错误；启动后浅色状态下工具栏显示该图标，点按切换到深色并变为太阳。

## 2026-11-15 V1.2.207

**改进｜深浅色模式切换图标提到工具栏**

- 需求：把深色 / 浅色模式切换按钮从菜单栏右端移到工具栏。
- 处理（`MainWindow.xaml`，代码无需改动）：
  1. 删除菜单栏 `Grid` 的右列与其中的主题按钮 `Border`，菜单栏改回单列 `Border > Menu`；
  2. 工具栏 `DockPanel` 内、`SearchBtnHost` 之后新增 `BtnThemeToggle`（`DockPanel.Dock="Right"`，`ActionButton` 样式，34×34 命中区）；
  3. 太阳 / 月亮两条 `Path` 改用工具栏统一的 `ToolIcon` 样式（17.28px、描边 2.16、颜色跟随按钮 `Foreground`），控件名 `IconThemeSun` / `IconThemeMoon` / `BtnThemeToggle` 保持不变，因此 `UpdateThemeQuickButton()` 与「跟随系统」监听逻辑零改动。
- 验证：构建 0 警告 0 错误；启动后按钮位于查找按钮左侧，点按可在深浅色间切换。

## 2026-11-15 V1.2.206

**修正｜翻页过渡过程中出现黑条**

- 现象：整页横移翻页时，画面中有一条深色（近黑）竖条扫过。
- 两个成因（都已处理）：
  1. **接缝漏光**：`PageSlideOld`（旧页快照）与 `PageSlideNew`（新页快照）按「旧页右边缘 == 新页左边缘」精确衔接。合成时 double 位置取整 + 位图亚像素采样会让接缝出现 ≤1px 的半透明缝，漏出下层 `PageSlideLayer` 的深色背景（`Th.DocAreaBg`），形成一条随动画移动的黑条。
     修复：两张快照各多走 `SlideOverlap = 3px`，接缝处始终重叠，重叠部分由上层（旧页）盖住，不会漏底。
  2. **滚动条残影**：`CaptureViewport()` 直接 `RenderTargetBitmap.Render(PageScroll)`，把贴右边缘的滚动条一起抓进快照；横移时这条深色竖条会横穿画面。
     修复：抓图前把 `PART_VerticalScrollBar` / `PART_HorizontalScrollBar` 的 `Opacity` 置 0（保留占位、不改布局），抓图后在 `finally` 里恢复。
- 验证：构建 0 警告 0 错误；启动冒烟正常。

## 2026-11-15 V1.2.205

**优化｜取词翻译移动目标时反应慢**

- 现象：按住 Ctrl 把鼠标移到另一个词上，卡片要等很久才更新，甚至一直显示上一个词的释义。
- 根因：
  1. `RequestWordLookup` 里固定 `Task.Delay(220)` 防抖，且**每次都等完整的一次性响应**（`LlmClient.ChatAsync` 用空 `IProgress` 走非流式），大模型生成需要 1~3 秒；
  2. 缓存只在 `LookupAsync` 内部命中，仍要先经过 220ms 延时才知道命中；
  3. 换词期间 `_translateResult` 仍是旧词结果，卡片继续显示旧释义，看起来像「没反应」；
  4. `RefreshInfoCard` 每次刷新都 `IsOpen=false` + 丢弃 `Popup` 再重建，刷新本身也有闪烁与位置跳动。
- 修复：
  1. `WordLookup.TryGetCached()`：命中缓存同步返回，`RequestWordLookup` 直接显示，零延时零网络；
  2. 防抖缩短到 90ms（只过滤「鼠标划过不停留」）；
  3. 新增 `WordLookup.LookupStreamAsync()`：接上 `ChatAsync` 的 SSE 增量，首行到达即回调，`ParsePartial()` 丢掉末尾半行后先显示，之后 160ms 节流刷新；
  4. 换词时立即把卡片切成新词 + 「正在查询…」占位；
  5. `RefreshInfoCard` 复用同一个 `Popup`，只替换 `Child` 内容。
- 验证：构建 0 警告 0 错误；启动冒烟正常。

## 2026-11-15 V1.2.204

**修正｜展开/收起侧栏时文档区闪动，改为整体平移**

- 现象：点「收起侧栏 / 展开侧栏」时文档区有闪动、内容像是被重新排版而不是整体位移。
- 根因：旧实现用列宽动画（`GridLengthAnimation` 每帧改 `SidebarColumn.Width`）。列宽每帧变化 → 文档区（`PageScroll`）每帧重新布局 → `VirtualizingPagePanel.ArrangeOverride` 每帧给可见页重新定位 → 页面被反复重排/重绘；同时分隔条列宽是瞬时切换，会带来 6px 突跳。
- 处理（`MainWindow.xaml.cs` + XAML）：
  1. 侧栏容器加 `Name="SideHost"`；开合时把列宽（含 `SidebarSplitterColumn`）**一次设置到位**，`UpdateLayout()` 只重排一次；
  2. 开合前后各测一次视口内首个页面视图的屏幕 X（`FirstPageScreenX()`），差值为 Δ；
  3. 立刻把 `PagePanel.RenderTransform.X` 设为 −Δ（把内容按回旧位置），再用 `LayoutAnim.SlideX(docPan, 0, ms)` 滑到新位置 → 视觉是文档整体平移；
  4. 侧栏 `SideHost` 固定为整幅宽度，用 `RenderTransform` 整体滑出/滑入（`ZIndex=20` 盖在文档区上），内容不被逐帧压扁；
  5. 动画结束后把 `SideHost.Width` / `SidePanel.Width` 交回列定义（`double.NaN`），窗口缩放与拖分隔条照常；
  6. 拖分隔条（`SidebarSplitter.DragStarted`）与关闭动画两个分支都会复位平移轨道，避免残留位移。
- 验证：构建 0 警告 0 错误；UI 自动化连续「展开→收起→展开」三轮，进程存活、日志无异常。

## 2026-11-15 V1.2.203

**修正｜翻页动画会回闪，改为整页水平滑动**

- 现象：翻页时（页角卷起动画）画面有回闪/抖动，链接跟踪观感不干净。
- 根因：卷页是**几何动画**——每一帧都要重算折痕直线 `x+y=r`、用 `CombinedGeometry(Exclude)` 重新裁剪旧页、重建镜像 `MatrixTransform` 与折痕阴影 `PathGeometry`。这些操作都在 UI 线程与合成器之间反复触发重绘，动画帧率一旦跟不上就会出现「回跳、闪一下」。
- 处理：
  1. 删除整套卷页代码（`SlideProgress` DP、`SetSlideProgress`、`CurlShade`、`Tri`、`PageSlideCurl/CurlShade/Dim/Edge` 及其 XAML）；
  2. 改为**两张快照整体横移**：`LayoutAnim.SlideX` 分别驱动 `PageSlideOldShift` / `PageSlideNewShift` 的 `TranslateTransform.X`，旧页移出一屏、新页从另一侧补位；
  3. 方向按目标偏移判断：向下翻（下一页）新页自右进、旧页向左出；向上翻（上一页）新页自左进、旧页向右出；
  4. 平移只是合成器搬运位图，不重绘 → 无抖动、无回闪；
  5. `StartSlideAnimation` 前用 `LayoutAnim.ResetSlideX` 清掉上一次的残留位移与在途轨道，连点翻页不会从半途位置起跳；
  6. 两个 `Image` 关掉 `SnapsToDevicePixels`（避免平移时按整像素跳动），保留 `BitmapScalingMode=LowQuality` 做平滑插值。
- 保留：快照覆盖策略（快照下静默跳页、等目标页渲染完再抓第二张）、`ArmSlideWatchdog` 保险丝、收尾 70ms 淡出、`AnimKey.PageFlip` 开关。
- 验证：构建 0 警告 0 错误；启动冒烟正常。

## 2026-11-15 V1.2.202

**重构｜动效内核整体重写（帧驱动 + 速度接续），解决卡顿/闪动/过渡生硬**

- 需求：清除现有动效实现，重建一套仿 iPhone 的操作动效，要求流畅丝滑、不闪动、过渡自然。
- 旧实现的三个根因：
  1. **多时钟竞争**：每个过渡各起一条 `DoubleAnimation`，同一属性被两条动画先后接管时，`HandoffBehavior.SnapshotAndReplace` 只保证值连续、不保证速度连续，观感是「急停再起步」；
  2. **HoldEnd 暗伤**：动画结束后动画值仍以更高优先级压住本地值，后续任何赋值（透明度、变换）都被吃掉，必须逐处 `SetCurrentValue + BeginAnimation(null)` 收拾，漏一处就是「点了没反应」；
  3. **分散看门狗**：窗口最小化 / 渲染停摆时动画时钟停摆，每个调用点都要自己起 `DispatcherTimer` 兜底，逻辑重复且容易漏。
- 新实现（`LayoutAnim.cs` 全量重写）：
  - 单一时钟：所有轨道由 `CompositionTarget.Rendering` 逐帧推进，`Track` 保存 From/To/时长/曲线/初速度；
  - 速度接续：同 Key+Slot 的新轨道通过 `TakeOver()` 拿到旧轨道的 `ValueAt` 与 `VelocityAt`，弹簧用临界阻尼解析解 `x(t)=To+(A+Bt)e^(-ωt)` 继续走，ω=4600/ms；
  - 零残留：轨道只写本地值，完成即终值；完成回调统一在「精确落定之后」执行；
  - 统一看门狗：`Sweep()` 每 200ms 巡检，超时轨道强制落定并触发回调；
  - 曲线查表：`EaseInOut` 预生成 96 点表 + 线性插值，避免每帧几十次二分求解。
- 附带修正：
  - `Settle` 不再叠加 −6px 位移与 0.88 二次淡入（树展开后整块内容会「先跳一下」）；
  - `SlideIn` 的透明度改为「只向不透明收拢」（侧栏页签每次切换都完整淡入 = 闪一下）；
  - `StaggerRows` 的延迟行同步落到起点（否则延迟期先显示、再跳回透明）；
  - 页面旋转改走 `RotateIn`，结束即清变换，无 HoldEnd 残留。
- 兼容性：对外 API 签名与语义全部保留（`On`/`Dur`/`Fade`/`PopIn`/`PopOut`/`Pulse`/`SlideIn`/`SlideY`/`Settle`/`StaggerRows`/`Flash`/`AnimateColumn`/`FinishColumn`/`RefreshPopups`/`ThemePulse`/`AttachGlobal`/`Enabled`/`Decel`/`Spring`/`Glide`/`Smooth`/`IosDuration`），42 处调用点零改动；`ms<=0` 仍表示「立即落定 + 同步回调」。
- 验证：构建 0 警告 0 错误；启动冒烟无异常。

## 2026-11-15 V1.2.201

**优化｜筛选弹窗「应用」按钮无用，移除**

- 现象：勾选筛选条件（选择者/类型/时间）后列表已即时生效，再点「应用」只是关闭弹窗，按钮形同虚设。
- 处理：`MainWindow.xaml` 删除 `CommentFilterApply` 按钮，底部仅留「全部清除」；`MainWindow.xaml.cs` 删除对应 `OnCommentFilterApply` 处理器。
- 关闭弹窗方式不变：右上角 ✕、或再次点击漏斗按钮（`StaysOpen=False` 亦支持点外部收起）。

## 2026-11-15 V1.2.199

**修正｜漏斗角标数字一直显示成 0（真因是图标字体）**

- 现象：筛选命中 1 条时，漏斗角标始终显示成一个圆圈（形似 0），与列表数量不符。
- 排查过程（重要）：
  1. 先怀疑缓存/统计口径，先后改为「缓存命中数」→「列表渲染行数」，日志 `[badge]` 均显示 `text=1`；
  2. 加可视化树诊断 `[vt]`：`wins=1 badgeVis=True badgeSize=15.2x15.2 texts=[1|vis=True|fs=9]`——元素、可见性、文案全对，但屏幕渲染仍是圆圈；
  3. 对比 `App.xaml` 的 `ToolButton` 样式发现 `FontFamily="Segoe MDL2 Assets"`（图标字体）与 `FontSize=19.2`，角标 TextBlock 只覆盖了 FontSize，字体继承为图标字体 → 数字 1 被渲染成图标字形。
- 修复（`MainWindow.xaml`）：`CommentFilterBadgeText` 显式 `FontFamily="Segoe UI"`；同时保留 15×15/9 号加粗/白描边，命中数写入 `CommentFilterBtn.ToolTip`。
- 教训：**放在图标字体控件（ToolButton/NavButton/SideToolBtn 等）内部、需要显示普通文字/数字的 TextBlock，必须显式指定 FontFamily**，否则字符会被当图标渲染。
- 验证：构建 0 错 0 警、lints 0、dll 哈希一致；待 GUI 复测（勾选条件后角标显示 1）。

## 2026-11-15 V1.2.195

**优化｜所有标注清除类图标统一为垃圾桶**

- 需求：所有「标记清除」图标改为垃圾桶图标。
- 改动：
  1. `Controls/PdfPageView.cs` 浮动工具栏：`actions.Add((IconBroom, "清除", ...))` → `IconTrash` + `IconTrashStroke`（与工具栏「删除」同一个带盖垃圾桶：`M 4.5,6.5 L 19.5,6.5 M 10,6.5 L 10,3.5 L 14,3.5 L 14,6.5 M 7,9.5 L 7,20.5 L 17,20.5 L 17,9.5 M 10.3,11.5 L 10.3,18 M 13.7,11.5 L 13.7,18`）；
  2. `MainWindow.xaml` `CommentClearBtn` 的 Path 由简版垃圾桶 `M4,7 H20 M9,7 V4 H15 V7 M7,7 L8,20 H16 L17,7` 换成上面同款图形，两处视觉一致；
  3. 删除已无引用的 `IconBroom`/`IconBroomStroke` 常量（避免遗留误用）。
- 不变量：两个按钮的 ToolTip、点击逻辑、禁用态判定不变；标注列表行内的 ✕ 删除按钮未改动（那是行内删除，不是「清除标记」）。
- 验证：构建 0 错 0 警、lints 0、部署 dll 哈希与构建产物一致；待 GUI 复测（选中标注 → 浮动工具栏第三枚为垃圾桶；侧栏漏斗右侧同为垃圾桶）。

## 2026-11-15 V1.2.194

**修正｜漏斗角标仍显示 0（V1.2.193 依赖缓存统计，缓存作废即失效）**

- 现象（用户截图，V1.2.193）：列表筛出 1 条（页 2 (1)），角标仍为 0。
- 根因：角标数量仍走「缓存统计」分支，而该分支要求 `AnnotCacheValid == true`；`RebuildCommentList()` 会把缓存置为无效（后台重扫未完成），此时列表用旧缓存渲染出 1 条，角标却被跳过 → 0。另：筛选/搜索变化时 `FillCommentTree` 同样被 `AnnotCacheValid` 卡住，导致列表不刷新、与角标彻底脱节。
- 修复（`MainWindow.xaml.cs`）：
  1. `UpdateCommentFilterBadge`：无 override 时**直接数 `CommentTree` 里 Tag 为 int 的页节点的子项数**（即界面实际渲染的标注行数），完全不依赖缓存有效性；
  2. `OnCfItemChanged` / `OnCommentSearchChanged` / `OnCommentFilterClear`：重建条件由 `AnnotCacheValid == true` 放宽为 `AnnotPageCache.Count > 0`（有内容就重新过滤），并在重建后再刷一次角标；
  3. `CommentClearBtn.IsEnabled = cond > 0 && matched > 0`（无筛选时即便列表有内容也禁用，防误删全部）。
- 踩坑：`OnCfItemChanged` 里 foreach 已有 `cb.Tag is int t`，模式变量再用 `t` 触发 CS0136，改名 `cur`。
- 验证：构建 0 错 0 警、lints 0、部署 dll 哈希与构建产物一致；待 GUI 复测（筛出 1 条 → 角标 1；改筛选列表即时刷新）。

## 2026-11-15 V1.2.193

**修正｜筛选出 1 条记录，漏斗角标仍显示 0**

- 现象（用户截图，V1.2.189）：列表已筛出 1 条（页 2 (1)），漏斗按钮角标仍为 0；状态栏显示「已清除 1 条符合筛选的标注」，说明是清除之后的状态。
- 根因：V1.2.189 的 `UpdateCommentFilterBadge` 统计命中数时有前置条件 `_active is { AnnotCacheValid: true }`；`OnClearMatchingComments` 删除后若 `anyFailed` 会调 `RebuildCommentList()`，该方法把 `AnnotCacheValid` 置 false（后台重扫未完成）；随后 `FillCommentTree` 仍用旧缓存渲染出 1 条，而角标统计被跳过 → `matched=0`，角标显示 0（条件数 cond>0 所以可见）。
- 修复（`MainWindow.xaml.cs`）：
  1. `FillCommentTree` 累加 `int shown`（各页 `items.Count` 之和），末尾 `UpdateCommentFilterBadge(shown)`——角标与列表同源，必然一致；
  2. `UpdateCommentFilterBadge(int matchedOverride = -1)`：`matchedOverride ≥ 0` 时直接采用（不再判断 `AnnotCacheValid`），否则回退按缓存统计。
- 不变量：`cond`（类型+作者+时间勾选数）仍决定角标显隐与清除按钮可用性判断；`CommentMatch` 谓词未变。
- 验证：构建 0 错 0 警、lints 0；待 GUI 复测（筛选出 1 条 → 角标显示 1；清除后剩余命中数同步变化）。

## 2026-11-15 V1.2.192

**修正｜「清除符合筛选条件的标注」只清了标注栏，文档页面上的标注仍在**

- 现象（用户截图，V1.2.189）：筛选后点清除，列表变「无匹配的注释」、状态栏提示「已清除 1 条」，但页面上的标注（粉色墨迹）仍显示，本页标注数未减。
- 根因：标注在 pdfium 里删除后，页面显示的是**已渲染位图**，不重渲染就仍显示旧标注。单条删除 `DeleteCommentAnnot` 里有 `if (ViewAt(page) is { } pv) _ = pv.RenderAsync();`，而 V1.2.184 的 `OnClearMatchingComments` 批量删除漏了这一步；另外批量删除忽略了 `DeleteAnnot` 的 bool 返回值（索引失效时静默失败）。
- 修复（`MainWindow.xaml.cs` `OnClearMatchingComments`）：
  1. 先遍历缓存收集 `(page, 命中 index 降序列表)` 到 `hitsByPage`（不在遍历中改缓存）；
  2. `BeginUiBatch` 内逐页逐 index 调 `doc.DeleteAnnot`，用 `anyFailed` 记录任一失败；
  3. **批量门释放后**对每个受影响页 `ViewAt(page) is { } pv → pv.RenderAsync()`（批量门内渲染会被排队/阻塞，故放外面，与 `DeleteCommentAnnot` 一致）；
  4. `anyFailed` 时 `RebuildCommentList()` 按真实状态重建列表；
  5. 逐页 `OnAnnotChanged(page)`（撤销快照/保存按钮/状态栏/注释列表），只对受影响页调用，不再遍历全部缓存页。
- 验证：构建 0 错 0 警、lints 0；待 GUI 复测（筛选→清除→确认：列表与页面标注同时消失，本页标注数减少，保存按钮亮起）。

## 2026-11-15 V1.2.191

**优化｜标注列表文字颜色正常显示，取消奇偶行交替配色**

- 现象（用户截图）：侧栏标注列表的行文字按奇偶行交替着色（默认奇数行 #1373E8 蓝、偶数行 #1E8E3E 绿），与标注自身颜色混在一起，阅读不适。
- 根因：`MakeCommentItem` 用 `AppPrefs.CommentOddColor/CommentEvenColor` 按 `rowIdx` 奇偶给标题与内容设 Foreground；`PdfPageView.BuildAnnotationSection` 同样按序号交替着色。
- 修复：
  1. `MainWindow.xaml.cs` `MakeCommentItem`：删除 `rowHex/rowBrush` 构造，标题与内容改 `SetResourceReference(TextBlock.ForegroundProperty, "Th.Text")`（跟随主题正文色，含夜间/护眼）；
  2. `Controls/PdfPageView.cs` `BuildAnnotationSection`：删除奇偶 `rowBrush`，注释文字同样 `SetResourceReference(..., "Th.Text")`，与侧栏一致。
- 不变量：行首色块仍显示标注自身颜色；删除按钮仍用 `Th.TabActiveAccent`；`AppPrefs.CommentOddColor/CommentEvenColor` 字段与首选项面板暂保留（不参与列表渲染），删除会造成配置不兼容，故不动。
- 验证：构建 0 错 0 警、lints 0；待 GUI 复测（列表各行文字颜色一致=主题正文色；切换夜间主题后文字仍清晰）。

## 2026-11-15 V1.2.190

**修正｜筛选弹窗仍覆盖标注列表（V1.2.189 的 Placement=Right 不够）**

- 现象：改用 `Placement="Right"` 后弹窗仍贴着按钮右侧展开，左侧边缘落在侧栏内，仍会盖住标注行的右侧区域（含行尾按钮）。
- 修复（`MainWindow.xaml` + `MainWindow.xaml.cs`）：
  1. Popup 改 `Placement="Custom"` + `CustomPopupPlacementCallback="OnPlaceCommentFilterPopup"`，`PlacementTarget` 换成侧栏面板 `SidePanel`（不再绑按钮）；
  2. 新增 `OnPlaceCommentFilterPopup(Size popupSize, Size targetSize, Point offset)`：返回 `new CustomPopupPlacement(new Point(targetSize.Width + 4, 0), PopupPrimaryAxis.Horizontal)`——弹窗左上角 = 侧栏右边缘 +4px、与侧栏顶端对齐；
  3. 移除 `HorizontalOffset/VerticalOffset`（Custom 模式下由回调坐标决定）。
- 效果：弹窗整体落在右侧文档区，侧栏标注列表零遮挡；窗口缩放、侧栏拖宽、DPI 变化时都贴侧栏右边缘，不会漂移回列表上方。
- 验证：构建 0 错 0 警、lints 0；待 GUI 复测（点漏斗 → 弹窗出现在文档左上、侧栏列表完整可见可点）。

## 2026-11-15 V1.2.189

**修正｜筛选弹窗压住标注列表 + 漏斗角标始终显示 0**

- 现象（用户截图，V1.2.185）：①筛选弹窗在侧栏左下展开，盖住标注列表项；②漏斗按钮角标不显示「符合筛选条件的标注数量」，始终为 0。
- 根因：
  1. `CommentFilterPopup` 为 `Placement="Bottom"` + `HorizontalOffset="-196"`（朝左下展开），落点正好压在侧栏标注列表上；
  2. `UpdateCommentFilterBadge` 计算的是「勾选的条件个数」（`_commentTypes.Count + _commentAuthors.Count + _commentDates.Count`），不是命中标注数；且列表重建后没有重新计算。
- 修复：
  1. `MainWindow.xaml`：Popup 改 `Placement="Right"` + `HorizontalOffset="2"` + `VerticalOffset="-6"`——在漏斗按钮右侧（文档区域）展开，不再遮挡标注项；
  2. `MainWindow.xaml.cs` `UpdateCommentFilterBadge`：改为 `cond`（条件数，决定角标显隐）与 `matched`（按 `CommentMatch` 遍历 `AnnotPageCache` 求和，即命中标注条数，作为角标文本）；`CommentClearBtn.IsEnabled = matched > 0`（条件存在但命中为 0 时同样禁用）；
  3. `FillCommentTree` 末尾调用 `UpdateCommentFilterBadge()`，扫描完成 / 删除标注 / 换文档 / 搜索变化后角标自动同步。
- 不变量：`CommentMatch` 逻辑（类型/作者/日期 + 搜索词）不变；`OnClearMatchingComments` 仍用同一谓词统计与删除，角标数与删除数一致。
- 验证：构建 0 错 0 警、lints 0；待 GUI 复测（弹窗在文档区域展开不压列表；勾选「类型→印章」后角标显示命中条数，如 1；清空条件后角标隐藏、清除按钮变灰）。

## 2026-11-15 V1.2.188

**修正｜本程序添加的水印 / 页眉页脚在标注列表显示为「印章」**

- 现象（用户截图）：侧栏标注列表里「添加水印」创建的标注，类型项显示「印章」，用户期望显示「水印」。
- 根因：`GetAnnotationsOfPage` 仅按 PDF 子类型显示中文名，水印与页眉页脚底层都是 STAMP 子类型，统一显示为「印章」，未识别本程序 `AddMarkedStamp` 写入的标记键（水印 `PdfReaderWatermark`、页眉页脚 `PdfReaderHeaderFooter`）。
- 修复（`Pdf/PdfDocument.cs` `GetAnnotationsOfPage`）：stamp 子类型下读 `WatermarkKey`/`HeaderFooterKey`（值为 "1"）标记键，命中则把 `name` 覆盖为「水印」/「页眉页脚」，再构造 `AnnotInfo`。`SubtypeName` 影响行文本（作者-类型-时间）、筛选「类型」分组、悬浮提示三处，全部跟随正确名称。
- 不变量：外部/他人创建的普通图章（无标记键）仍显示「印章」；`SubtypeName` 静态映射其余子类型不变。
- 验证：构建 0 错 0 警、lints 0；待 GUI 复测（本程序水印显示「水印」、页眉页脚显示「页眉页脚」、他人图章仍「印章」）。

## 2026-11-15 V1.2.187

**修正｜新建标注未写入作者（/T）与时间（/M），列表行显示「（无作者）」且无时间**

- 现象（用户截图，V1.2.185）：软件内新画的画笔/矩形标注在列表显示「（无作者）- 加粗」等，无时间段。
- 根因（`Pdf/PdfDocument.cs`）：V1.2.183 起列表行读 /T + /M（回退 /CreationDate），但本版 pdfium `FPDFPage_CreateAnnot` 不会自动补这两项，而创建路径只有 `AddTextMarkup` 写了 /T，`AddShape`/`AddInk`/`AddFreeText`/`AddStamp` 均未写；且所有路径都没写 /M → 读不到即「（无作者）」+无时间。
- 修复：
  1. 新增私有 `TKey`/`MKey` 字节数组与实例方法 `StampAuthorAndTime(nint annot)`：写 /T=AuthorName（默认 Environment.UserName）、/M=DateTime.Now.ToString("D:yyyyMMddHHmmss", InvariantCulture)（初版误带包裹引号已去掉）；
  2. 调用点：`AddTextMarkup`（原内联 /T 改为助手，补 /M）、`AddShape`、`AddInk`、`AddFreeText(st)`、`RecreateFreeText`（移动/改字重建）、`AddStamp`（OCR 不可见文字层与链接不写，属内部层）；
  3. 三处「改样式重建」（squiggly/ink/square 重建，原只回填 /T）补写 /M 刷新为当前时刻，作者仍保留原值。
- 不变量：PDF 里已存在的旧标注（本就没存 /T//M）不受影响，仍显示「（无作者）-类型」；`AnnotHit`/悬停提示读 /T 链路不变。
- 验证：构建 0 错 0 警、lints 0；待 GUI 复测（新画标注列表行显示 `Frank-墨迹-2026-11-15 HH:mm`；旧标注仍（无作者），需重画）。

## 2026-11-15 V1.2.186

**优化｜检测到已有实例但无法通信时，提示失败原因并指引任务管理器手动关闭**

- 需求：软件启动失败、检查到已有运行实例时，提示失败原因，并建议用户在任务管理器查看软件进程手动关闭。
- 改动（`App.xaml.cs` `OnStartup` 第二实例分支 + `ForwardToRunningInstance`）：
  - `ForwardToRunningInstance` 由 `void` 改为 `bool`：管道连上并写入参数返回 `true`，连不上（50×100ms 重试仍失败）返回 `false`；
  - 第二实例分支：先尝试转发；`forwarded==true` 则静默 `Environment.Exit(0)`（保留双击 .pdf 在已有窗口打开的便利）；`forwarded==false` 则 `Msg.Show(null, 文本, "启动失败", OK, Warning)`，文本说明「已在运行但无法与之通信（多因上次异常退出进程残留占用启动锁）」，并分 4 步指引：Ctrl+Shift+Esc 打开任务管理器 → 进程找「XC PDF Reader」→ 结束进程 → 重启；随后 `Environment.Exit(0)`。
- 设计取舍：不破坏正常场景下「第二实例把文件交给首实例、聚焦窗口」的体验，只在「互斥体被占用却连不上管道」这一真正起不来的场景下弹提示——覆盖用户描述的启动失败情形。
- 验证：构建 0 错 0 警、lints 0；待 GUI 复测（①正常双开：第二实例静默、文件在首实例打开；②模拟残留互斥体：第二实例弹「启动失败」提示+任务管理器指引）。

## 2026-11-15 V1.2.185

**修正｜启动失败：XamlParseException「"ToggleButton" TargetType 与元素 "Button" 的类型不匹配」**

- 现象（用户截图）：V1.2.184 启动即弹「启动失败」：`System.Windows.Markup.XamlParseException: 设置属性 "System.Windows.FrameworkElement.Style" 时引发了异常 ---> InvalidOperationException: "ToggleButton" TargetType 与元素 "Button" 的类型不匹配`（StyleHelper.UpdateStyleCache → CheckTargetType）。
- 根因：V1.2.184 在漏斗按钮后新增的 `CommentClearBtn`（Button）误套了 `Style="{StaticResource ToolButton}"`——`ToolButton` 样式的 TargetType 是 `ToggleButton`（漏斗按钮本身是 ToggleButton 所以没事），WPF 样式 TargetType 校验在解析 XAML 时直接抛异常，程序无法启动。构建期不报错（XAML 运行时才解析），故 0 错 0 警没能提前暴露。
- 修复（`MainWindow.xaml`）：`CommentClearBtn` 样式改 `Style="{StaticResource ActionButton}"`（TargetType 为 Button 的同族样式，`SidebarCollapseBtn` 等同样在用）；`Width=26 Height=26`、垃圾桶 Path（ToolIcon）、`IsEnabled=False` 默认、`Click=OnClearMatchingComments` 均不变。
- 教训：套 `ToolButton` 样式的必须是 `ToggleButton`；`Button` 用 `ActionButton`。
- 验证：构建 0 错 0 警、lints 0；待 GUI 复测（程序可正常启动，漏斗后垃圾桶按钮灰色禁用，勾选筛选后亮起）。

## 2026-11-15 V1.2.184

**优化｜漏斗后加「清除匹配标注」按钮 + 筛选新增时间维度、去掉颜色维度**

- 需求：漏斗后加清除图标（有筛选时 enable，点击清除符合条件的标注，无筛选 disable）；筛选项增加时间条件，去掉颜色选项。
- 改动（`MainWindow.xaml` / `MainWindow.xaml.cs` / `Pdf/PdfDocument.cs`）：
  1. XAML：搜索框行加第三列 `CommentClearBtn`（`ToolButton` 样式 + 垃圾桶 Path `M4,7 H20 M9,7 V4 H15 V7 M7,7 L8,20 H16 L17,7`，`IsEnabled=False` 默认）；筛选弹窗去掉 `CfColorHdr/CfColorList`，新增 `CfDateHdr/CfDateList`（时间分组）；漏斗 ToolTip 去掉「颜色」。
  2. `AnnotInfo` 新增 `DateKey`（Time 前 10 位 `yyyy-MM-dd`，无时间 null）。
  3. 筛选集合 `_commentColors` → `_commentDates`（HashSet<string> 日期桶 "yyyy-MM-dd" / "（无时间）"）；`CommentMatch` 去颜色、加日期；`SyncCommentFilters` 重建改用 `BuildCfCheckList(CfDateList,...)`（删颜色色块行）；`OnCfItemChanged`/`OnCommentFilterClear` 改日期；`OnCfSectionToggle` 映射 `CfDateHdr→CfDateList`；空列表提示条件 `_commentDates`。
  4. `UpdateCommentFilterBadge` 计算 `n=类型+作者+日期`，并 `CommentClearBtn.IsEnabled = n>0`（无筛选禁用）。
  5. 新增 `OnClearMatchingComments`：统计命中数 `count`；0 则双保险返回；否则 `Msg.Show` 确认（YesNo/Warning）；`PdfDocument.BeginUiBatch` 内对 `AnnotPageCache` 每页取命中标注 index 降序 `doc.DeleteAnnot(page,idx)`（删高位不影响低位 index），逐页 `OnAnnotChanged(page)` 刷新（撤销快照+保存按钮+列表）。
- 边界：删前确认避免误删；按页降序删除规避 index 错位；无筛选时按钮禁用且 `count==0` 双保险。
- 验证：构建 0 错 0 警、lints 0；待 GUI 复测（加筛选→垃圾桶亮起可点→确认后匹配标注被删；弹窗有 选择者/类型/时间 三组、无颜色）。

## 2026-11-15 V1.2.183

**优化｜标注列表行文本改为「所有者(作者)-标注类型-时间」**

- 需求（用户截图）：侧栏标注列表项显示为 所有者(作者)-标注类型-时间 的名称。
- 改动（`Pdf/PdfDocument.cs`）：
  1. `AnnotInfo` record 增加第 9 参 `string? Time = null`（带默认值，其它 new AnnotInfo 调用点无须补参）；
  2. 新增静态 `AnnotInfo.ParsePdfDate(string?)`：解析 PDF 日期（`D:YYYYMMDDHHmmSS+hh'mm`），TakeWhile 取前段数字、按位切 YYYY/MM/DD/HH/mm/SS，输出 `yyyy-MM-dd HH:mm`，失败返回 null；
  3. `GetAnnotationsOfPage`：时间读 `/M`（FPDFAnnot_GetStringValueByKey(annot,"M")），空则回退 `"CreationDate"`，经 `AnnotInfo.ParsePdfDate` 传入（首版在 PdfDocument 类内直接调 `ParsePdfDate` 致 CS0103，改为 `AnnotInfo.ParsePdfDate` 限定）；
  4. `RowText` 由「标题 - 作者」改为 `作者-SubtypeName-时间`（无作者→「（无作者）」，无时间省略段）；`RowText` 仅 `MakeCommentItem` 一处使用，改动面可控。
- 不变量：`CommentMatch` 搜索/筛选仍按 Contents/Author/Subtype/Color；`Title`（内容首行）保留用于悬浮提示/展开；AI 分析对话框不使用 RowText。
- 验证：构建 0 错 0 警、lints 0；待 GUI 复测（本页标注行显示如 `（无作者）-方形工具-2026-11-15 10:20`；旧文档无 /M 的标注显示 作者-类型）。

## 2026-11-15 V1.2.182

**优化｜「清除」按钮刷子图标改用 iconfont「清除数据库」同款造型**

- 需求（用户提供 iconfont「清除」搜索页截图并圈选）：刷子图标采用该斜柄扫帚造型。
- 改动（`Controls/PdfPageView.cs`）：`IconBroom` 由「竖直柄+喇叭刷头+刷毛纹」改为 `"M 21,3 L 10.8,13.2 M 9.4,11.2 L 12.2,15.2 L 9.2,18.2 L 5.8,14.2 Z M 3,21 L 11,21"`——45° 斜柄从右上 (21,3) 扫到刷头顶边中点 (10.8,13.2)、斜置正方形刷头（四角沿柄轴向 ±2 垂直偏移）、刷头下方地面横线；`IconBroomStroke` 仍 2.2。按钮名称「清除」/ 事件 `DeleteSelectedAnnot` 不变。
- 不变量：24 网格直线描边、与 IconPen/IconTrash 同一视觉语言；其余浮动工具栏按钮不动。
- 验证：构建 0 错 0 警、lints 0；待 GUI 复测（选中标注 → 浮动工具栏第三枚按钮显示斜柄扫帚+地面线图标）。

## 2026-11-15 V1.2.181

**修正｜筛选弹窗取不到所有标注的所有者 / 类型 / 颜色（三组为空）**

- 现象（用户截图）：打开「选择筛选条件」弹窗，选择者 / 类型 / 颜色三个分组下没有任何复选项；但文档里已有标注（状态栏"本页标注 2 个"）。
- 根因：`SyncCommentFilters`（按 `AnnotPageCache` 缓存重建筛选选项）只在两处被调用——注释面板首次扫描完成（`AnnotCacheValid=true` 时激活面板 / 扫描结束）与（V1.2.177 初版）此后不再刷新。用户在打开面板**之后**用浮动工具栏新建的标注（红框 / 红椭圆 / 红文字等）虽会经 `RefreshCommentListForPage` 更新页缓存，但筛选弹窗打开时不会重建选项 → 三组为空。
- 修复（`MainWindow.xaml` + `MainWindow.xaml.cs`）：
  1. `CommentFilterPopup` 增加 `Opened="OnCommentFilterPopupOpened"`；
  2. 新增处理 `OnCommentFilterPopupOpened(object? sender, EventArgs e)`（注意 `Popup.Opened` 是 `EventHandler` 而非 `RoutedEventHandler`，首版签名写错致 CS0123 已改）：`if (_active is { AnnotCacheValid: true }) SyncCommentFilters();`——弹窗每次打开都按最新缓存重建三组复选项；重建在 `_cfSyncing` 下进行，已勾选的筛选条件（`_commentTypes/_commentAuthors/_commentColors`）原样保留，角标计数同步。
- 不变量：筛选仍即时生效（勾选即刷列表）；扫描进行中（`AnnotCacheValid=false`）打开弹窗为空属预期，扫描完成后自动刷新。
- 验证：构建 0 错 0 警、lints 0；待 GUI 复测（画几个不同颜色 / 作者 / 类型的标注后打开弹窗，三组应列出全部候选且包含新建项）。

## 2026-11-15 V1.2.180

**优化｜标注浮动工具栏删除按钮改名「清除」+ 图标改清理刷子**

- 需求（用户截图圈出选中标注的浮动工具栏删除按钮）：名称改为「清除」，图标改为「清理」的刷子图标。
- 改动（`Controls/PdfPageView.cs`）：
  1. 新增 `IconBroom` 常量（24 网格直线描边、`IconBroomStroke=2.2`，与 `IconPen`/`IconTrash` 同一视觉语言）：`"M 12,2.5 L 12,10 M 9.5,10 L 14.5,10 L 17,21 L 7,21 Z M 10.6,13 L 9.9,21 M 13.4,13 L 14.1,21"`（竖直扫帚柄 + 喇叭形刷头梯形 + 刷头内两道斜向刷毛纹）；
  2. 浮动工具栏按钮 `actions.Add(...)` 由 `(IconTrash, "清除标注", ...)` 改为 `(IconBroom, "清除", ...)`，仍调 `DeleteSelectedAnnot`。
- 不变量：`IconTrash` 常量保留未删（无编译警告）；按钮位置/尺寸/其余按钮（便签、取色）不变；注释树行内 ✕ 删除与右键清除标注逻辑不变。
- 验证：构建 0 错 0 警、lints 0；待 GUI 复测（选中标注 → 浮动工具栏第三枚按钮显示扫帚图标、悬停提示「清除」）。

## 2026-11-15 V1.2.179

**优化｜标题栏不再显示文档名**

- 需求：标题栏无需再显示文档名。
- 改动（`MainWindow.xaml.cs`）：去掉三处带文档名的标题拼接，统一 `Title = AppTitleBase`：①打开文档（原 `$"{tab.Title} - {AppTitleBase}"`）；②保存后（原 `$"{Path.GetFileName(_doc.FilePath)} - {AppTitleBase}"`）；③另存为后（原 `$"{Path.GetFileName(saveAsPath)} - {AppTitleBase}"`）。构造函数初始与无文档时的 `Title = AppTitleBase` 本就只显示软件名+版本号，维持不变。
- 不变量：文档名仍显示在其他位置（如 `StatusLeft` 状态栏、多文档标签栏 `RefreshTabTitle`），仅窗口标题栏不再重复显示；多文档标签栏未受影响。
- 验证：构建 0 错 0 警；待 GUI 复测（打开/保存/另存为任意文档，标题栏恒为「XC PDF Reader V1.2.179」）。

## 2026-11-15 V1.2.178

**优化｜侧栏标签「注释」改「标注」+ 底部每个标签加对应图标**

- 需求：①侧栏注释标签改为标注；②给底部单个标签都加上对应图标。
- 改动（`MainWindow.xaml` `SideTabs` 三个 `TabItem.Header`）：原 `HeaderedContentControl.Header` 内的纯 `TextBlock` 改为 `StackPanel(Orientation=Horizontal)` 内 `Path` 图标 + `TextBlock`；图标 `Stroke={DynamicResource Th.Text}`（随主题变色）、`StrokeThickness=2` 圆角线帽、`Width/Height=15`、`Stretch=Uniform`、`Margin=0,0,4,0`：
  - 书签 `TabItem Name=OutlineTab`：`Data="M6,3 H18 V21 L12,16 L6,21 Z"`（书签形）；
  - 页面 `TabItem`（无名）：`Data="M6,3 H14 L18,7 V21 H6 Z M14,3 V7 H18"`（文档带折角）；
  - 注释 `TabItem Name=CommentTab`：`Data="M4,4 H20 V15 H13 L9,19 V15 H4 Z"`（对话气泡），`Text="标注"`。
- 不变量：标签名 `CommentTab` 不变（后台 `OnSideTabChanged` 仍靠它识别）；图标与文字同色 `Th.Text`，明暗主题均可读；页签条仍是底部 `UniformGrid` 等分。
- 验证：构建 0 错 0 警、lints 0；待 GUI 复测（底部三标签：书签/页面/标注 各带图标；「注释」已变「标注」）。

## 2026-11-15 V1.2.177

**重构｜注释面板筛选改为 Adobe 式漏斗筛选弹窗（用户截图对照）**

- 需求：注释筛选（原 2×2 下拉框 + 清除按钮）改为像 Adobe 的漏斗形状筛选弹窗选择操作。
- 改动：
  1. `MainWindow.xaml` 注释标签页：移除 `CommentTypeFilter/CommentAuthorFilter/CommentColorFilter` 三个下拉与 2×2 网格，改为搜索框 + `CommentFilterBtn` 漏斗按钮（`ToolButton` 样式 + 漏斗 Path + `CommentFilterBadge` 角标）；`CommentFilterPopup`（Placement=Bottom，IsOpen 双向绑定按钮 IsChecked，StaysOpen=False 点外部关闭）内含「选择筛选条件」标题 + ✕、三个可折叠分组（`CfSectionHeader` 模板：三角箭头 IsChecked 转 90°，`OnCfSectionToggle` 按名称映射折叠 `CfAuthorList/CfTypeList/CfColorList`）、底部「全部清除 / 应用」。
  2. `MainWindow.xaml.cs`：筛选字段单值（`int?/string?`）→ 多选 `HashSet<int> _commentTypes / HashSet<string> _commentAuthors / _commentColors`（空集合=不限）；`CommentMatch` 按集合判断；`SyncCommentFilters` 重建复选项（`BuildCfCheckList`，颜色行为色块+色号）、清失效旧值、`_cfSyncing` 抑制同步期间 Checked 回调；`OnCfItemChanged` 从复选项回读集合并即时刷新；`UpdateCommentFilterBadge` 角标计数；`OnCommentFilterClear` 全清（保搜索框清空行为）；`OnCommentFilterApply/ClosePopup` 收起弹窗；删除 `PopulateCommentCombo/PopulateCommentColorCombo/OnCommentFilterChanged`。
  3. 修 CS8620：`BuildCfCheckList` 元组 `Display` 定为非空 `string`（作者项 "（无作者）" 兜底）。
- 兼容：搜索框行为不变；筛选即时生效（勾选即刷列表），「应用」仅收起弹窗；prefs.json 无新字段。
- 验证：构建 0 错 0 警、lints 0；待 GUI 复测（漏斗弹窗三组可折叠、多选过滤正确、角标计数、全部清除/应用/外部点击关闭）。

## 2026-11-15 V1.2.176

**修正｜打开文档时缩放档位不应恢复为上次关闭时的值，应始终按首选项「默认视图比例」**

- 现象：首选项「默认视图比例」=「适应宽度」，但重开文档（NCD57100-D.PDF）时缩放显示 400%——正是上次关闭时的档位。
- 根因：打开路径在「还原上次视图」（`RestoreDocView` 开启且命中 `LastViews` 记忆点）时，除恢复阅读位置外还执行 `tab.ZoomIndex = ResolveZoomIndex(v.ZoomName, v.ZoomIndex)`，把缩放档位一并恢复，覆盖了 `DefaultZoomIndex()`（默认适应宽度）。
- 修复（`MainWindow.xaml.cs`）：
  1. 打开文档时不再从记忆点恢复缩放档位——`tab.ZoomIndex` 保持 `DefaultZoomIndex()`；记忆点仅恢复 `SavedOffset/SavedPage/SavedFraction`（页码锚与页内比例，缩放无关）；
  2. 删除失去唯一调用方的 `ResolveZoomIndex`（含 V1.2.151 旧 12 项档位下标迁移逻辑）；`SaveTabView` 仍照常写 `ZoomIndex/ZoomName` 字段，prefs.json 结构不变、向后兼容。
- 语义说明：同一标签切走再切回（ActivateTab）仍沿用该标签当前缩放（会话内不重置）；仅“关闭后重新打开文档”按默认比例。
- 验证：构建 0 错 0 警、lints 0；待 GUI 复测（上次 400% 关闭 → 重开应显示「适应宽度」；滚动位置/页码仍恢复；新建文档默认适应宽度不变）。

## 2026-11-15 V1.2.175

**优化｜水印对话框加粗按钮文字 T → B**

- 需求：加粗图标由「T」换成「B」。
- 改动：`Dialogs/WatermarkDialog.xaml` 的 `BoldBtn` 的 `Content="T"` → `Content="B"`（其余样式/事件/逻辑不变）。
- 验证：构建 0 错 0 警；待 GUI 复测（水印对话框格式栏首枚按钮显示「B」）。

## 2026-11-15 V1.2.174

**修正｜水印 / 页眉页脚对话框格式按钮图标暗色主题下看不清**

- 现象（用户截图圈出）：暗色主题下「添加水印」对话框字体下方一排格式按钮（加粗 T、文本颜色黑色色块、左/中/右对齐）是浅灰方块 + 浅色字形，几乎不可辨；「页眉页脚」对话框的下划线 U + 色块同款问题。
- 根因：这些按钮未套主题样式——默认 ToggleButton 底色与字形色在暗色主题下都接近浅灰、互相融掉；`ColorSwatch` 硬编码 `Background="Black"` 且无边框，深色背景上不可见。
- 修复：
  1. `Dialogs/WatermarkDialog.xaml`：`BoldBtn` / `AlignLeft` / `AlignCenter` / `AlignRight` 套全局 `ToolButton` 样式（App.xaml：透明底、`Th.Triangle` 前景、悬停 `Th.Hover`、选中 `Th.Selected`+`Th.SelectedText`，与工具栏图标按钮同款；文字按钮覆盖 `FontFamily="Segoe UI" FontSize="13"` 防被 MDL2 字体替换字形）；
  2. `Dialogs/HeaderFooterDialog.xaml`：`UnderlineBtn` 同款处理；
  3. 两处 `ColorSwatch` 加 `BorderBrush={DynamicResource Th.Border}` `BorderThickness=1`，黑色色块在深色背景上有清晰轮廓。
- 不变量：按钮尺寸仍 26×26、事件/逻辑零改动；对齐 Path 描边本就绑定 ToggleButton 前景，随主题自动变色。
- 验证：构建 0 错 0 警；待 GUI 复测（暗色/亮色主题下 T/U 字形与对齐图标清晰、选中态高亮、色块有边框）。

## 2026-11-15 V1.2.173

**优化｜首选项分类「性能」改为「性能设置」**

- 需求：首选项左侧分类列表里把「性能」改名为「性能设置」。
- 改动：`PreferencesDialog.xaml` 分类 `ListBoxItem` 的 `Content="性能"` → `Content="性能设置"`（仅可见标签，页面内容与功能不变）。`AppPrefs`/`PerfLimits` 等代码注释与内部命名保持「性能」语义，无需改动。
- 验证：构建 0 错 0 警；待 GUI 复测（首选项分类出现「性能设置」项）。

## 2026-11-15 V1.2.172

**修正｜缩放 HUD 滑轨轴线看不见 + 滑块改空心圆环**

- 反馈：①轴线还是看不到；②圆形滑块不要实心圆。
- **根因（①的真因不是颜色）**：滑块模板用 Grid 三行（`0.5*/Auto/0.5*`），中行 `Auto` 收缩到 Track 的期望高度 = Thumb 高度（上下 RepeatButton 模板为透明 Border、期望高度 0）→ 中行仅 ~14px：轴线 3px 只画 14px 高且被滑块完全盖住，同时滑块行程≈0（拖动几乎无效果）。
- 修正（`MainWindow.xaml` ZoomHud Slider 模板）：
  1. 去掉 `Grid.RowDefinitions`，`Track` 直接铺满整个 Grid（WPF Track 自身按当前值分配 Decrease/Increase 区域与 Thumb 位置），加 `IsDirectionReversed="True"`（垂直滑块必须，向上=值增大=放大）；
  2. 轴线 `Rectangle Width=3 #99FFFFFF` 改 `VerticalAlignment=Stretch`（Margin 0,2,0,2）贯穿全高，画在 Track 之下不再被遮挡；
  3. Thumb 改空心圆环：`Ellipse 14×14 Stroke=#E8E8E8 StrokeThickness=3`、无填充（中心透出轴线/底色）。
- 顺带收益：拖动滑块的行程从 ~14px 恢复为全轨道 ~104px，离散吸附体验正常。
- 验证：构建 0 错 0 警；待 GUI 复测（轴线从顶部贯穿到底部清晰可见；滑块为空心圆环；拖动滑块上下行程正常、吸附工具栏档位；向上滑=放大）。

## 2026-11-15 V1.2.171

**优化｜缩放 HUD 滑轨看不见 / 面板透明度 80% / 标题名称与版本号加间隔**

- 反馈：①拉杆滑轨线看不见；②HUD 面板透明度调到 80%；③标题栏名称和版本号之间再增加一个字符间隔。
- 改动：①滑轨 `Rectangle` 由 `Width=2 Fill=#59FFFFFF` 改为 **`Width=3 Fill=#99FFFFFF`**（加粗提亮）；②HUD 面板 `#E6323232` → **`#CC323232`**（alpha E6≈90% → CC=80%）；③`AppTitleBase` 改为 `"XC PDF Reader  V" + 版本`（双空格间隔）。
- 验证：构建 0 错 0 警；待 GUI 复测（Ctrl+滚轮弹出 HUD：滑轨线清晰可见、面板半透明 80%；标题栏「XC PDF Reader  V1.2.171」名称与版本号之间有空隙）。

## 2026-11-15 V1.2.170

**优化｜标题栏软件名后追加版本号**

- 需求：标题栏显示的软件名称后面增加软件版本号。
- 改动（`MainWindow.xaml.cs`）：新增 `AppVersionString`（从 `Assembly.GetExecutingAssembly().GetName().Version?.ToString(3)` 读取，自动同步版本，无需手写）与 `AppTitleBase => "XC PDF Reader V" + 版本`；构造函数 `InitializeComponent()` 后 `Title = AppTitleBase`；四处标题拼接统一改为 `$"... - {AppTitleBase}"` 或 `AppTitleBase`（无文档 / 打开文档 / 保存后 / 另存为后）。XAML 初始 `Title="XC PDF Reader"` 会被构造函数与后续逻辑覆盖，无需手改版本。
- 不变量：标题语义不变（仍是「文件名 - 软件名 V版本」），仅追加版本号。
- 验证：构建 0 错 0 警；待 GUI 复测（标题栏显示「XC PDF Reader V1.2.170」；打开文档后「文件名 - XC PDF Reader V1.2.170」）。

## 2026-11-15 V1.2.169

**优化｜导出 PDF 默认文件名改为 `原文件名_np_exp`**

- 需求：导出 n 页文档时，默认文件名改为「原文件名_np_exp」（原 `_export`）。
- 改动：`ExportPagesDialog.DefaultPdfName()` 返回 `原文件名 + "_np_exp.pdf"`（无来源路径回退「导出页面_np_exp.pdf」），仍可在另存为对话框手动改名。仅影响 PDF 默认名；图片导出按 `page_001..N` 自动编号到所选文件夹，不涉及单文件名。
- 验证：构建 0 错 0 警；待 GUI 复测（导出 PDF，另存为默认名形如 `原文件名_np_exp.pdf`）。

## 2026-11-15 V1.2.168

**优化｜缩放 HUD 改为 Adobe 同款深色胶囊视图（用户反馈"丑爆了"）**

- 用户对照 Adobe 截图提出三点：文字下要有横线、拉杆形状为圆形、整体像 Adobe 的深色胶囊。
- 改动（`MainWindow.xaml` ZoomHud 块）：
  1. 面板：`Background=#E6323232`（固定深色，不随主题）、`CornerRadius=10`、`Width=48`、`Padding=0,9,0,10`，去掉 `BorderBrush/BorderThickness`（Adobe 胶囊无边框）；百分比文字固定白色；
  2. 分隔线：百分比下方居中横线 `Rectangle Width=36 Fill=#4CFFFFFF`；
  3. 滑块模板：滑轨改 `Rectangle Width=2 Fill=#59FFFFFF` 细白线；Thumb 改 `Ellipse 14×14 Fill=#E8E8E8` 圆形；滑块高度 140→118、宽度 26→24 适配胶囊。
- 不变量：唤出/淡出/档位逻辑零改动（`ShowZoomHud`/`HideZoomHud`/`OnZoomHudSliderChanged` 不动）。
- 验证：构建 0 错 0 警；待 GUI 复测（外观与 Adobe 截图一致：深色胶囊、白字、横线、圆滑块；明暗主题下观感一致；拖动/淡出行为不变）。

## 2026-11-15 V1.2.167

**优化｜导出页面对话框去掉多余浏览步骤（点确定直接弹系统保存窗口）**

- 现象（用户反馈）：「导出页面」对话框里先要点「浏览…」选位置、再点「确定」，感觉多了一步——保存窗口里本来就可以浏览保存位置。
- 改动（`Dialogs/ExportPagesDialog.xaml(.cs)`）：
  1. XAML 移除「PathBox + 浏览…按钮」整行（底部按钮组 Margin 调整补白）；
  2. `OnOk` 重写为直接弹系统窗口：PDF → `SaveFileDialog`（Filter `PDF 文件|*.pdf`，`FileName=DefaultPdfName()` 即 `原文件名_export.pdf`，`InitialDirectory=源文件目录`）；PNG/JPG → `OpenFolderDialog`（.NET 8 新增的原生文件夹选择器，多页导出按 `page_001..N` 自动编号，选文件夹比选单文件合理），同样默认定位源目录；
  3. 删除 `OnBrowse` 与路径校验分支（不存在"没选位置"的中间态）。
- 不变量：`ExportPagesDialog.Path` 语义不变（PDF=完整文件路径，图片=目标文件夹），`MainWindow.OnExportPages` 无需改动。
- 验证：构建 0 错 0 警、lints 0；待 GUI 复测（导出 PDF：确定后直接弹另存为、默认名/目录正确；导出图片：确定后弹文件夹选择器；取消保存窗口则对话框不关闭也不导出）。

## 2026-11-15 V1.2.165

**新增｜Ctrl+滚轮缩放 HUD：文档区左下角竖向弹出缩放比例拉杆（类 Adobe）**

- 需求：像 Adobe PDF 那样，Ctrl+滚轮缩放时在文档左下侧竖向弹出拉杆比例条。
- 实现（`MainWindow.xaml` + `MainWindow.xaml.cs`）：
  1. XAML：文档区 Grid.Column=2 内新增 `ZoomHud` Border（`HorizontalAlignment=Left / VerticalAlignment=Bottom / Margin=14,0,0,18 / ZIndex=8`，默认 Collapsed、Opacity=0），内含 `ZoomHudPct`（百分比文字）+ `ZoomHudSlider`（竖向 `Slider`，Width 26 / Height 140，`TickFrequency=1`、`IsSnapToTickEnabled=True`，`ValueChanged=OnZoomHudSliderChanged`）。主题用 `Th.PanelBg80 / Th.Border / Th.Text` 动态资源，明暗两套自适应。
  2. `OnPreviewMouseWheel` Ctrl 分支在 `SelectZoom` 后调 `ShowZoomHud()`：设置 `Maximum=steps.Count-1`、`Value=当前选中档下标`（`_zoomHudSync` 抑制事件回环；适应类模式取最近数值档）、更新百分比文字，撤在途淡出动画后 `Visible`，并重启 1300ms 自动淡出定时器。
  3. `HideZoomHud()`：`LayoutAnim.Fade(ZoomHud,1,0,150)` 淡出后 Collapsed（复用 `AnimKey.SearchBar` 动效开关，无需新增 AppPrefs 键）；`myGen != _zoomHudGen` 代次让位——淡出途中又被唤出/拖动则不收。
  4. `OnZoomHudSliderChanged`：拖动吸附到 `ZoomStepList()` 档位并 `SelectZoom`（与滚轮/+- 按钮/下拉框四源统一），更新文字、代次++、撤淡出、续命定时器。
- 不变量：缩放仍是离散跳档（`SetZoom` 瞬时落定）；不新增动效设置项；`ZoomStepList` 单一数据源贯穿。
- 验证：构建 0 错 0 警、lints 0；待 GUI 复测（Ctrl+滚轮唤出 HUD 且百分比随滚轮档位变化；拖动拉杆吸附到工具栏档位并联动缩放；约 1.3s 无操作自动淡出；淡出途中继续滚轮/拖动不残留半透明、不卡死；暗色/亮色主题下均清晰）。

## 2026-11-15 V1.2.164

**修正｜Ctrl+滚轮缩放应严格按工具栏缩放下拉框列出的比例逐档跳（非连续线性缩放）**

- 现象：Ctrl+滚轮放大/缩小页面像"线性连续缩放"，而非按工具栏 ZoomBox 列出的比例跳。
- 核查：`SetZoom` 本身是瞬时落定（无动画补间），`OnPreviewMouseWheel` 早已按 `CtrlZoomSteps`（15 个离散档：8.33%~6400%）步进——它与工具栏数值项一致，本就是离散跳档。但 `CtrlZoomSteps` 是与下拉框**重复的硬编码副本**，任一处改了就会漂移；且"最近匹配"算法在缩放漂移/适应模式下可能跳到非预期档，观感上像"不按工具栏比例"。
- 修复（`MainWindow.xaml.cs`）：
  1. 删除 `CtrlZoomSteps` 字段；新增实例方法 `ZoomStepList()` 遍历 `ZoomBox.Items`，提取所有以 `%` 结尾的项，返回 `(名称, 比例)` 列表——**单一数据源，滚轮/+− 按钮与下拉框永远一致**。
  2. `OnPreviewMouseWheel`：取 `ZoomBox.SelectedItem` 的名称在 `ZoomStepList` 中的下标，直接 ±1 步进（适应类模式下退化为"最近数值档"起步）；结果用 `SelectZoom(档位名)` 选中下拉框对应项。缩放仍是离散跳档，不连续补间。
  3. `NudgeZoom`（+ / − 按钮）：同样经 `ZoomStepList()` 找最近列出的比例，与滚轮完全统一。
- 验证：构建 0 错 0 警、lints 0（先修 `ZoomStepList` 返回类型 `IReadOnlyList→List` 以用 `FindIndex`）；待 GUI 复测（Ctrl+滚轮：100%→150%→200%→300%→400%→800%→…→6400% 严格按工具栏档跳；从"适应宽度"起步向上滚应先落到最近数值档再逐级放大；+ / − 按钮档位与滚轮一致）。
- 注意：若复测仍觉"线性"，多为旧 exe 未重启（部署目录已为 1.2.164，但运行中的进程仍锁旧文件）——需关闭程序重开。

## 2026-11-15 V1.2.163

**优化｜查找文本工具栏关闭卡顿严重（PopOut 缩放带文本框控件 → 逐帧重栅格化）**

- 现象：开启动效时点 X / Esc 关闭查找栏"卡顿严重"（V1.2.161 把"关不掉"修成"能关但卡"）。
- 根因：① `CloseSearch` 走 `LayoutAnim.PopOut(SearchBar,150ms,toScale:0.94,toY:-10)`——对包含 `TextBox`/`Button`/计数 `TextBlock` 的 `SearchBar(Border)` 做 **ScaleX/ScaleY 缩放**。WPF 对带文本的控件做缩放变换时每帧需重新栅格化文本位图 → CPU 飙高、掉帧严重（纯抖动/卡顿，与动画时钟停摆无关）。② `ResetSearch()` 在关闭一开始就同步遍历 `RealizedViews` 调 `ClearSearchHighlights()`，清空所有页高亮会重渲页面，阻塞收栏。③ 若动画时钟停摆，`PopOut` 内部看门狗 `ms+250` → 最坏冻约 400ms 才强制收起。
- 修复：
  1. 关闭改**纯淡出**：`LayoutAnim.Fade(SearchBar,1,0,130ms, done)` 只动 `Opacity`（GPU 合成层，不触发控件重栅格化），无缩放无平移 → 平滑不卡；`done` 内保留 `_searchShown` 重开门卫防误隐藏，`Fade` 内部看门狗（V1.2.161，现 `ms+150`）兜底时钟停摆。
  2. `ResetSearch()` 从关闭开头移到 `done` 回调（收起置 Collapsed 之后），高亮清除不再阻塞收栏，关闭更跟手。
  3. `LayoutAnim.PopOut` 与 `Fade` 的看门狗宽限 `ms+250 → ms+150`（侧栏/对话框/翻页卷角/DocOverlay 全部受益，最坏冻结更短）。
- 不变量：动效关闭分支、`OpenSearchBar` 的 `PopIn` 弹出保持不变（用户未报打开卡顿）；`AnimKey.SearchBar` 时长键仍控制淡出速度。
- 验证：构建 0 错 0 警、lints 0；待 GUI 复测（开启动效，查找栏打开后点 X / Esc → 平滑淡出收起、无卡顿；快速反复 开/关 不残留、不抖；动画途中重新打开不误隐藏）。

## 2026-11-15 V1.2.162

**优化｜翻页闪动收尾 + 书签展开"接力"感（动效流畅度）**

- 现象：① 翻页卷角动效有闪动、不流畅自然；② 展开所有标签栏（书签）动效不流畅，每行像接力。
- ① 根因：卷角完成时 `FinishSlideTransition` 把整个 `PageSlideLayer`（不透明 DocAreaBg 背景）**硬隐藏**，露出下面真实文档区；只要那一帧快照与真实渲染有亚像素 / 解码时机差异，揭幕瞬间就"啪"地闪。
  - 修复：`anim.Completed → FinishSlideTransition(smooth:true)`；smooth 路径先 `LayoutAnim.Fade(PageSlideLayer,1,0,70)` 把整层**淡出**再收，把接缝溶解掉。用户接管（`StopPageAnimation`）仍走 `smooth:false` 立即隐藏（不被淡出拖住）。新增 `_slideFinishing`：淡出期间若又起新翻页，`StopPageAnimation` 调 `FinishSlideTransition(false)` 中断淡出并 `CollapseNow`（先 `BeginAnimation(Opacity,null)` 撤掉淡出动画、复位 Opacity=1、隐藏层），陈旧淡出回调用 `myToken != _slideToken` 让位、绝不收掉新翻页的层。`ArmSlideWatchdog` 停摆兜底仍走 `false` 硬隐藏。
- ② 根因：`LayoutAnim.StaggerRows` 每行用 `BeginTime=index*stepMs` 错峰、动画 `rowMs=240` 用 `IosSpring`（微回弹），长列表里每行明显依次冒出 → 接力观感。
  - 修复：`StaggerRows` 改紧凑连贯波浪：行数很多时把每行起跳延迟压缩、总错峰封顶 `220/(n-1)` ms；改用无超调 `IosEaseInOut`、位移/缩放幅度收敛（scale 0.985→1、Y -6→0）；`PlayOutlineAnim` 与 `OnOutlineNodeExpanded` 两处调用点 `rowMs`/`stepMs` 同步调小（190/8、170/7）。
- 验证：构建 0 错 0 警、lints 0；待 GUI 复测（翻页刺溜到目标页应无揭幕闪动；书签"展开所有"应是一段连贯波浪而非逐行接力；翻页动画播放中滚动鼠标应即时接管、不卡淡出）。

## 2026-11-15 V1.2.161

**修复｜查找工具栏 X 关不掉（动画时钟停摆的系统性兜底）**

- 现象（用户实锤）：设置里关闭动效后，点查找栏的 X 能正常关闭；开启动效后点 X 关不掉。侧栏（V1.2.157）、退出保存对话框不自动关（V1.2.158）是同一根因的不同表现。
- 根因：`MainWindow.CloseSearch` 走 `LayoutAnim.PopOut` 退场，真正的 `SearchBar.Visibility = Collapsed` 写在 `PopOut(done)` 完成回调内。窗口最小化 / 渲染被抑制 / 系统动画被关等场景下 WPF 动画时钟停摆（不推进 CurrentProgress），`a4.Completed` 永不触发 → `done` 不执行 → 工具栏永久停在屏幕上（X 关不掉）。关掉动效时走 `!LayoutAnim.On` 同步隐藏分支，故正常。
- 修复（系统性，一处修全局）：在 `LayoutAnim.PopOut` 与 `Fade` 内部为完成回调用 `DispatcherTimer(ms+250)` 看门狗兜底——超时强制触发 `done`；`fired` 标志防双触发，`IsCurrent(el,gen)` 防被新动画接管时误触发旧收尾。覆盖：查找栏关闭、对话框 iOS 退场（与 `OnDialogClosing` 已有看门狗一致、互无冲突）、`DocOverlay` 淡出后切换背景等所有"动画结束才生效"的收尾。
- `CloseSearch` 还原为干净形式（去掉临时的调用方看门狗），由 `PopOut` 内部统一保证隐藏必执行；`done` 内保留 `_searchShown` 重开门卫，避免动画途中再次打开时被误隐藏。
- 验证：构建 0 错 0 警、lints 0；待 GUI 复测（开启动效，查找栏打开后点 X / 按 Esc 应正常关闭；最小化时关闭查找栏恢复后应已收起；重复快速 开/关 查找栏不残留、不卡死）。

## 2026-11-15 V1.2.160

**修正｜Ctrl+滚轮缩放取消 400% 上限（可放大到 6400%）**

- 背景：V1.2.156 按“限制最大 400%”加了 `maxZoom=4.0` 硬上限 + 到顶停涨判断；现需求反转——要能放大超过 400%。
- 改动：`MainWindow.OnPreviewMouseWheel`（Ctrl+滚轮缩放通道）改用与 `ZoomBox` 列表一致的完整 15 档（`8.33% 12.5% 25% 50% 75% 100% 150% 200% 300% 400% 800% 1600% 2400% 3200% 6400%`），删除 `maxZoom` 常量与“`cur>=maxZoom && 向上滚` 直接 return”的两道限制；向上滚经 `Math.Min(Length-1, idx+1)` 自然封顶在 6400%，向下滚封底 8.33%。
- 顺手消除重复：抽出私有静态只读 `CtrlZoomSteps` 数组，`NudgeZoom` 的本地档位列表也改用它（与注释“档位与 ZoomBox 列表一致”保持一致），不再两处硬编码分叉。
- 不变量：渲染端仍由 `zoom = Math.Clamp(zoom, 0.05, 64.0)`（64.0=6400%）兜底；下拉框、+ / − 按钮、`NudgeZoom` 行为不变。
- 验证：构建 0 错 0 警、lints 0；待 GUI 复测（Ctrl+滚轮从 100% 向前滚：…400%→800%→1600%→…→6400% 一路放大；到 6400% 后再向上滚停住；从下拉框选 6400% 后 Ctrl+滚轮向下滚正常回落）。

## 2026-11-15 V1.2.159

**修复｜侧栏收起仍残留空带（SettleValue 用 SetCurrentValue，撤动画后被基值覆盖回弹）**

- 现象（用户截图，V1.2.158）：侧栏面板已折叠，但文档区左侧残留 ≈202px（=XAML 基值 `Width="202.4"`）空带——与 V1.2.157 截图（残留 120 且面板未折叠）不同：这次 `Settle` 已跑、动画已撤，但**列宽落定值没有生效**。
- 根因：`LayoutAnim.SettleValue` 的实现是 `d.SetCurrentValue(dp, final)` + `BeginAnimation(dp, null)`。WPF 语义：`SetCurrentValue` 只改"当前有效值"、**不改本地基值**；撤掉动画后属性系统按基值重新计算 → 有效值弹回基值。对 Opacity（基值 1.0）、Transform（ResetTransform 直接 `sc.ScaleX=1` 写本地值）这类基值恰等于落定目标的属性从未暴露；`ColumnDefinition.Width` 基值 = XAML 202.4 ≠ 0 → 收起落定的 0 被覆盖回 202.4。`AnimateColumn` 的 Completed 路径与 V1.2.157 `FinishColumn` 看门狗路径都经 `SettleValue`，全部中招。
- 修复（`LayoutAnim.cs`）：
  1. 新增私有 `SettleColumnWidth(column, to)`：`column.Width = new GridLength(to)`（写本地基值）→ `BeginAnimation(WidthProperty, null)`（撤在途动画）。撤表后有效值 = 本地基值 = 目标，无回弹。
  2. `AnimateColumn`：零时长 / 距离过小路径与 Completed 路径的落定改走 `SettleColumnWidth`；并把 `SettleValue`（撤在途动画）挪到读取 `from` 之前，动画起点与撤表后的视觉一致。
  3. `FinishColumn`（看门狗兜底）改走 `SettleColumnWidth`。
- 验证：构建 0 错 0 警、lints 0；待 GUI 复测（收起侧栏 → 列宽收到 0、把手贴窗口左缘；最小化时收起 / 快速反复收展 → 均无残留空带、无回弹；右侧吸附栏同通道一并受益）。

## 2026-11-15 V1.2.158

**修复｜文档保存完成后不自动退出（保存进度框卡在 100% ✓）**

- 现象（用户截图）：退出软件 → 弹「保存文档」批量保存框 → 进度到 100%「已完成」（绿色 ✓）后对话框不消失，主窗口退不出，必须手动关对话框。
- 链路：`Window_Closing` → `BatchSaveAll`（`ShowDialog`）→ 后台保存完成 → `dlg.FinishAll(true)`（`_busy=false`、`Close()`）→ `ShowDialog` 返回 Saved → `Window_Closing` 不再取消 → 主窗口关闭退出。卡点必在「对话框 Close 不掉」。
- 根因①（退场动画拦截 + 时钟停摆）：`BatchSaveDialog.Close()` 被 V1.2.151 `LayoutAnim.OnDialogClosing` 拦截（`e.Cancel=true` → `PopOut(el,160ms)` → 完成回调里再次 `Close`）。动画时钟停摆（窗口最小化 / 渲染被抑制，与 V1.2.157 侧栏收不干净同根因）时 `Completed` 永不触发 → 第二次 `Close` 永不执行 → 对话框满不透明卡在第 0 帧（与截图一致）。
  - 修复：`OnDialogClosing` 加看门狗 `DispatcherTimer(ms+250)`，超时直接 `Finish()`（移除自身处理器 + `window.Close()`）；`closed` 标志防双关；同步完成（动画关闭 / 零时长）不启动。**全部对话框统一受益**（MessageDialog / ExitTabsDialog / PreferencesDialog / BatchSaveDialog…）。
- 根因②（收尾异常跳过 FinishAll）：`BatchSaveAll` 最终 `Dispatcher.Invoke` 里 `PushCompressed / MarkSaved / RefreshTabTitle` 等任一抛异常，`FinishAll` 与 `_saving=false` 都不执行 → 对话框永不关闭、保存按钮永久禁用。
  - 修复：收尾改 try/catch/finally——主体（落账、状态消息、计时器）在 try，异常记 `App.Log`；`_saving=false`、`RefreshSaveButton/UpdateStatus`、`dlg.FinishAll(...)` 移入 finally 必达。
- 验证：构建 0 错 0 警、lints 0；待 GUI 复测（退出有未保存文档 → 保存到 100% 后对话框自动关闭、软件自动退出；保存期间最小化主窗口 → 恢复后能正常退出；失败 / 中断路径仍保留窗口展示详情）。

## 2026-11-14 V1.2.157

**修复｜侧栏收起后残留一条空带（动画时钟停摆 → Completed 永不触发）**

- 现象（用户截图）：收起侧栏后，左侧残留约一个侧栏宽的空带：`SidePanel` 以固定宽度（120）留在列内、其余区域露出底色，展开把手 `SidebarStrip` 悬在半空而非窗口左缘；点把手展开后一切正常。
- 证据链：把手锚在文档区左缘（列 2，Margin 5），其位置 ≈ 列 0 实际宽度 → 列宽没收到 0；`SidePanel.Visibility` 仍 Visible 且宽度是 `SetSidebarVisible` 里设置的 `Math.Max(_sidebarWidth,120)` → `Settle` 回调没跑 → 列宽动画的 `Completed` 没触发，`FillBehavior.HoldEnd` 把列宽钉死在起始值。
- 根因：WPF 动画时钟在窗口最小化 / 视觉树尚未渲染等场景会停摆（不推进 CurrentProgress），`Completed` 永不触发；文档加载时 `ApplyOpenSidebarState → SetSidebarVisible(false)` 若恰逢此状态即复现。
- 修复：
  1. `MainWindow.AnimateLayoutColumn`（侧栏 / 吸附栏列宽动画公共入口）加**看门狗**：`DispatcherTimer(ms+250)`，若超时仍未完成（token 未变、未 finished），调新增的 `LayoutAnim.FinishColumn(column, to)` 强制把列宽落定为目标值并撤掉在途动画（`SettleValue` 落定呈现值再撤表，无跳变），再执行收尾回调（`Settle`：折叠 SidePanel、清 MinWidth、重算适应缩放）。`finished` 标志防双收尾；token 比对防与后续动画互踩；同步完成（动画关闭/零时长）不启动看门狗。
  2. 连带修复数据污染：`SetSidebarVisible` 记忆宽度处加 `SidebarColumn.Width.Value >= 120` 前置条件——已收起（Width=0）时重复收起，原 `Math.Clamp(0,120,420)` 会把 `_sidebarWidth` 错误记成 120，下次展开丢失用户拖宽。
- 验证：构建 0 错 0 警、lints 0；待 GUI 复测（收起侧栏 → 无残留空带、把手贴窗口左缘；最小化窗口时打开无书签文档 → 恢复后侧栏应已收干净；反复快速收起/展开宽度记忆正确）。

## 2026-11-14 V1.2.156

**优化｜Ctrl+滚轮缩放硬性限制最大 400%**

- 需求：按住 Ctrl + 鼠标滚轮缩放时，限制最大 400%。
- 改动：`MainWindow.xaml.cs` 的 `OnPreviewMouseWheel`（Ctrl+滚轮缩放通道）。原逻辑用固定档位数组 `["25%"…"400%"]` 步进，`next` 已 clamp 到 `pctItems.Length-1`（即 400%），本就停在 400%；本轮把 400% 上限做**显式硬上限**并补两道保险：
  1. 定义 `const double maxZoom = 4.0`；若 `cur >= maxZoom - 1e-6 && e.Delta > 0` 直接 `return`（向上滚且已到/超上限时不再放大，避免从下拉框进入 6400% 后再向上滚被“吸”回 400% 的跳动）；
  2. 计算出的目标缩放 `z` 再 `z = Math.Min(z, maxZoom)` 钳一次，双保险确保 Ctrl+滚轮绝不超过 400%。
- 不变量：档位列表（含 800%~6400%）与 +/− 按钮、缩放下拉框的其它通道不受影响，仅约束 Ctrl+滚轮这条手势通道。
- 验证：构建 0 错 0 警、lints 0；待 GUI 复测（Ctrl+滚轮放大到 400% 后继续向上滚应停住；从下拉框选 6400% 后 Ctrl+滚轮向上滚不变、向下滚回落到 300%）。

## 2026-11-14 V1.2.155

**新增｜右键菜单第一行加入手型工具项**

- 需求：在页面右键菜单第一行增加「手型工具」菜单项（已有工具栏手型按钮，现补右键入口）。
- 改动：`Controls/PdfPageView.cs` 的 `OnContextMenuOpening`（动态拼装右键菜单处），在 `new ContextMenu()` 之后、原有文档级操作之前，插入一个可勾选项：`MenuIcons.Item("手型工具", <手型几何>)`，`IsCheckable=true`、`IsChecked=(Tool==ToolMode.Hand)`，`Click` 转发 `RequestActivateTool?.Invoke("Hand")`；其后加一条 `Separator` 与下方「适合宽度…」分组分隔。
- 复用链：`RequestActivateTool` 在主窗口挂 `OnReqActivateTool → ActivateToolFromTag(tag)`：优先按 Tag 找 `ToggleButton`（命中 `ToolHand`）调 `OnToolClick`，否则 `SelectTool(tag)`。因此该菜单项与工具栏手型按钮完全同源：点击即切换为手型工具并联动高亮/状态栏；当前已是手型时显示 √。
- 验证：构建 0 错 0 警、lints 0；待 GUI 复测（页面右键 → 第一行见「手型工具」、可勾选；点击后工具栏手型按钮高亮、光标变手；再右键该项正确显示 √）。

## 2026-11-14 V1.2.154

**修复｜手型工具拖拽平移抖动**

- 现象：V1.2.153 新增手型工具后，按住拖动文档画面抖动。
- 根因：`PdfPageView` 的 `OnMouseMove`（手型 case）与 `OnMouseLeftDown` 用 `e.GetPosition(this)` 计算平移增量。但 `this`（PdfPageView）正是被 ScrollViewer 滚动的内容；每次 `ScrollToVerticalOffset/HorizontalOffset` 后内容位移，`GetPosition(this)` 的参考系（本控件自身坐标系）随滚动整体平移，于是下一帧 `now - _handLast` 里混入了上一帧已滚动的量，形成正反馈 → 越拖越抖。
- 修复：起点与每帧位移统一改用**静止的 ScrollViewer** 坐标（`FindAncestorScrollViewer()` → `e.GetPosition(sv)`）。ScrollViewer 的边界不随内容滚动变化，delta 只对应真实鼠标物理位移，反馈回路被切断，拖拽平滑稳定。
- 改动：`Controls/PdfPageView.cs` 手型分支（按下记录 `_handLast`、移动计算 dx/dy）由 `GetPosition(this)` 改为 `GetPosition(sv)`；字段 `_handLast` 注释同步说明成因。
- 验证：构建 0 错 0 警、lints 0。

## 2026-11-14 V1.2.153

**新增｜手型工具（抓手平移 + 手型光标）**

- 需求：增加右键手型工具在第一行，实现鼠标拖动文档、光标呈手型。
- 改动：
  - `Controls/ToolMode.cs`：枚举新增 `Hand`（Select 之后）。
  - `MainWindow.xaml`：工具区首个 `ToggleButton ToolHand`（Tag="Hand"），置于 `ToolNote` 之前（当前工具组首按钮）；`OnToolClick` 通用分支（非选择类/非印章）自动接手 `CurrentTool=Hand`、`pv.Tool=Hand` 并互斥高亮，无需特判。
  - `Controls/PdfPageView.cs`：
    - 新增字段 `_handLast`（拖拽上一帧鼠标位置，本控件坐标）。
    - `Tool` setter：切到 Hand 立即 `Cursor=Cursors.Hand`（避免等鼠标移动才变手型）；切离仍走 `HideInkCursor`。
    - `OnMouseLeftDown` switch 新增 `case Hand`：置 `_dragging=true`、`_handLast=e.GetPosition(this)`、`CaptureMouse()`、光标 Hand、`e.Handled=true`（不触发文字选区/标注命中）。
    - `OnMouseMove`：`!_dragging` 分支首行若 `Tool==Hand` 直接 `Cursor=Hand` 并返回；`_dragging` 的 switch 新增 `case Hand`：取 `FindAncestorScrollViewer()`，按 `now - _handLast` 增量反向 `ScrollToHorizontalOffset/ScrollToVerticalOffset` 后更新 `_handLast`，光标保持 Hand。
    - `OnMouseLeftUp` switch 新增 `case Hand`：`Cursor=Hand`（顶部已有 `_dragging=false; ReleaseMouseCapture()`）。
  - `MainWindow.xaml.cs`：`ToolName` switch 增加 `ToolMode.Hand => "手型"`（状态栏「当前工具：手型」）。
- 验证：构建 0 错 0 警、lints 0；待 GUI 复测（点手型按钮→文档区光标变手→按住拖动页面跟随平移→松手光标仍是手；切到其它工具手型消失；手型下不误选文字）。

## 2026-11-14 V1.2.152

**优化 + 连带修复｜缩放倍数补齐至 8.33%~6400%；记忆点档位下标错位**

- 需求：用户截图（其它阅读器的缩放列表）要求「缩放可选倍数增加列表中所有」，即 6400/3200/2400/1600/800/400/200/150/100/75/50/25/12.5/8.33% 全档位。
- 改动：
  - `MainWindow.xaml`：ZoomBox 新增 `8.33%`、`12.5%`、`800%`、`1600%`、`2400%`、`3200%`、`6400%` 七档（保持升序），现 19 项。
  - 钳制放宽 0.1~8.0 → 0.05~64.0：`MainWindow.xaml.cs SetZoom`、`Controls/PdfPageView.cs` Zoom setter、`Controls/DocumentViewer.cs SetZoom`（对比/分屏）。
  - `NudgeZoom`（±25% 步进找最近档）的档位数组同步 15 项。
  - 渲染安全无需改：`PdfDocument` 渲染端已有 `maxDim 6000` + `PerfLimits.MaxPagePixels`（预算 1/4，4M~24M 像素）等比降采样，超高档位像素超限自动降密度，显示尺寸不变。
- **连带修复（本会话引入的隐患，随本版一并处理）**：文档记忆点 `AppPrefs.FileView.ZoomIndex` 按下标持久化，本次在列表前端插入 2 项、中段插入 5 项，旧记忆点恢复会整体错位（例：旧「适应宽度」=10，新列表 10=800%；旧 100%=3，新 3=50%）。修复：
  - `FileView` 新增 `ZoomName` 字段（档位名称，如 "100%" / "适应宽度"），`SaveTabView` 两条路径同时写名称；
  - 恢复时走新增的 `ResolveZoomIndex(name, legacyIndex)`：有名称按名称解析（列表再变动也不会错位），无名称的旧数据按旧 12 项列表映射迁移（0-7→+2，8-11→+6），并 Clamp 兜底；
  - `DocTab.ZoomIndex` 默认值与 `DefaultZoomIndex()` 兜底从 10 同步改 17（新列表「适应宽度」下标）。
- 验证：构建 0 错 0 警、lints 通过；待 GUI 复测（下拉列表 19 项齐全；选 6400% 不崩、仅略糊；Ctrl+/- 步进覆盖新档位；重开软件后旧文档缩放档位恢复正确不再跳成 800%/50%）。

## 2026-11-14 V1.2.151

**优化｜动效：对话框 iOS 式退场（缩放回弹消失）**

- 需求延续：所有动效尽量 100% 复刻 iPhone iOS，不跳动不闪动。V1.2.150 已完成「入场 + 主题 + 列宽 + Popup + 页面旋转」的 iOS 化，但对话框关闭仍是硬关闭，与 iOS「模态视图缩放回弹消失」差距最大，本轮补齐。
- 改动：`LayoutAnim.cs` 的 `OnAnyWindowLoaded` 对非主窗口再挂 `window.Closing += OnDialogClosing`；新增 `OnDialogClosing`：先判断 `e.Cancel`（尊重其它逻辑的取消，如 `BatchSaveDialog` 忙时拦截）、未加载完成、`On("Dialogs")` 开关、`Dismissing` 重入标记、`window.Content` 为空，任一不满足即放行；满足则 `e.Cancel=true`、登记 `Dismissing`、播 `PopOut`（160ms），完成时移除 `Closing` 处理器再 `window.Close()`。用 `ConditionalWeakTable<Window,StrongBox<bool>> Dismissing` 防递归，`Popup` 的弱表照旧。
- 影响面：不影响 `ShowDialog` 返回值（DialogResult 在关闭前设定）；不影响主窗口退出；不影响忙时拦截逻辑；动画关闭时长受 `AnimSpeed` / 逐项倍率约束，极速档仍保留一段可感知平滑过渡。
- 验证：构建 0 错 0 警、lints 通过；待 GUI 复测（打开任意对话框 → 确认 → 应见缩放回弹消失而非瞬关；忙时进度对话框无法关闭；连续快速开关不卡死不残留半透明）。

## 2026-11-14 V1.2.150

**优化｜动效内核 iOS 化：统一曲线、消除跳变/闪动/回弹**

- 需求：所有动效仿 iPhone iOS 操作动效，尽量 100% 复刻，要求不跳动、不闪动、丝滑流畅。
- 现状梳理：项目已有 `LayoutAnim.cs`（660 行）自称 iOS 动效，含 4 个自定义缓动、10 余个动画方法、18 个逐项开关；XAML 中没有任何 Storyboard/VisualState（全部动效在 C#）。但存在多处根因级缺陷：
  - `IosSpringEase = 1 - e^(-11t)cos(10t)` 有约 3% 超调，PopIn/Pulse/StaggerRows/Settle 都会回弹。
  - 所有方法用 `BeginAnimation(dp, null)` 直接撤动画，值会跳回旧本地值；`FillBehavior.HoldEnd` + 代次失配时 Completed 不执行，残留值压住后续本地赋值。
  - `Fade` 的 `from` 由调用方写死 1，交叉淡化中途被新过渡打断会亮度回跳；`SlideY` 先 `tt.Y = toY` 落终值，取消即跳。
  - `ResetTransform` 无条件把 `Opacity = 1`，`PopOut` 完成瞬间已淡出的元素「复活」闪一下。
  - `EnsureTransform` 强制 `(0.5,0.5)`，`StaggerRows`/`Settle` 又改 `(0.5,0)`，重复入场换中心点。
  - `AnimateColumn` 把 Star/Auto 列宽当 0 起，`GridLengthAnimation` 忽略 `defaultOriginValue`，侧栏展开从 0 突跳且每帧重排。
  - `ThemePulse` 对整个 `Window.Content` 做 0.99→1.0 缩放，文字亚像素模糊、边缘闪动；DWM 标题栏瞬时变色与 220ms 缩放不同步；`PreferencesDialog` 的 4 处 `ThemeManager.Apply` 完全不带脉冲。
  - `App.xaml:416` 的 `PopupAnimation="Fade"` 与 `ApplyPopup` 的 `None` + `PopIn` 互相覆盖，形成双重动画。
  - `OnAnyWindowLoaded` 每次窗口 Loaded 都递归遍历 `Application.Current.Windows` 整棵视觉树。
  - `PdfPageView.PlayRotationInAnimation` 的 `Opacity` 动画未撤表，后续本地 `Opacity`（如 0.25 标注层）被动画值压住。
- 改动：
  - `LayoutAnim.cs` 完整重写（保留全部 public API 与调用点兼容）：新增 `IosEaseInOutEase`（cubic-bezier 精确解，二分求 t）、`IosSpringEase`（临界阻尼 `1-(1+at)e^(-at)` 归一化，单调无超调）、`IosDuration` 档位；核心 `SettleValue(d, dp, final?)` 先 `SetCurrentValue` 落定当前呈现值再撤动画，覆盖 `UIElement` / `Animatable` / `FrameworkContentElement` 三类宿主。
  - `Fade` / `SlideY` 一律从当前呈现值接手；`PopIn` / `PopOut` / `Pulse` / `SlideIn` / `StaggerRows` / `Settle` 全部经 `StopTransform`（= SettleValue）接手，完成时落定终值并撤表；`ResetTransform` 增加 `opacity` 参数，PopOut 传 0、其余传 1。
  - `EnsureTransform` 只在 `RenderTransformOrigin == default` 时设一次 `(0.5,0.5)`；`StaggerRows` / `Settle` 不再改中心点；`StaggerRows` 保留 `BeginTime` 阶梯但不再预设本地起始值。
  - `AnimateColumn` 起点改 `column.ActualWidth`，缓动改 `IosEaseInOut`；`GridLengthAnimation` 保持（起点已由呈现宽度提供）。
  - `ThemePulse` 改为 iOS 式即时同步：只遍历窗口补一次 `ThemeManager.ApplyTitleBar`，不再缩放内容；颜色由 `ThemeManager.Apply` 一次性替换，无中间态。
  - `OnAnyWindowLoaded` 每窗口只接管一次，只遍历该窗口视觉树；`RefreshPopups` 保留为显式调用；`ApplyPopup` 统一 `PopupAnimation.None`。
  - `App.xaml` ComboBox 下拉改 `PopupAnimation="None"`；`Controls/PdfPageView.cs` 旋转完成时落定 `Opacity=1`、撤 Opacity/Angle 动画后再清 RenderTransform。
  - 版本同步至 1.2.150。
- 未改动（有意为之）：XAML 里 Hover/Selected 的瞬时 Setter（iOS 按钮高亮本身是 touch-down 即时响应，不该加渐变）；翻页卷角逐帧几何（`MainWindow.xaml.cs:2747` 每帧重建 Geometry，属性能优化而非跳变/闪动来源，改动风险高）；对话框退场动画（需拦截 `Closing` 延迟关闭，会影响 `ShowDialog` 返回值）；`MarchingAnts` 常驻时钟。
- 验证：构建 0 错 0 警、lints 通过；待 GUI 复测（侧栏/搜索栏连续快速开合、标签连点、主题快速切换、大纲批量展开、翻页中途打断、下拉框反复开合，确认无跳变/闪动/回弹）。

## 2026-11-14 V1.2.149

**移除｜在线更新 / 检查更新功能整体下线**

- 需求：用户决定放弃在线更新链路，要求剔除「检查更新」功能。
- 改动：
  - `MainWindow.xaml`：帮助菜单移除「检查更新(_U)…」及图标，保留「诊断信息」/ 分隔线 /「关于」。
  - `MainWindow.xaml.cs`：移除 `OnUpdate`；`using PdfReader.Dialogs;` 保留（`Dialogs.ExitTabsDialog` 等仍在用）。
  - 删除 `Update/UpdateManager.cs`（`UpdateInfo` / `UpdateSettings` / `CheckAsync` / `IsNewer` / `DownloadAsync` / `LaunchUpdater` 与内嵌 `apply-update.ps1` 更新器脚本）和 `Dialogs/UpdateDialog.cs`（检查更新窗口）。csproj 使用 SDK 默认 glob，删文件无需改动。
  - 版本同步至 1.2.149（csproj 四字段、AssemblyInfo 三特性）。
- 影响面核查：全局搜索 `检查更新|OnUpdate|UpdateDialog|UpdateManager|PdfReader.Update` 在 `*.cs` / `*.xaml` 中，除 OCR 组件自身的「检查更新」文案外为 0；`PreferencesDialog.xaml.cs`、`Ocr/OcrPluginManager.cs` 里的同名按钮是 OCR 模型下载/校验，保留不动。`obj\Release\...\MainWindow.g.cs` 旧生成文件里的 `OnUpdate` 绑定随重新构建自动刷新。
- 保留：`Docs` 历史条目、`Tools\*.ps1` 与 `Updates\` 产物（发布工具，已停用、不参与编译）；`%LOCALAPPDATA%\XC PDF Reader\updates`、`update-source.json` 属用户数据，未加清理逻辑。
- 验证：构建 0 错 0 警、lints 通过、源码全局搜索 0 残留；待 GUI 复测（帮助菜单只剩「诊断信息 / 关于」）。

## 2026-11-14 V1.2.148

**修复｜检查更新：清单 JSON 字段大小写不匹配，误报「缺少 version 或 url 字段」**

- 现象：用户上传 `update.json` 后点「检查更新」，状态栏显示「检查失败：更新清单缺少 version 或 url 字段」。此时界面已隐藏地址、版本为 1.2.147。
- 诊断（联网实测）：`GET https://api.github.com/repos/frankqu1977/xc-pdf-reader-updates/contents/?ref=main` 显示根目录已有 `update.json`（301 字节）；用 contents API 取回 base64 内容解码后，与本地 `Updates\update.json` 逐字比对为 `True`，内容含完整 `version` / `url` / `sha256` / `size` / `notes`。Releases 数量仍为 0（尚未建 Release）。因此线上清单无误，问题在客户端。
- 根因：`Tools\BuildUpdatePackage.ps1` 用 `[ordered]@{ version; url; sha256; size; notes }` + `ConvertTo-Json` 生成**全小写键**；`UpdateManager.CheckAsync` 用 `JsonSerializer.Deserialize<UpdateInfo>(json)` 且未设置 `PropertyNameCaseInsensitive`，System.Text.Json 默认区分大小写，`version` 不会映射到 `Version`，结果所有属性保持默认空值，触发第 136 行的字段校验异常。此前从未用真实清单端到端检查过，所以一直没暴露（Gitee / GitHub 仓库未上传清单时都只走 404 分支）。
- 改动：`Update/UpdateManager.cs` 的 `CheckAsync` 传入 `new JsonSerializerOptions { PropertyNameCaseInsensitive = true }`，并补充注释说明清单键的大小写约定；版本同步至 1.2.148（csproj 四字段、AssemblyInfo 三特性）。`UpdateInfo` 与打包脚本的清单格式均不变，同时兼容第三方 PascalCase 清单。
- 旁注：本机命令行偶发 `raw.githubusercontent.com` 请求超时（TLS 首次握手慢），客户端 `CheckAsync` 有 20 秒超时；用户那次请求确实拿到了 JSON，故本次不调整超时，偶发失败重试一次即可。
- 验证：构建 0 错 0 警、lints 通过；另建临时 .NET 8 工程直接编译真实 `Update/UpdateManager.cs`，用本地 HttpListener 提供线上同款 `update.json` 调用 `CheckAsync`，实测 `version` / `url` / `sha256` / `size=12487530` / `notes` 全部正确解析（验证后已删除临时工程）；待 GUI 复测（重开软件 → 检查更新 → 应显示「当前已是最新版本」，不再报缺少字段）。完整下载安装链路仍需仓库存在对应版本的 Release 附件，且清单版本高于客户端版本。

## 2026-11-14 V1.2.147

**优化 + 修复｜检查更新：默认隐藏清单 URL；旧配置迁移未生效**

- 需求：用户截图反馈「检查更新」窗口里直接显示更新清单 URL，希望隐藏该地址。
- 截图暴露的连带 Bug：窗口显示当前版本 1.2.146、详情区是新的 `frankqu1977` 默认源，但清单 URL 输入框仍是上一版的 `frankqu` 地址。原因是 `UpdateSettings.ManifestEpoch` 写成 `= UpdateManager.CurrentManifestEpoch`（3）；System.Text.Json 反序列化 V1.2.145 的旧配置（无该字段）时保留属性初始化器的值 3，`LoadSettings()` 的 `s.ManifestEpoch < 3` 判定为 false，历史默认地址迁移被跳过。修复：去掉初始化器，让旧配置以 0 触发迁移并回写。
- 改动：
  - `Dialogs/UpdateDialog.cs`：新增「自定义更新源」按钮与 `_urlRow` 字段；清单 URL 行默认 `Collapsed`，`_check`（检查更新）移到可见按钮栏；详情区不再输出 `DefaultManifestUrl`，改为「更新源已内置（GitHub 公开仓库，main 分支）」；ToolTip、状态栏、404 引导全部去掉仓库名与直链。新增 `ApplyCustomVisibility()` / `ToggleCustom()`，展开时自动聚焦并全选地址，收起时回到内置源。
  - `OnCheck`：默认状态下直接使用 `UpdateManager.DefaultManifestUrl`，只有展开自定义行时才读输入框；保存 `UseCustomManifest` 标记，下次打开窗口按该标记决定是否自动展开。这样即便本机残留旧地址，检查更新也不会再请求失效清单。
  - `Update/UpdateManager.cs`：`UpdateSettings` 去掉 `ManifestEpoch` 初始化器并新增 `UseCustomManifest`；`LoadSettings()` 迁移逻辑不变。
  - 版本同步至 1.2.147（csproj 四字段、AssemblyInfo 三特性）。
- 说明：隐藏的是界面展示，地址仍编译在程序里且可由「自定义更新源」查看/更换；这是界面整洁性处理，不是安全隔离。
- 验证：构建 0 错 0 警、lints 通过；待 GUI 复测（重开软件 → 帮助 → 检查更新，地址不再显示 → 点检查更新走内置源 → 展开自定义可填地址并持久保存）。

## 2026-11-14 V1.2.146

**变更｜在线更新：切到实际仓库 frankqu1977 + 一键发布脚本**

- 背景：用户给出实际仓库 `https://github.com/frankqu1977/xc-pdf-reader-updates`，希望自动完成发布。
- 联网实测：`GET https://api.github.com/repos/frankqu1977/xc-pdf-reader-updates` 返回 200、`private=false`、`default_branch=main`；`raw.githubusercontent.com/.../main/update.json` 与 `.../master/...` 均为 404（清单尚未上传）。本机 `gh` CLI 未安装、Windows 凭据管理器无 GitHub 条目，没有可复用的登录态。
- 认证结论：**GitHub 自 2021-08 起禁止用账户密码做 Git / API 认证**，必须使用 PAT 或 SSH。用户随消息提供的账户密码不用于任何命令、脚本、配置文件或日志，也不写入本仓库；建议尽快改密并启用两步验证。自动发布改由脚本从环境变量 `GITHUB_TOKEN` / `GH_TOKEN` 读取细粒度 PAT。
- 改动：
  - `Update/UpdateManager.cs`：默认清单改 `frankqu1977`；把 V1.2.145 的 `MigratedToGitHub` 布尔标记重构为 `UpdateSettings.ManifestEpoch` + `CurrentManifestEpoch = 3`，`LoadSettings()` 按代次一次性迁移 Gitee `frankqu` 与 GitHub `frankqu` 两个历史默认地址并回写配置，用户手填地址保持不变。
  - `Dialogs/UpdateDialog.cs`：ToolTip / 示例版本 / 状态栏 / 404 引导改新仓库（仓库已存在，改为提示上传 `update.json` 到 `main` 根目录）。
  - `Tools/BuildUpdatePackage.ps1`：默认 Release 直链与用法改 `frankqu1977`，步骤里指向一键发布脚本。
  - 新增 `Tools/PublishUpdate.ps1`：纯 ASCII，用 GitHub REST API 完成清单上传（自动带 `sha` 覆盖）、创建或复用 `v<版本>` Release、上传 zip 附件并核对直链；令牌只从环境变量读取。
  - 版本同步至 1.2.146（csproj 四字段、AssemblyInfo 三特性）。
- 验证：构建 0 错 0 警、lints 通过；两个 .ps1 的 `Parser.ParseFile` 0 语法错误；`Updates\` 内 update.json 的 `url` / `sha256` / `size` 与 zip 实测一致；清单与 Release 的实际上传待设置 PAT 后由脚本完成（或网页手动上传）。

## 2026-11-14 V1.2.145

**变更｜在线更新：默认更新源从 Gitee 迁到 GitHub（10 MB 单文件限制）**

- 背景：用户确认 Gitee 单文件限制为 10 MB，V1.2.144 精简后的全量包仍有 11.9 MB，无法作为仓库文件 / raw 直链上传。早期建议的「zip 放 GitHub Releases，只改清单 url」在本版升级为整体迁到 GitHub，避免同时维护两个平台。
- 调研（联网实测）：`https://api.github.com/users/frankqu` 返回该账号存在（id 6788969，public_repos 2）；`.../users/frankqu/repos?per_page=100` 返回 `morningstarweb` 与 `mweb`，均为 2014 年的老仓库、默认分支 `master`，无 `xc-pdf-reader-updates`。GitHub 新建仓库当前默认分支为 `main`，故内置地址用 `main`；若建仓时选了 `master`，在窗口里把 URL 里的分支名改一次即可。
- 方案：清单文件（几百字节）放仓库根目录，用 `raw.githubusercontent.com` 匿名直链；全量 zip 放同仓库 Releases 附件（单文件上限 2 GB，公开仓库无需登录，302 到 objects.githubusercontent.com 由默认 `HttpClient` 自动跟随）。这样不把每版二进制包提交进 git 历史。
- 改动：
  - `Update/UpdateManager.cs`：默认清单改为 `https://raw.githubusercontent.com/frankqu/xc-pdf-reader-updates/main/update.json`；新增 `LegacyGiteeManifestUrl` 与 `UpdateSettings.MigratedToGitHub`，`LoadSettings()` 对 V1.2.144 保存的旧 Gitee 默认地址做**一次性**迁移并回写配置，之后用户手填的地址不再被覆盖；空地址仍回退默认源。
  - `Dialogs/UpdateDialog.cs`：ToolTip / 详情 / 状态栏 / 404 引导全部改为 GitHub 仓库与 `main` 分支说明，示例版本改 1.2.145，并说明全量包走 Releases。
  - `Tools/BuildUpdatePackage.ps1`：省略 `-PackageUrl` 时默认生成 `https://github.com/frankqu/xc-pdf-reader-updates/releases/download/v<ver>/<zip 名>`；顶部用法 / 步骤改为建仓 + 传清单 + 建 Release，保持纯 ASCII。
  - 版本同步至 1.2.145（csproj 四字段、AssemblyInfo 三特性）。
- 保留：`-IncludeAllPlatforms` 原样打包开关与 V1.2.144 的平台精简逻辑不变；客户端地址始终可手改，因此清单仍可用 jsDelivr / 对象存储 / Gitee 小文件托管（Gitee 只放清单不受 10 MB 限制）。
- 验证：构建 0 错 0 警、lints 通过；脚本 `Parser.ParseFile` 0 语法错误；重新生成的 `update.json` 中 `url` 指向 GitHub Releases，`sha256` / `size` 与 zip 实测一致；待 GUI 复测与实际建仓上传后验证下载安装链路。

## 2026-11-14 V1.2.144

**优化｜在线更新：内置 Gitee 默认更新源**

- 背景：上一轮说明里提出「给出仓库地址即可内置默认清单 URL」，用户提供了 Gitee 个人主页 `https://gitee.com/frankqu`。
- 调研（联网实测）：
  - `GET https://gitee.com/frankqu` 与 `https://gitee.com/api/v5/users/frankqu/repos?per_page=100` 显示该账号有 3 个公开仓库 `FastGithub` / `OSDA` / `hpSocketCommon`，全是 fork、默认分支 `master`，**没有 XC PDF Reader 或更新清单仓库**，需新建一个。
  - `https://gitee.com/<owner>/<repo>/raw/master/<file>` 会 302 到 `https://raw.giteeusercontent.com/...?signature=...`；用与软件相同的默认 `System.Net.Http.HttpClient`（无自定义 UA、自动跟随重定向）实测读取 `FastGithub/README.md` 成功返回原始 Markdown 199 字符，证明该格式可作清单直链且无需登录 / UA 加固。
  - `raw/branch/master/<file>` 格式返回 404，不可用；Gitee Release 附件下载常有登录要求，故建议 zip 也走仓库 raw 或外部对象存储。
  - 内置默认地址当前返回 404（不是登录页 200），因此可为「仓库未建立」单独给友好提示。
- 改动：
  - `Update/UpdateManager.cs`：新增 `DefaultManifestUrl` 常量（`https://gitee.com/frankqu/xc-pdf-reader-updates/raw/master/update.json`）；`UpdateSettings.ManifestUrl` 默认取该常量；`LoadSettings()` 在配置文件存在但地址为空时回退到默认源。
  - `Dialogs/UpdateDialog.cs`：窗口展示默认源与部署提示、示例版本改为 1.2.144；`OnCheck` 增加 `HttpRequestException` + `StatusCode.NotFound` 的过滤 catch，提示「请先在 Gitee 建立公开仓库 frankqu/xc-pdf-reader-updates 并上传 update.json，或改地址」。
  - `Tools/BuildUpdatePackage.ps1`：省略 `-PackageUrl` 时默认生成 `https://gitee.com/frankqu/xc-pdf-reader-updates/raw/master/<zip 名>`；顶部用法 / 步骤改为 Gitee raw 形式（仍保持纯 ASCII）。
- 约定：仓库名 `xc-pdf-reader-updates`、分支 `master`、根目录放 `update.json` 与 `XC_PDF_Reader_<版本>.zip`。用户按此建仓即可；若改名或换托管，在检查更新窗口里改一次地址即可（存 `update-source.json`）。
- 验证：构建 0 错 0 警，lints 通过；默认地址实测 404、脚本 `Parser.ParseFile` 0 语法错误；待 GUI 复测（帮助 → 检查更新，URL 已预填 → 未建仓时显示 404 引导 → 建仓上传后能读到新版本）。
- 补记（首次执行打包脚本）：原样打包得到 191.57 MB，超出 Gitee 单文件限制。排查发现 `runtimes/` 里含 iOS 188 MB、macOS / Android / Linux 等共约 305 MB 的非 Windows 平台 ONNX 原生库，另有 `win-x64/` 180 MB 旧自包含发布残留；当前 `XC PDF Reader.runtimeconfig.json` 为 framework-dependent（依赖系统 .NET 8 桌面运行时），host 只按 deps.json 解析 `runtimes/win-x64`，这些文件均不会加载。脚本改为默认精简，仅保留根目录程序集 + `runtimes/win-x64` + 文档，并新增 `-IncludeAllPlatforms` 保留原样打包；重新生成 11.9 MB，实测 `ZipFile.ExtractToDirectory` 解压后主 exe、`runtimes/win-x64/native/onnxruntime.dll`、文档齐全，清单 `sha256` / `size` 与包一致。

## 2026-11-14 V1.2.143

**移除｜意见反馈 / 留言板**

- 需求：删除「意见反馈 / 留言板」菜单和实现代码。
- 改动：
  - 删除 `Dialogs/FeedbackDialog.cs`（留言板窗口）与 `Dialogs/FeedbackMailer.cs`（SMTP 投递 / mailto 回退 / 配置持久化）；csproj 使用 SDK 默认 glob，无需改动，相关 `System.Net.Mail` 代码与 `SYSLIB0014` pragma 一并消失。
  - `MainWindow.xaml` 帮助菜单移除「意见反馈 / 留言板(_B)…」及信封图标；`MainWindow.xaml.cs` 移除 `OnFeedback`。`using PdfReader.Dialogs;` 保留（`UpdateDialog` 仍在该命名空间）。
- 保留：更新日志 / Bug 修复记录里 V1.2.141 的历史条目不回溯修改；本机曾保存的 `%LOCALAPPDATA%\XC PDF Reader\feedback-smtp.json` 属于用户数据，未加清理逻辑，可自行删除。
- 验证：源码全局搜索仅剩 `obj\Release\...\MainWindow.g.cs` 旧生成文件（重新构建后自动更新）；构建 0 错 0 警，lints 通过；待 GUI 复测（帮助菜单只剩「诊断信息 / 检查更新 / 关于」）。

## 2026-11-14 V1.2.142

**新增｜在线更新（无自建服务器：清单直链 + 全量包 + 自动覆盖重启）**

- 需求：没有个人空间 / 服务器，希望客户端检测网盘或其它地方保存的软件副本，软件内下载全量安装包、完成后自动安装并关闭当前实例。
- 结论先行：**普通网盘（百度 / 夸克 / 阿里云盘等）分享链接需要登录态与跳转、没有稳定公开直链 API，客户端无法可靠下载**；蓝奏云直链有反爬且无版本查询能力。可行且免费的替代是 GitHub / Gitee Releases、免费对象存储或任意能提供文件直链的 CDN——只需一个 `update.json` 直链和一个 zip 直链，不需要服务器。
- 改动：
  - 新增 `Update/UpdateManager.cs`：`UpdateInfo`（version/url/sha256/size/notes）与 `UpdateSettings`（清单地址，存 `%LOCALAPPDATA%\XC PDF Reader\update-source.json`）；`CheckAsync`（20 秒超时、兼容 BOM）、`IsNewer`（版本补齐四段再比较，避免 1.2.142 与 1.2.142.0 误判）、`DownloadAsync`（流式下载 + 进度 + SHA256 校验，失败删包）、`LaunchUpdater`（把 PowerShell 更新器写到 updates 缓存，传入 PID / zip / 目标目录 / exe / 备份目录，程序目录不可写时 `Verb=runas` 提权）。
  - 更新器脚本：等待主进程退出 → 解压到临时目录并确认含 `XC PDF Reader.exe`（兼容 zip 内多一层根目录）→ 备份当前程序目录到 `%LOCALAPPDATA%\...\updates\backup` → 覆盖 → `Start-Process` 重启；任何异常回滚备份并重新拉起旧版本。
  - 新增 `Dialogs/UpdateDialog.cs`：清单 URL 输入、检查 / 详情 / 进度条 / 状态栏、安装前 `Msg.Show` 确认（提示先保存文档），启动更新器后 `Environment.Exit(0)` 关闭本实例。
  - 新增 `Tools/BuildUpdatePackage.ps1`：从 `bin\Release\net8.0-windows` 生成全量 zip（排除 pdb/log/tmp）与无 BOM 的 `update.json`（SHA256 用 `Get-FileHash`）。
  - `MainWindow.xaml` 帮助菜单加「检查更新(_U)…」；`MainWindow.xaml.cs` 加 `OnUpdate`。
- 设计取舍：更新器用独立 PowerShell 进程而不是主程序自身（主 exe/dll 运行时被锁，不能覆盖自己）；缓存与备份放在 LocalAppData 而非程序目录，避免覆盖时被清掉；默认手动检查、不自动联网，避免无清单时报错或打扰；不做增量更新，全量包最易校验与回滚。
- 安全说明：只信任自己填的清单地址；SHA256 为空时跳过校验（界面提示）；未做数字签名验证，如需强校验可后续加签名。
- 脚本编码坑：`Tools\BuildUpdatePackage.ps1` 与内嵌更新器脚本都保持纯 ASCII。Windows PowerShell 5.1 按 ANSI 读取无 BOM 的 .ps1，中文注释 / 字符串会被误解码甚至导致「字符串缺少终止符」等 7 处解析错误；`update.json` 是数据文件、用 UTF-8 无 BOM 写出不受影响。两个脚本已用 `Parser.ParseFile` 实测 0 语法错误。
- 验证：构建 0 错 0 警，lints 通过；待 GUI 复测（用脚本生成 zip + update.json → 本地 HTTP 静态服务或上传到 Releases → 软件填清单直链 → 检查到新版本 → 下载校验 → 确认后自动关闭、覆盖、重启 → 故意损坏 zip 验证校验失败与回滚）。

## 2026-11-14 V1.2.141

**新增｜帮助 ▸ 意见反馈 / 留言板（邮件投递）**

- 需求：帮助菜单增加留言板，用于改进建议、Bug 反馈、新功能建议等；含标题、内容、留言者或匿名；点确定自动发邮件到 `12632565@qq.com`。
- 关键约束：软件是纯本地 WPF 程序、无服务端、无内置发件账号，**没有发件邮箱凭据就无法真正「自动」投递**。设计成双通道，保证功能开箱可用且能在配置后完全自动。
- 改动：
  - 新增 `Dialogs/FeedbackMailer.cs`：`ToAddress` 常量；`FeedbackSmtpSettings`（Host/Port/EnableSsl/From/AuthCode + `IsConfigured`），JSON 存 `%LOCALAPPDATA%\XC PDF Reader\feedback-smtp.json`；`BuildSubject` / `BuildBody`（附类型、标题、留言者、时间、程序集版本、OS 版本）；`SendAsync` 用框架内置 `System.Net.Mail.SmtpClient` 走 STARTTLS 发送（`#pragma warning disable SYSLIB0014`，避免引入 MailKit 等新 NuGet 依赖）；`OpenMailto` 用 `Process.Start(UseShellExecute=true)` 打开系统邮件客户端，正文超 1500 字截断。
  - 新增 `Dialogs/FeedbackDialog.cs`：纯代码 WPF 窗口，Grid 表单（类型下拉 / 标题 / 留言者 + 匿名勾选 / 多行内容），底部按钮行 + 状态栏，折叠的「发件设置」区（服务器 / 端口 / SSL / 发件邮箱 / 授权码）。点「发送」校验标题与内容 → 保存设置 → 已配置则 SMTP 自动发送，失败或未配置则回退 mailto，结果都写在状态栏；全程异步、按钮防重入。
  - `MainWindow.xaml` 帮助菜单加「意见反馈 / 留言板(_B)…」（信封图标）；`MainWindow.xaml.cs` 加 `OnFeedback` 以 `ShowDialog()` 打开。
- 安全说明：授权码以明文保存在本机当前用户目录，界面明确提示使用邮箱「SMTP 授权码」而非登录密码；不上传、不内置任何账号。
- 验证：构建 0 错 0 警，lints 通过；待 GUI 复测（帮助菜单打开留言板 → 填标题 / 内容 / 匿名 → 未配置时系统邮件客户端预填收件人与主题 → 配置 QQ 邮箱发件授权码后点发送，收件箱收到带版本信息的邮件 → SMTP 填错时状态栏给出失败原因并回退 mailto）。

## 2026-11-14 V1.2.140

**优化｜外观主题：两个按钮合二为一，改用太阳 / 月亮图标**

- 需求（截图）：V1.2.138 加的「深色 / 浅色」两个文字按钮占位置，改为一个按钮；深色模式显示太阳图标、浅色模式显示月亮图标。
- 语义：图标表示「点此将切换到的模式」——深色界面显示太阳（去浅色），浅色界面显示月亮（去深色），与用户给的两张图标一一对应。
- 改动：
  - `MainWindow.xaml`：右列 `StackPanel` 内两个 `BtnThemeDark/BtnThemeLight` 换成单个 `BtnThemeToggle`（26×20，复用 `ActionButton` 模板 + `Th.InputBg` 底 / `Th.Border` 边）；内容叠在 15×15 `Grid` 里：`IconThemeSun`（中心圆用两个严格半圆 + 八条放射线）、`IconThemeMoon`（两段圆弧构成的弯月 + Z 闭合），描边 `Th.Text` 动态资源、`Fill=Transparent`、圆头线帽，初始只显示太阳。
  - `MainWindow.xaml.cs`：`OnThemeQuickSwitch` 改用 `ThemeManager.IsDarkMode()` 判断实际明暗，切到相反的固定模式并 `Save()` + `Apply()` + `ThemePulse()`；`UpdateThemeQuickButtons()` 更名 `UpdateThemeQuickButton()`，按明暗切两个 Path 的 `Visibility`，ToolTip 显示当前状态与目标模式；构造、`ApplyPreferences()`、`OnWindowsMessage` 三处调用同步改名。
- 设计取舍：不再有「两个都不高亮」的 System 态，跟随系统时按实际明暗显示对应图标；「跟随系统」仍由首选项设置，夜间模式临时深色的既有联动不改。
- 验证：构建 0 错 0 警，lints 通过；待 GUI 复测（深色下显示太阳、点击变浅色且图标变月亮、再点回深色；跟随系统且系统切主题时图标跟着变；首选项改回跟随系统后提示更新；图标在明暗主题下对比度足够）。

## 2026-11-14 V1.2.139

**优化｜MD 预览：不同级标题显示不同颜色**

- 现象（截图）：AI 文档分析预览视图里「关键数据与术语」「结论与建议」「一句话总结」以及 `###` 小节标题全是同一个前景色，只能靠字号区分层级。
- 根因：`Dialogs/MarkdownRenderer.cs` 的 `MakeHeading()` 只设置了 `FontSize` / `FontWeight` / `Margin`，前景继承 `FlowDocument` 上的 `Th.Text`；主题调色板里也没有标题专用色。
- 改动：
  - `ThemeManager.cs` 的 `LightPalette` / `DarkPalette` 各新增 `Heading1` ~ `Heading6` 六个键（浅色深字 `#1268C3 / #0B7A6B / #7A4F00 / #7B3FA0 / #B0422E / #5A616B`；深色提亮 `#82B8FF / #5FD6C0 / #E8C46A / #C79BFF / #FF9C86 / #B4BBC6`），由 `Build()` 自动注册为 `Th.HeadingN` 动态资源。
  - `MarkdownRenderer.MakeHeading()` 对标题 `Paragraph` 调 `SetResourceReference(TextElement.ForegroundProperty, "Th.Heading" + level)`；DynamicResource 让明暗主题切换实时生效，标题内粗体 / 斜体 / 行内代码 Span 继承该色，链接仍保留 `Th.HoverText`。
- 未改：字号 / 边距 / 解析逻辑、「源码」视图的纯 `TextBox`（等宽原样显示 Markdown）、复制与「保存为 .md」内容。
- 验证：构建 0 错 0 警，lints 通过；待 GUI 复测（生成含 `#` / `##` / `###` 的报告，各级标题颜色不同；切换深色 / 浅色后标题色同步变化且清晰可读；源码视图与导出内容不变）。

## 2026-11-14 V1.2.138

**新增｜主窗口右上角外观主题「深色 / 浅色模式」快捷切换**

- 需求（截图红框）：在窗口右上角加深色模式 / 浅色模式的快捷切换按钮，免于每次进首选项。
- 位置取舍：标题栏由 Windows DWM 绘制（`ThemeManager.ApplyTitleBar` 只改 DWMWA_USE_IMMERSIVE_DARK_MODE），标准 WPF 窗口无法在其中放控件；引入 WindowChrome 自定义标题栏会牵动系统按钮、拖动与双击最大化，改动面过大。因此把按钮放在菜单栏同一行的最右端，视觉上紧贴窗口右上角红框处。
- 改动：
  - `MainWindow.xaml`：`MainMenu` 由根 DockPanel 直接子项改为两列 `Grid`（左 `*` 装 Menu、右 `Auto` 装按钮组，整体仍 `DockPanel.Dock=Top`），右列 `Border` 内放 `BtnThemeDark` / `BtnThemeLight`；复用 `ActionButton` 样式并覆盖尺寸 / 字号 / 字体，前景 `Th.Text`、背景 `Th.InputBg`，底边框与菜单栏一致。
  - `MainWindow.xaml.cs`：`OnThemeQuickSwitch` 写入 `AppPrefs.Current.Theme` → `Save()` → `ThemeManager.Apply(mode)` → `LayoutAnim.ThemePulse()`；`UpdateThemeQuickButtons` 用 `Th.Selected` 标记当前偏好，在 System 模式下两个都不高亮并在 ToolTip 显示实际明暗；构造、`ApplyPreferences()`、`OnWindowsMessage`（ImmersiveColorSet）三处调用保持同步。
- 设计取舍：快捷按钮只提供深 / 浅两个固定模式，「跟随系统」仍由首选项设置；夜间模式临时套用深色的既有联动不改，按钮高亮始终反映已保存的偏好而非临时外观。
- 验证：构建 0 错 0 警，lints 通过；待 GUI 复测（启动后默认跟随系统、按钮都不高亮 → 点「浅色」界面立即变浅且标题栏同步 → 点「深色」变深 → 重启保持 → 首选项改回跟随系统后按钮取消高亮 → Windows 切换应用主题时悬停提示更新）。

## 2026-11-14 V1.2.137

**新增｜AI 文档分析：报告区右上角 MD 预览 / 源码切换**

- 需求（截图红框）：在文本显示区右上方增加「MD 文档预览 / 源码」切换按钮，让 Markdown 报告能直接阅读排版结果。
- 现状：V1.2.131 起报告区只有一个只读 `TextBox`（等宽字体），显示原始 Markdown 标记；思维导图功能的 ```mermaid 代码块也只是纯文本。项目无 WebView2 / Markdown 渲染库依赖。
- 设计取舍：
  - 用 WPF 自带 `FlowDocument` + `FlowDocumentScrollViewer` 做预览，新增 `Dialogs/MarkdownRenderer.cs` 手写转换器（标题 / 段落 / 列表 / 引用 / 表格 / 围栏代码块 / 分隔线 / 行内粗斜体、删除线、行内代码、链接），零新增 NuGet 依赖、零脚本执行、零网络访问。
  - 不解析、不渲染 Mermaid 图形：只把代码块按等宽文本显示并加提示，避免引入图形布局引擎；需要可视化导图仍按 V1.2.133 的方式导出 .md 后用外部编辑器渲染。
  - 不做可编辑预览：`_report.Text` 保持唯一数据源，复制 / 保存 / 提示词回显全部读它，避免两份文本不同步。
- 改动（`Dialogs/AIAnalysisDialog.cs`）：
  - 新增 `_viewer`（FlowDocumentScrollViewer）、`_btnPreview` / `_btnSource`、`_previewMode`、`_previewDirty`、220ms 的 `_previewTimer`。
  - 报告区由直接挂 `TextBox` 改为 `Border` → `Grid` 叠放源码 `TextBox`、预览 `FlowDocumentScrollViewer` 与右上角切换胶囊（`HorizontalAlignment=Right / VerticalAlignment=Top / ZIndex=10`）；边框统一由外层 `Border` 绘制，报告区仍零外边距贴住状态栏。
  - `SetReport()` 统一写入并立即刷新预览；`OnDelta()` 流式输出时节流重建；生成完成后停止定时器并强制刷新一次（修正流式半截 ``` 围栏）；`RefreshPreview()` 沿可视化树找 `ScrollViewer`，重建文档后恢复滚动位置，跟读时保持在底部。
  - 源码 `TextBox` 顶部 `Padding=34`、预览 `FlowDocument.PagePadding` 顶部 36，给悬浮按钮留出空间；切换按钮选中态用 `Th.Selected` 动态资源，主题切换实时跟随。
- 验证：构建 0 错 0 警，lints 通过；待 GUI 复测（打开 AI 文档分析 → 默认预览显示排版后的标题 / 表格 / 列表 → 点「源码」显示原始 Markdown → 复制 / 保存内容一致 → 切换到思维导图后 mermaid 代码块有提示 → 流式生成不卡顿、滚动位置不跳 → 明暗主题下文字与代码块对比度正常）。

## 2026-11-14 V1.2.136

**新增｜文档分析技能库（SKILL.md 导入 + 自动选用）**

- 需求：增加开源 PDF 文档阅读技能，支持 GitHub 免费 Skill 链接自动提取或本地添加，AI 文档分析自动选择适合的 Skill 生成最适合的报告。
- 调研：`https://github.com/anthropics/skills` 默认分支 main，PDF 技能在 `skills/pdf`（README 注明 Apache-2.0）；SKILL.md 为 YAML frontmatter（`name` / `description` / 可选 `license`）+ Markdown 正文。contents API `.../contents/skills/pdf?ref=main` 已联网验证能返回 SKILL.md 的 download_url。该技能正文是 pypdf / pdfplumber / qpdf 等 Python 操作示例，**软件没有脚本执行环境**，故不内置其正文、也不执行脚本。
- 设计取舍：技能 = 分析报告的领域规范（正文注入 system prompt），不是可执行的 PDF 处理工具；导入整仓会带入几十个无关技能，故只支持具体技能目录 / 单文件链接。
- 改动：
  - 新增 `LLM/DocSkillLibrary.cs`：`DocSkill` 数据类、`Root`（%LOCALAPPDATA%\XC PDF Reader\doc-skills）、`EnsureBuiltIns()` 首次写入 4 个原创分析技能、`Load()` 解析 frontmatter（正文超 12000 字截断）、`SetEnabled`（.disabled 标记）/`Delete`、`ImportLocal`（文件或文件夹）、`ImportGitHubAsync`（raw/blob/.md 直链 + tree 目录 contents API；`NormalizeRaw` 把 blob 转 raw）、`PickAsync`（关键词打分 → 明显命中直接用 → 否则 LLM 从编号列表裁定；`ChatAsync` 必须传非空 IProgress 才走 SSE）。
  - 新增 `Dialogs/SkillLibraryDialog.cs`：纯代码 WPF 窗口，ListBox + GitHub URL 输入框 + 从 GitHub / 本地导入 + 启用停用 + 删除（`Msg.Show` 确认）+ 状态栏。
  - `MainWindow.xaml.cs` 拓展菜单加「文档分析技能库…」；`AIAnalysisDialog.RunAnalysis()` 在抽取文字后调用 `PickAsync`，把技能正文追加到 system prompt，状态栏显示选用结果与完成提示。
- 验证：构建 0 错 0 警，lints 通过；GitHub contents API 路径已联网验证；待 GUI 复测（拓展菜单打开技能库可见 4 个内置技能 → 粘贴 tree 链接导入 → 打开 AI 文档分析，状态栏显示自动选中技能、报告结构随技能变化；断网时离线打分仍可用）。

## 2026-11-14 V1.2.135

**修复｜AI 文档分析：文本显示区与状态栏之间的空白带**

- 现象（截图红框）：报告区底部与状态栏之间有一条浅色空白，状态栏文字在更下方。
- 根因：`AIAnalysisDialog` 构造里的 `_report.Margin = new Thickness(0,0,0,8)` 是 V1.2.131 之前「底部按钮行」时代遗留的间距；V1.2.132 把 `_status` 移到底部状态栏后没有同步去掉，8px 外边距露出 Window 默认背景。报告 TextBox 的底边框又与状态栏 `BorderThickness=(0,1,0,0)` 的上边框叠在一起，加深了「两条线中间夹空白」的观感。
- 改动（`Dialogs/AIAnalysisDialog.cs`）：
  - `_report.Margin = new Thickness(0)`；`_report.BorderThickness = new Thickness(1,1,1,0)`（去掉底边）。
  - `_status.Margin` 由 `(10,3,10,3)` 收紧为 `(10,2,10,2)`，状态栏更薄。
- 未改：状态栏 `Th.PanelAltBg` 底色与上边框（保持与主窗口状态栏一致）、报告区 `Th.InputBg` 背景。
- 验证：构建 0 错 0 警，lints 通过；待 GUI 复测（报告区深色背景直接延伸到状态栏上边框，中间无浅色空白带；滚动条、复制 / 保存不受影响）。

## 2026-11-14 V1.2.134

**修复｜对比 / 分屏查看窗口显示太大**

- 现象（截图）：`CompareWindow` 几乎盖住整个主窗口，工具栏按钮与状态文字挤在一行。
- 根因：`CompareWindow` 构造里硬编码 `Width = 1280; Height = 840;`，与屏幕 / 工作区无关；没有 `WindowStartupLocation`，位置由系统默认；工具栏是水平 `StackPanel`，窄窗口下不换行，越界的项被裁。
- 改动（`CompareWindow.cs`）：
  - 尺寸改为 `var work = SystemParameters.WorkArea; Width = Math.Min(Math.Clamp(work.Width*0.66,720,1000), work.Width-32); Height = Math.Min(Math.Clamp(work.Height*0.68,500,680), work.Height-32);`，加 `MinWidth=640 / MinHeight=420` 与 `WindowStartupLocation = CenterScreen`。1920×1080 下为 1000×680（与 AI 文档分析窗口同级），1366×768 下约 901×522。
  - `BuildToolbar()` 的 `StackPanel` → `WrapPanel`（工具栏所在行是 `GridLength.Auto`，换行后自动增高）。
  - `_status` 加 `MaxWidth=300 / TextTrimming=CharacterEllipsis`，`UpdateStatus()` 同步写 `ToolTip` 保留完整提示。
- 说明：未改调用方（`MainWindow.xaml.cs:4926` 仍 `new CompareWindow().Show()`），因此用 `CenterScreen` 而非 `CenterOwner`。
- 验证：构建 0 错 0 警，lints 通过；待 GUI 复测（打开窗口后尺寸明显小于主窗口且居中；缩窄窗口时工具栏自动换行、按钮不重叠；双栏仍能打开文档并适应宽度）。

## 2026-11-14 V1.2.133

**新增｜AI 文档分析：思维导图 + 记忆大纲生成**

- 需求：在 AI 文档分析窗口增加思维导图和记忆大纲生成功能。
- 设计假设：窗口现有输出是只读 Markdown 报告（可复制 / 保存 .md），两种新类型同样以 Markdown 文本输出；思维导图采用通用 Mermaid `mindmap` 语法并附等价文本大纲，可在支持 Mermaid 的编辑器中渲染；记忆大纲定位为「便于复述与自测的速记材料」。若需要窗口内可视化节点图，需另外引入渲染控件。
- 改动（`Dialogs/AIAnalysisDialog.cs`，纯代码构造 UI）：
  - 新增 `_kind` ComboBox（文档概要 / 思维导图 / 记忆大纲，默认 0），加入主题资源遍历、设置行循环（分隔由 16 缩到 12 以容纳第三项）与 ToolTip；`_kind.SelectionChanged` 只在状态栏提示「已选择…，点「一键生成」开始生成」，不自动消耗 API 请求。
  - 新增 `KindName()`、`ExtractedUserText()`（对比模式带 A/B 标记、单文档带标题）、`BuildMindMapPrompts()`、`BuildMemoryOutlinePrompts()`；`BuildPrompts()` 开头按 `_kind.SelectedIndex` 分派 1/2，0 保持原有概要 / 对比提示词不动。两组提示词均有中英版本，复用 `IsEnglishOutput()` 与 `DepthHint()`。
  - `RunAnalysis()` 进度 / 完成状态文案按类型显示，思维导图完成时额外提示 Mermaid 语法查看方式；`DefaultReportName()` 用 `suffix` 按语言 + 类型命名导出文件。
- 验证：构建 0 错 0 警，lints 通过；待 GUI 复测（切换三种类型分别点「一键生成」→ 报告区与状态栏文案正确；思维导图输出可保存 .md 并在 Mermaid 编辑器渲染；记忆大纲含 5 个章节；保存文件名带「思维导图 / 记忆大纲」）。

## 2026-11-14 V1.2.132

**调整｜AI 文档分析窗口：新增底部状态栏，提示文字移入**

- 需求（截图红框）：「正在生成文档概要（流式输出，请稍候）…」等提示当前显示在报告正文上方，要求对话框显示状态栏、把该提示显示到状态栏。
- 改动（`Dialogs/AIAnalysisDialog.cs`，纯代码构造 UI）：
  - `_status` 字段初始化改为 `Margin(10,3,10,3) / FontSize 12 / TextTrimming.CharacterEllipsis / VerticalAlignment.Center / Text="就绪"`，前景色由 `Th.Text` 改为 `Th.TextMuted`。
  - 新增 `statusBar = new Border { BorderThickness = (0,1,0,0), Child = _status }`，背景 `Th.PanelAltBg`、边框 `Th.Border`（对齐 `MainWindow.xaml:716` 的 StatusBar）。
  - 主 `DockPanel` 中 `_status` 由 `Dock.Top` 改为 `statusBar` 的 `Dock.Bottom`；children 顺序 header(Top) → settingsRow(Top) → statusBar(Bottom) → _report(fill)。
- 说明：8 处 `_status.Text` 赋值（正在抽取 / 正在生成 / 完成 / 未配置 / 生成失败 / 已复制 / 已保存 / 保存失败）无需改动，自动落到新状态栏；报告区不再被状态文字挤占一行。
- 验证：构建 0 错 0 警，lints 通过；待 GUI 复测（打开 AI 文档分析 → 底部出现状态栏并显示生成进度，完成后显示「概要生成完成…」；复制 / 保存后状态栏同步更新）。

## 2026-11-14 V1.2.131

**调整｜AI 文档分析窗口：按钮上移 + 去掉「关闭」按钮**

- 需求（截图红框）：窗口底部一排「一键生成 / 复制 / 保存为 .md / 关闭」需移到上面，并去掉「关闭」按钮。
- 改动（`Dialogs/AIAnalysisDialog.cs`，纯代码构造 UI，无 XAML）：
  - 删除 `_close` 字段与 `_close.Click += (_, _) => Close()`；按钮数组由 `{_regen,_copy,_save,_close}` 改为 `{_regen,_copy,_save}`。
  - 顶部 `settingsRow` 由 `StackPanel` 改为 `DockPanel { LastChildFill = false }`：左侧 `settingItems`（原报告语言 / 分析深度 StackPanel）`Dock.Left`，右侧 `btns` `Dock.Right`；`btns` 不再 `DockPanel.SetDock(..., Dock.Bottom)`，主 `dock` 也不再添加它。
  - 主 DockPanel 顺序保持 header(Top) → settingsRow(Top) → _status(Top) → _report(fill)。
- 取舍：关闭入口只剩标题栏 X / Alt+F4（用户要求去掉按钮）；未额外加 Esc 关闭。
- 验证：构建 0 错 0 警，lints 通过；待 GUI 复测（AI 文档分析窗口顶部右侧三个按钮可用，底部无按钮行，报告区扩展到底部）。

## 2026-11-14 V1.2.130

**调整｜AI 划词翻译入口：菜单项 → 快捷栏徽章图标**

- 需求（截图红框）：选中文本后弹出的浮层里，「AI 划词翻译」以文字菜单项出现；要求去掉该菜单项，改为在顶部快捷栏添加图标，图标为圆圈中带「译」的徽章，并用分割线与前面的图标隔开。
- 改动（均在 `Controls/PdfPageView.cs`）：
  - `ShowSelectionPopup`：删除 `SelMenuTile("Geo.List", "AI 划词翻译", ...)` 文字项；在图标行 `Geo.Squiggly` 之后加一条 `Width=1 / Height=18 / #48484C` 的竖直分隔线，再加 `SelBadgeTile("译", "AI 划词翻译", () => Run(TranslateSelection))`。
  - 新增 `SelBadgeTile(label, tip, click)`：Grid(18×18) 内叠 `Ellipse`（白色 1.4 描边圆）+ 居中 `TextBlock`（「译」，10.5pt 加粗白字），交给现有 `SelTile` 复用悬停高亮 / 点击行为 / 30×30 尺寸。
  - `AddDocContextItems`：删除 `HasSelectionRects` 时置顶的「AI 划词翻译」右键菜单项及其 Separator，使菜单形式入口全部退出；`TranslateSelection()` 仍由快捷栏调用。
  - `MainWindow.xaml.cs` 的 `OnTranslateFullDoc` 注释同步为「入口在快捷栏徽章图标」。
- 取舍：右键菜单里的同名项一并移除，功能入口唯一化为快捷栏徽章；若仍需右键入口可再恢复。
- 验证：构建 0 错 0 警，lints 通过；待 GUI 复测（选中一段文本 → 快捷栏出现竖线 + 「译」圆徽章，点击后译文卡贴选区右侧；浮层随图标增多自动重新度量居中）。

## 2026-11-14 V1.2.129

**修复｜某些文档默认适应宽度时页面未居中、左边留大黑边**

- 现象（截图）：打开 Datasheet 类文档，缩放 254%、默认适应宽度，白页左缘距阅读区左缘约 150px 全为黑色，页面右缘与视口齐平，底部出现水平滚动条。
- 根因：`VirtualizingPagePanel.SetLayout` 的 `_contentWidth` 取「所有行中最宽的一行」；`ArrangeOverride` 把 `avail = Math.Max(finalSize.Width, _contentWidth)` 传给 `SlotOf`，而 `SlotOf` 用 `left = max(0,(avail-rowW)/2)+_left[page]` 居中。当文档后面存在更宽的页使 `_contentWidth > ViewportWidth` 时，较窄的首页被相对「整个滚动内容宽度」居中，而非相对当前显示区居中 → 视口从 HorizontalOffset=0 看就是左侧黑边、右侧被裁。次要放大项：`PageScroll` 为所有标签共享，`RestoreAnchor` / `ActivateTab` / `SetZoom` 全部只操作 VerticalOffset，横向偏移残留会带到新文档。
- 改动：
  - `Controls/VirtualizingPagePanel.cs`：新增 `CenterWidth`（`ScrollViewer.ViewportWidth - Margin.Left - Margin.Right`，找不到 ScrollViewer 时回退 `_contentWidth`）；`SlotOf` 开头把传入的 `availWidth` 夹到 `CenterWidth`。`ArrangeOverride`（布局宽 / 内容宽）与 `OnRender`（ActualWidth）因此自动统一到视口基准，`MainWindow.ScrollToSearchRect` 传 ViewportWidth 的调用也一并对齐。
  - `MainWindow.xaml.cs`：`ActivateTab` 的 Loaded 回调在 `PageScroll.UpdateLayout()` 之后加 `ScrollToHorizontalOffset(0)`；`SetZoom` 在 `RestoreAnchor` 之后，若 `IsFitMode` 则同样归零。
- 取舍：不修改 `UpdateFitZoom`（仍按首页 / 双页前两页较宽者算），保证首页按视口宽度铺满；其他更宽页仍可通过水平滚动条查看，不会因迁就宽页把首页缩小。曾尝试按全文档最宽页算缩放，会让页面明显变小、反而不「适应宽度」，已撤销。
- 验证：构建 0 错 0 警，lints 通过；待 GUI 复测（打开尺寸不一致的 Datasheet → 首页左右留白对称、无单侧大黑边；切换标签 / 改变窗口宽度后仍居中；放大到 400% 时超宽页仍可横向滚动）。

## 2026-11-14 V1.2.128

**移除｜有道 / 欧路词典引擎，取词翻译改 AI 大模型智能翻译**

- 需求（截图红框）：首选项 → 取词翻译 → 「取词翻译引擎」下拉（有道词典 / 欧路词典）及下方说明整块去除，换为 AI 翻译引擎智能翻译。
- 改动：
  - `Translation/WordLookup.cs` 重写：删除 `EngineYoudao/EngineEudic/CurrentEngine/CurrentEngineName`、两个 HttpClient（含 gzip/br 解压与浏览器 UA 反爬）、`FetchYoudaoAsync/ParseYoudao/ParseEudic` 及全部正则解析（约 370 行）；新增 `FetchAsync` 调 `LlmClient.ChatAsync(system, word, ct, new NullProgress())`——**必须传非空 IProgress 才会走 SSE 流式分支**，否则非流式 JSON 会被 `ChatAsync` 逐行过滤掉、返回空字符串；`ParseAiReply` 按行拆音标 / 释义 / 例句填充原 `LookupResult`；`LookupResult` 新增 `Transient` 标记，未配置 / 失败结果不进缓存。
  - `AppPrefs.cs` 删除 `WordLookupEngine`；`PreferencesDialog.xaml` 删除 `CbWordLookupEngine` ComboBox、两个 ComboBoxItem 与旧说明，改为 AI 引擎静态说明 + 「打开 AI 大模型设置…」按钮；`PreferencesDialog.xaml.cs` 删除加载 / 保存引擎逻辑，新增 `OnOpenAiSettings`（关闭后 `WordLookup.ClearCache()`）。
  - `Controls/PdfPageView.cs`：`RequestWordLookup` 把 `_translateCts.Token` 传入 `LookupAsync`（鼠标移开即取消在途 LLM 请求）；卡片兜底文案改为 AI 相关，「网络」行改「例句」；`CloseTranslateTip` 无论是否已有结果都清 `_translateWord`，修复「在途请求被取消后移回同词被同词跳过挡住、不再查询」。
- 验证：构建 0 错 0 警，lints 通过；源码已无 `有道 / 欧路 / EngineYoudao / EngineEudic / WordLookupEngine / CbWordLookupEngine` 有效引用（仅两条历史说明注释与 obj 缓存）；待 GUI 复测（配置 AI 后悬停英文词 → 卡片显示发音、释义、例句，来源「AI 智能翻译」；未配置时显示配置提示；首选项页无引擎下拉）。

## 2026-11-14 V1.2.127

**方向调整｜放弃全文翻译对照排版，改为 AI 划词翻译浮层**

- 背景：V1.2.122~126 多次调整全文翻译右栏（坐标定位 → 流式 → 成段 / 连续编号 / 自适应高度），版面仍难做到与原文逐段对照；用户要求改用「选中文本后即时翻译该段、在选区旁弹译文」的方式。
- 改动：
  - `Controls/PdfPageView.cs` 新增 `TranslateSelection()` / `RunAiTranslateAsync()` / `ShowAiTranslateCard()` / `PositionAiTranslatePopup()` / `ViewportInControl()` / `CloseAiTranslatePopup()`：`GetSelectedText()` 取文本 → 判 `LlmClient.IsConfigured` → `LlmClient.ChatAsync(..., IProgress<string>)` 流式回填；`CancellationTokenSource` 保证重复触发、关闭、页视图回收时旧任务失效。
  - 卡片样式复用取词卡（固定 300 宽 StackPanel、Th.PanelBg / Th.Border、「译」徽标、BuildDivider），新增 ScrollViewer（MaxHeight 280）、状态行与「复制译文」；`StaysOpen=false` + `DispatcherPriority.Loaded` 延迟打开，避免右键菜单收起时的鼠标捕获立刻把卡片关掉。
  - 定位：`_selRects` → `PageRectToScreen` 得控件坐标包围盒，`ScrollViewer.TransformToDescendant(this)` 把可视窗口换算到同一坐标系；比较右 / 左可用宽度决定贴右缘或左缘，并把 x / y 夹进可视区。
  - 入口：右键菜单有选区时置顶「AI 划词翻译」；选区工具条在「复制文本」下新增同名项；移除右键里的「全文 AI 翻译」及 `RequestTranslateFullDoc` 事件与 `MainWindow` 的订阅 / 解绑（否则 CS0067 警告）。
  - 生命周期：`ClosePopup()`、`RefreshAfterRestore()`、`SizeChanged` 均关闭卡片并取消在途请求；`MouseLeave` 不关闭，保证可滚动 / 复制。
- 取舍：侧栏「全文 AI 翻译」入口与 `FullDocTranslateView` 实现保留，仅从页内右键移除，避免破坏已有功能；如需彻底删除可再执行。
- 验证：构建 0 错 0 警，lints 通过；待 GUI 复测（选中一段英文 → 右键 → 卡片出现在选区右侧；把选区放到页面右缘 → 卡片翻到左侧；长段落可滚动 / 复制；未配置 AI 时显示配置提示）。

## 2026-11-14 V1.2.126

**改进｜译文碎片化 / 编号跳跃 / 内容被页面高度限制**

- 现象（截图红框标出对照页面区域）：右栏译文被切成一行一编号的短句（`[10] 隔离高电流门极`、`[11] NCD57100...`、还有 `[14] —`、`[19] —` 等孤立标点块），编号从 10 起跳、看似重复，且译文堆到固定高度页面底边后放不下。
- 根因：① V1.2.124 为避免坐标定位溢出把段落合并收紧到 `gap<=0.9 行高 && 最多 6 行`，导致块过碎；② `AddRow` 按 `Y1/X0` 坐标排序显示，`[n]` 用的是原块索引，于是编号跳跃；③ 右栏 `Height=dispH` 固定 + 内层 ScrollViewer，内容超出后在页面内滚动，视觉上像被裁切。
- 修复：
  - `Pdf/PdfDocument.cs`：`GetPageTextBlocks` 段落合并改回 `gap <= avgH*1.6 && paraLines < 12`（译文已是流式排版，不再有绝对定位溢出问题），让译文成段。
  - `Translation/FullDocTranslateView.cs`：新增 `IsNoiseBlock`（trim 长度 <2 或不含任何字母/数字）并在 `BuildPagesAsync` 过滤，孤立标点块不进入翻译与显示；`AddRow` 右栏去掉坐标排序与双栏判定，改为 `for k=0..blocks.Count-1` 连续编号 `[k+1]`，`row.Views` 与 `row.DisplayOrder` 按同序添加（保证 `ApplyRow` 按索引回填正确）；`rightPage` 由 `Height=dispH` 改为 `MinHeight=dispH + VerticalAlignment=Top`（Height 自适应），移除内层 `ScrollViewer`，直接 `Child = StackPanel`；编号色 `#AAA`、段距 7、正文 12pt/行高 18。
  - 顶部说明改为「右：按原文段落顺序的译文页面（[n] 连续编号对应原文段落）」。
- 说明：截图未附文字，按可见问题（碎片化、编号跳跃、页面高度限制）处理；若红框想表达的是页面尺寸/占比等其他诉求，需用户进一步指明。
- 验证：构建 0 错 0 警，lints 通过；待 GUI 复测（英文 datasheet 第 1 页：右栏段落完整、编号连续 1..N、无孤立标点行、内容向下延伸不被裁切）。

## 2026-11-14 V1.2.125

**移除｜鸿蒙 OS 动效代码 + 首选项「动效风格」选项**

- 需求：移除鸿蒙 OS 动效相关代码，去掉首选项「动效设置」页红色框标记的「动效风格」选项行（iOS 风格 / 鸿蒙 OS 风格）。
- 改动：
  - `AppPrefs.cs`：删除 `public enum AnimationSet { iOS=0, HarmonyOS=1 }` 与 `public AnimationSet AnimSet { get; set; } = AnimationSet.iOS;`。JSON 反序列化默认忽略未知成员，旧 `prefs.json` 里的 `"AnimSet":1` 不会报错，保存时不再写出。
  - `LayoutAnim.cs`：删除 `HmDecelerateEase`（三次衰减）、`HmSpringEase`（`1-e^(-6t)cos(6.5t)`）两个私有缓动类及 `HmDecelerate`/`HmSpring` 静态实例；`Decel/Spring/Glide` 三个属性去掉 `AppPrefs.Current.AnimSet == AnimationSet.HarmonyOS ? ... : ...` 分支，固定返回 `IosDecelerate`/`IosSpring`/`IosGlide`，注释同步改为单曲线说明。
  - `PreferencesDialog.xaml`：删除「动效风格」Grid（含 `RbAnimiOS` / `RbAnimHarmony` 两个 RadioButton）及其两行布局注释；分组标题「动效集与整体速度」→「整体速度」。
  - `PreferencesDialog.xaml.cs`：删除加载时 `RbAnimiOS/RbAnimHarmony.IsChecked = ...` 两行与保存时 `p.AnimSet = ...` 一行。
- 保留：`Animations` 总开关、`AnimSpeed`（1x/2x/3x）、`AnimFlags` 逐项开关与倍速，以及 `Smooth` 交叉淡化曲线、iOS 三条曲线；其余代码对 `Decel/Spring/Glide` 的调用无需改动（仍为 `IEasingFunction` 属性）。
- 复查：源码 `*.cs` / `*.xaml` 已无 `鸿蒙|Harmony|AnimationSet|AnimSet|HmDecelerate|HmSpring|RbAnim` 命中；剩余命中都在历史更新日志与 obj 构建缓存（历史记录保留原样，obj 生成文件由构建自动重建）。
- 验证：构建 0 错 0 警，lints 通过；待 GUI 复测（首选项 → 动效设置：不再出现「动效风格」行，只有「整体速度」与逐项动效；动效表现与之前默认 iOS 风格一致）。

## 2026-11-14 V1.2.124

**修复｜译文页面乱七八糟、无法查看（文字堆叠重叠）**

- 现象：阅读区对照视图右栏中文译文全部堆在左上区域，字号巨大、相互覆盖，无法阅读（截图红框）。
- 根因（两处叠加）：
  1. `FullDocTranslateView.AddRow` 用 `Canvas.SetLeft/SetTop` 按原文块坐标绝对定位，宽度锁为原英文块宽；中文译文换行后实际高度远超原块矩形，向下覆盖相邻块。字号 `FontSize = clamp(6, 20, (Y1-Y0) * s * 0.78)` 用「整段高度」而非行高，多段合并后逼近 20pt，进一步加剧重叠。
  2. 小模型常忽略 `[n]` 编号要求，`ApplyRow` 的 fallback 把整页 `row.Raw` 全塞进 `Views[0]`，一个块内塞整页译文。
- 修复：
  - `Translation/FullDocTranslateView.cs`：右栏 `Canvas` 绝对定位改为 `ScrollViewer + StackPanel` 流式排版。按页宽 55% 判定双栏（`blocks>=6 && 左右各>=3 && 右栏>20%`），排序 `OrderBy(列组).ThenByDescending(Y1).ThenBy(X0)`；每块一行 `DockPanel`（左侧灰色 `[n]` 标记 + 右侧译文 `TextBlock`，FontSize=12、LineHeight=18、Wrap、Margin 底 8）；`views[k] = tb` 保证与 `Blocks` 索引对应，`row.DisplayOrder` 记录显示顺序；`ScrollViewer` 保证超出同尺寸页面时可滚动而不溢出重叠。
  - `ApplyRow`：`parts == null` 或「有效块 < 总块数一半」时调用新增 `DistributeRaw`——`Regex.Replace` 去掉残留 `[n]` 标记、按非空行均分到各 `Views`（流式 delta 可反复调用）；正常编号路径不变。`OnCopy` 按 `DisplayOrder` 输出。
  - `Pdf/PdfDocument.cs`：`GetPageTextBlocks` 段落合并加 `paraLines` 计数，条件由 `gap <= avgH*1.4` 收紧为 `<= avgH*0.9` 且 `paraLines < 6`，避免整页合成巨块（该 API 目前仅供全文翻译使用）。
  - 顶部说明改为「右：按原文块顺序编号的译文页面（[n] 对应原文块）」。
- 取舍：严格按原坐标镜像在中文译文换行时必然溢出重叠；优先保证可读性，用编号 `[n]` 维持与原文块的对照关系，白底同尺寸页面外观不变。
- 验证：构建 0 错 0 警，lints 通过；待 GUI 复测（英文 datasheet 全文翻译：右栏逐段 12pt 中文、无重叠、编号顺序与原文一致、可滚动；复制译文顺序一致；图片页仍跳过）。

## 2026-11-14 V1.2.123

**修复｜页面风格不对：系统原生 MessageBox 与深色主题不一致**

- 现象：深色主题下点「删除水印」后弹出「未找到本程序添加的水印。」提示，红框标注的是系统原生 MessageBox（浅色标题栏 + 白底），与整体深色 UI 明显不符。
- 原因：V1.2.112 引入 `Msg.Show` / `MessageDialog` 统一主题化弹窗后，仍有 16 处代码直接使用 `MessageBox.Show(owner, text, title, buttons, image)`，水印 / 页眉页脚相关功能全部在列。
- 修复：把 `MessageBox.Show(` 全量替换为 `Msg.Show(`（签名一致，参数顺序相同）：
  - `MainWindow.xaml.cs` 11 处（添加水印 2、删除水印 3、添加页眉/页脚 2、删除页眉/页脚 3、AI 文档分析 1）；
  - `CompareWindow.cs` 3 处；`Dialogs/DocumentPropertiesDialog.cs` 1 处；`Controls/PdfPageView.cs` 1 处（文档属性读取失败）。
  - 四个文件均已 `using PdfReader.Dialogs;` 或位于该命名空间，无需新增 using。
  - `Dialogs/MessageDialog.cs` 内部两处 `MessageBox.Show` 是「主题资源不可用（启动早期）」时的兜底，保留不动；注释中的文字同步保留。
  - `App.xaml` 已有全局 `TargetType="Button"` 深色样式（`Th.PanelBg`/`Th.Text`/`Th.Border`），主题消息框底部按钮自动跟随；窗口经 `ThemeManager.ApplyTitleBar(this)` 同步深色标题栏。
- 复查：全仓 `*.cs` 仅剩 `MessageDialog.cs` 兜底的 2 处 `MessageBox.Show`。
- 验证：构建 0 错 0 警，lints 通过；待 GUI 复测（深色主题下点「删除水印」/「添加水印」等提示应为深色主题化窗口）。

## 2026-11-14 V1.2.122

**改版｜全文 AI 翻译改为阅读区内按页分页（不再打开新窗口）**

- 需求：AI 全文翻译需要在阅读当前页面分页显示，而不是打开新窗口。V1.2.119 虽改成「阅读式页面对照」，但仍是独立 Window，本次彻底内嵌。
- 实现：
  - 新建 `Translation/FullDocTranslateView.cs`（`UserControl`，代码构建 UI）：从原 `FullDocTranslateWindow` 移植 `BuildPagesAsync/AddRow/TranslateRowAsync/ApplyRow/ParseNumbered/HasCjk`，保持左原文页面渲染图 + 右同尺寸 Canvas 坐标排版、图片页（<20 字符）跳过、`[n]` 编号块流式回填。改为顶部工具条（翻译全部/停止/跳到当前页/复制译文/AI 设置/退出对照）+ 状态行 + ScrollViewer（横纵均可滚，窄窗口不裁切）。
  - 公共 API：`Begin(doc,title,initialPage)`（`Stop()` 后递增 `_generation` 使旧任务失效，构建完自动 `Dispatcher.BeginInvoke(Loaded)` 定位到当前阅读页）、`Stop()`、`ScrollToPage(int)`（`_scroll.UpdateLayout()` 后 `BringIntoView()`）、`CloseRequested` 事件、`Func<int>? CurrentPageProvider`。`AiSettingsDialog` 的 Owner 改为 `Window.GetWindow(this)`。`StartTranslation()` 内部取当前 `_generation`，避免「翻译全部」重复点击时误用失效代次。
  - 删除 `Translation/FullDocTranslateWindow.cs`（全仓 .cs 已无引用）。
  - `MainWindow.xaml`：在 `PageScroll`/`DocOverlay` 同 Grid 第 2 列新增 `TranslateOverlay`（`Panel.ZIndex=7`、`Visibility=Collapsed`、背景 `Th.DocAreaBg`）+ 内层 `ContentControl Name=TranslateHost`；侧栏「全文 AI 翻译」菜单项加 ToolTip 说明「阅读区按页显示，再次点击退出」。
  - `MainWindow.xaml.cs`：`OnTranslateFullDoc` 改为切换（已显示则 `ExitTranslateMode()`；否则 new `FullDocTranslateView{CurrentPageProvider=()=>CurrentPageIndex}`、挂 `CloseRequested`、放入 `TranslateHost`、`TranslateOverlay.Visibility=Visible`、`Begin(_doc, _active.FilePath, CurrentPageIndex)`）；新增 `_translateView` 字段与 `ExitTranslateMode()`（Stop / 清 Host / 隐藏）。`ActivateTab` 早退分支后调用 `ExitTranslateMode()`（切文档停止在途任务并解除旧文档引用）；`CloseTab` 中 `_tabs.Count==0` 时同样退出。
- 验证：构建 0 错 0 警，lints 通过；待 GUI 复测（右键「全文 AI 翻译」→ 阅读区出现顶部工具条与按页对照卡片、自动定位当前页；翻滚/跳到当前页/复制译文/停止/AI 设置可用；点「退出对照」或再次点菜单恢复原阅读；切换标签与关闭文档自动退出）。
- 注意：对照视图覆盖 `PageScroll`（ZIndex 7），期间原阅读区不可交互；`PerfHud` ZIndex 8 且不命中测试，不受影响。

## 2026-11-14 V1.2.121

**新增｜受保护文档：标签标记 + 拓展/右键菜单自动出现「文件去保护」**

- 需求：打开受保护文档时标签栏文档名后加「(受保护文档)」；拓展菜单、文件右键菜单自动增加「文件去保护」菜单项。
- 实现：
  - `MainWindow.xaml.cs`：`DocTab` 新增 `TabTitle`（`Path.GetFileName(FilePath)` + `Doc.IsEncrypted ? " (受保护文档)" : ""`，try/catch 兜底），仅用于标签栏；`MakeTabItem` 的标题 `TextBlock.Text = tab.TabTitle`。
  - 新增 `SyncProtectionUi()`：按 `_doc?.IsEncrypted` 设置 `_miFileUnprotect`、`_sepFileUnprotect`（配套分隔线）与 `MiRemoveProtection` 的 Visibility，并遍历 `_tabs` 调 `RefreshTabTitle`。调用点：构造（BuildExtendedToolsMenu 之后）、`ActivateTab` 正常路径与 `_active==tab` 早退分支、`OnThumbMenuOpened`（侧栏右键菜单打开）。
  - `RefreshTabTitle` 修复：标签头实际是 `DockPanel`，旧实现判断 `StackPanel` 且取 `Children[0]`（是关闭按钮）永远不生效；改为 `Header is Panel` 并遍历子控件找 `TextBlock` 写入 `tab.TabTitle`。
  - `BuildExtendedToolsMenu` 末尾新增「文件去保护」`MenuItem`（带解锁图标，Visibility 初始 Collapsed，Click → `OnRemoveProtection`），字段 `_miFileUnprotect` + `_sepFileUnprotect`。
  - `MainWindow.xaml`：侧栏「页面」右键菜单 `MiRemoveProtection` Header 改「文件去保护」并加 ToolTip；`OnThumbMenuOpened` 由「置灰 IsEnabled」改为 `SyncProtectionUi()` 显示/隐藏；`OnRemoveProtection` 各弹窗标题与状态文案统一为「文件去保护 / 已解除文件保护」。
  - `Controls/PdfPageView.cs`：新增 `event RoutedEventHandler? RequestFileUnprotect` 与 `Func<bool>? CanUnprotectFile`（主窗口注入的受保护判定）；`AddDocContextItems` 在「文件操作」分组末尾 `if (CanUnprotectFile?.Invoke() == true)` 才添加分隔线 + 「文件去保护」项，实现页内文档右键菜单自动增加。`MainWindow.RealizePage` 挂 `pv.RequestFileUnprotect += OnRemoveProtection` 并设 `pv.CanUnprotectFile = () => _doc?.IsEncrypted == true`；`UnrealizePage` 解挂并置 null。
- 说明：去保护是「另存为未受保护副本」，当前标签仍指向原受保护文档，故标记与菜单项保持显示；`_doc.IsEncrypted` 复用 V1.2.115 的 `FPDF_GetSecurityHandlerRevision > 0` 判定。
- 验证：构建 0 错 0 警，lints 通过；待 GUI 复测（打开加密 PDF：标签显示 `xxx.pdf (受保护文档)`；拓展菜单与两处右键菜单出现「文件去保护」；切到普通文档标签后菜单项与标记消失；另存为后标签名正确刷新）。

## 2026-11-14 V1.2.120

**修复｜导出 PDF 的新页码应替换原页码（此前新旧并存）**

- 反馈：V1.2.118 勾选页码后，导出页右下角出现「4/4」，但原页脚页码仍在；要求新页码替代原页码。V1.2.118 曾误判「原页码已烘进页面内容无法擦除」，实际上 pdfium 可枚举并改写页面文本对象。
- 实现（`Pdf/PdfDocument.cs`）：
  - 新增 `OldPageNumberPattern`（整块即页码：`4`、`4/29`、`4 / 29`、`- 4 -`、`[4]`、`(4)`、`Page 4 of 29`、`第 4 页/共 29 页`；纯数字只认 1~3 位，避免把页脚年份 `2024` 误判）、`PageNumberInTextPattern`（长页脚内嵌短语 `Page 4 of 29`、`第 4 页`、`4/29`）、`ReadTextObject`（`FPDFTextObj_GetText` 按 NUL 截取）。
  - `StampExportPageNumbers` 重写：`FPDFText_LoadPage` 后 `FPDFPage_CountObjects/GetObject/GetType(=FPDF_PAGEOBJ_TEXT)/GetBounds`，只在页脚下 15% 或页眉上 10% 带、文本 ≤200 字符的对象中收集；① 整块页码对象用 `FPDFText_SetText(obj,"N / M")` **原位改写**（保留原字号/颜色），其余同类用 `SetText(" ")` 清空（失败则 `FPDFPage_RemoveObject`，移除后对象由页面释放不可再 Destroy）；② 无整块匹配则用 `PageNumberInTextPattern.Replace(text,label,1)` 只替换内嵌短语并 `SetText` 回写，保留其他页脚文字；③ 均失败/未找到才在原位置或右下角新建 10pt Helvetica 页码戳。每页 `FPDFPage_GenerateContent` 后关闭 text_page/page。仅操作临时 dest 文档。
  - `Native/Pdfium.cs`：新增 `FPDF_PAGEOBJ_TEXT=1`，`FPDFPageObj_GetBounds(nint,float* left,float* bottom,float* right,float* top)`，`FPDFTextObj_GetText(nint,nint,ushort*,uint)` 返回 `uint`（本机 Win64 `unsigned long` = 32 位）。
  - `Dialogs/ExportPagesDialog.xaml(.cs)`：复选项改为「替换原有页码（PDF 按导出顺序标注 1..N）」+ ToolTip，属性注释同步。
- **原生实测（临时 console probe，验证后已删除）**：`FPDFPageObj_GetBounds` 用 `FS_RECTF*` 声明会 `AccessViolationException` 崩溃——真实签名是 4 个 `float*`；修正后 `GetBounds` 返回 1、包围盒正确。`FPDFTextObj_GetText` 对 `Page 4 of 29` 返回 26（字节数，含 NUL）；`FPDFText_SetText(obj," ")` 后重开页面读回为空（清空有效）；`FPDFText_SetText(obj,"1 / 4")` 后 `GenerateContent` + 重开页面读回 `[1 / 4]`（原位改写有效）；`FPDFPage_RemoveObject` 返回 1 且对象数归零（无需再 Destroy）。这些实测结论是本次实现签名与三级策略的依据。
- 验证：构建 0 错 0 警，lints 通过；待 GUI 复测（导出带原页脚页码的 PDF：旧页码消失，新页码按 1..N/M 出现在原位置且字体大小/颜色与原页码一致；无原页码文档仍会补新戳；取消勾选不改动页码）。
- 限制：页码位于 Form XObject 内部或纯图片页码无法识别改写，此时会按兜底逻辑在原位置/右下角添加新页码；表格底部形如 `5 / 10` 的孤立数字串存在被误判为页码短语的小概率。

## 2026-11-14 V1.2.119

**改版｜全文 AI 翻译：阅读式页面对照（译文版面同原文、图片页跳过）**

- 需求：全文 AI 翻译在文档阅读页面式视图中生成；译文页面与原文页面布局一致方便对照；图片类（无文字）页面无需翻译。
- 实现：
  - `Pdf/PdfDocument.cs`：新增嵌套记录 `PageTextBlock(Text, X0, Y0, X1, Y1)`（页面用户空间、y 向上）。新增 `GetPageTextBlocks(index)`：`FPDFText_CountChars` → 逐字符 `FPDFText_GetUnicode` + `FPDFText_GetCharBox`，按基线接近（≤max(1.5, h*0.45)）与水平推进正常聚成行，遇 `\r/\n` 断行；`AddTextLine` 用 `FPDFText_GetText(tp,start,cap,buf)` 抽行文本（segLen 按字符索引差计算，保证跳过的生成字符不错位）；行再按垂直间距（gap>0 且 ≤1.4×平均行高）与水平重叠（>0.2×行宽）合并段落块。复用既有 `GetPageSize(index)`（文件内原本已有，初次误加同名方法导致 CS0111，已删除）。
  - `Translation/FullDocTranslateWindow.cs`（整文件重写）：`BuildPagesAsync` 后台逐页 `GetPageTextBlocks` + `RenderPage(i,2.0,96,0)`（返回已 Freeze 的位图，可跨线程显示），UI 线程 `AddRow` 生成每页对照卡：左白底 Border+Image（原文页面渲染图）、右同尺寸白底 Border+Canvas（译文页面），`GetPageSize` 计算显示高度、坐标按 `x=X0*s`、`y=(pageH-Y1)*s` 转换并设 TextBlock 宽/字号；顶部标注第 N 页与翻译方向。
  - 图片页判定：页文本合计字符 <20 → `IsImagePage`，右栏显示「图片页 · 无需翻译」，翻译循环跳过、进度统计 skipped，复制译文跳过。
  - `TranslateRowAsync`：块以 `[n]` 编号组 prompt，system 要求逐块按同一编号输出、不合并拆分；`Progress<string>` 累加 `row.Raw`，`ApplyRow` 用 `ParseNumbered`（正则 `\[\s*(\d{1,3})\s*\]` 切片）把译文写回对应坐标块；无编号时回退整页文本放入首块。工具条保留 翻译全部/停止/复制译文/AI 设置/关闭；未配置时仅建页并给出引导。
  - 注意：译文页面按未旋转的用户空间坐标排版，左栏渲染也传 rotation=0，保证左右版面互为镜像一致；带 /Rotate 的文档在阅读页有旋转但对照窗口统一以未旋转版面展示。
- 构建期修复：① `PdfDocument.GetPageSize` 重复定义（CS0111）→ 删除新增副本复用原方法；② `FullDocTranslateWindow` 缺 `using System.Windows.Media.Imaging`（CS0246 BitmapSource）→ 补；③ `leftContent` 声明 `object` 不能赋给 `Border.Child`（CS0266）→ 改 `UIElement`。
- 验证：构建 0 错 0 警，lints 通过；待 GUI 复测（文字页左渲染图 + 右同版面逐块译文；纯图页显示无需翻译且不被调用；中/英方向正确；停止/复制/重新翻译可用）。

## 2026-11-14 V1.2.118

**改进｜导出页面：默认文件名 原名_export + 按导出顺序重新添加页码**

- 需求：① 导出 PDF 的另存对话框默认文件名取原文件名加 `_export`；② 去除导出页面原有页码、按导出顺序重新标注导出文档页码。
- 实现：
  - `Dialogs/ExportPagesDialog.xaml(.cs)`：构造函数新增 `string? sourcePath` 参数；`OnBrowse` 的 SaveFileDialog `FileName` 改为 `DefaultPdfName()`（`Path.GetFileNameWithoutExtension(源文件名)+"_export.pdf"`，无来源回退「导出页面.pdf」）；XAML 格式卡片新增 `CbNumbers`「重新添加页码（PDF 按导出顺序标注 1..N）」默认勾选，暴露 `AddPageNumbers` 属性；PNG/JPG 单选文案改为「按导出顺序编号」。
  - `Pdf/PdfDocument.cs`：`ExportPagesToPdf` 新增 `bool addPageNumbers = false`（默认参数，旧调用兼容），导入页成功后调用新增私有静态 `StampExportPageNumbers(dest, total)`：`FPDFText_LoadStandardFont(doc,"Helvetica")` → 逐页 `FPDF_LoadPage` → `FPDFPageObj_CreateTextObj(doc,font,10f)` → `FPDFText_SetText("N / M")` → `SetFillColor(0,0,0,255)` → `FPDFPageObj_Transform` 平移到右下角（x=w-16-len*5.6, y=16，宽度按 0.556em 数字字宽估算）→ `FPDFPage_InsertObject`+`FPDFPage_GenerateContent` → `FPDF_ClosePage`；对象创建失败/异常时 `FPDFPageObj_Destroy` 兜底，全部只作用于临时 dest 文档不触碰当前文档。`ExportPagesToImage` 改为按导出顺序重编文件名（`for k` 计数器，`page_{k+1:000}`，不再沿用原页码 `page_{i+1:000}`）。
  - `MainWindow.xaml.cs`：`OnExportPages` 传入 `new ExportPagesDialog(sel.Count, _doc.FilePath)` 并把 `dlg.AddPageNumbers` 传给 `ExportPagesToPdf`。
  - 无需新增 P/Invoke：所需 API 均已存在（`FPDFPageObj_Transform` 原生返回 void，历史声明为 int，按注释约定不检查其返回值）。
- 限制说明：原页面内容中已打印的页码是页面内容本身，pdfium 无法擦除；新页码戳与原页码独立并存（右下角 16pt 边距处，尽量避免遮挡常见页脚位置）。
- 验证：构建 0 错 0 警，lints 通过；待 GUI 复测（导出非连续多页 PDF：文件名 原名_export.pdf、每页右下角 1..N/M 页码戳、可正常打开；导出图片 page_001.. 按导出顺序；取消勾选页码项后导出无戳）。

## 2026-11-14 V1.2.117

**改版｜AI 文档分析：一键生成文档概要（全文档类型 + 中英双版 MD + 页面设置）**

- 需求：AI 分析不再限于规格书，支持所有可识别文字的文档，更换为一键生成文档概要；AI 自主生成 MD，支持中文版与英文版两种格式；截图页更名「AI 文档分析」，页面内增加概要分析设置；取消「AI 设置」按钮；重排页面布局。
- 实现（`Dialogs/AIAnalysisDialog.cs`）：
  - 标题：`AI 规格书分析`→`AI 文档分析`，`AI 规格书版本对比`→`AI 文档对比`；`AiMode` 注释同步。
  - 设置行（顶部新增）：`报告语言` ComboBox（自动（按文档语言）/ 中文 / English，默认自动）+ `分析深度` ComboBox（简明概要 / 标准分析 / 深入分析，默认标准），均套 Th.* 主题资源。
  - `BuildPrompts` 全面通用化：Single 模式为「文档概览 / 核心内容摘要 / 关键数据与术语 / 结论与建议 / 一句话总结」，声明文档类型不限；Compare 模式为「文档概览 / 关键内容对比表(要点|文档A|文档B|差异|简析) / 主要差异与改进 / 潜在回退风险 / 适用场景建议」。深度档位注入篇幅要求（Zh/En 两套 DepthHint）。
  - 新增 `IsEnglishOutput()`（English 恒真、中文恒假、自动按 `HasCjk` 判定抽取文字）与 `HasCjk`（CJK 表意/假名/谚文）。
  - `DefaultReportName()` 随语言命名：中文 `*_文档概要_*` / `*_对比_*_文档对比_*`，英文 `*_Document_Summary_*` / `*_vs_*_Document_Compare_*`（保留时间戳防覆盖）。
  - 布局重排：DockPanel 顶部 header → settingsRow → status，底部按钮组（一键生成 / 复制 / 保存为 .md / 关闭）；**移除 _settings 按钮及其 Click**；未配置提示改为引导「主菜单 工具 → AI 设置」。
  - 按钮文案：`重新生成`→`一键生成`；状态文案改「正在生成文档概要…/概要生成完成/生成失败」。
- 主菜单（`MainWindow.xaml.cs`）：「AI 分析当前文档…」→「AI 文档分析…」，ToolTip 更新；未打开文档提示标题同步「AI 文档分析」。
- 验证：构建 0 错 0 警，lints 通过；待 GUI 复测（打开任一类型 PDF → 工具菜单 AI 文档分析 → 自动生成概要；切换报告语言/深度后一键生成；保存 .md 文件名符合语言命名；页面无 AI 设置按钮）。
- 注意：FullDocTranslateWindow（全文 AI 翻译）中的 AI 设置按钮属于翻译功能，未受本次改动影响。

## 2026-11-14 V1.2.116

**新增｜全文 AI 翻译（侧栏页面菜单 + 文档右键菜单）**

- 需求：在 V1.2.115 基础上，于侧栏「页面」右键菜单与文档右键菜单均加入「全文 AI 翻译」，点击后按页分页显示当前文档，左原文右译文，英文→中文、中文→英文。
- 实现：
  - `Translation/FullDocTranslateWindow.cs`（新建）：Window 按 `PdfDocument.PageCount` 逐页抽文（`GetPageText`）生成「左原文/右译文」卡片，全部置于单一 ScrollViewer 内（左右同步滚动）。`HasCjk` 判定方向；`LlmClient.ChatAsync(system,user,ct,onDelta)` 逐页流式翻译并增量写入译文 TextBlock；工具条含 翻译全部/停止/复制译文/AI 设置/关闭；未配置时提示并可用 AI 设置。
  - `PdfPageView.cs`：新增 `event RoutedEventHandler? RequestTranslateFullDoc`；`AddDocContextItems` 末尾「AI」分组新增「全文 AI 翻译」项（带地球图标）触发该事件。
  - `MainWindow.xaml`：ThumbList ContextMenu 在「去除文档保护」后新增「全文 AI 翻译」(`Click="OnTranslateFullDoc"`)。
  - `MainWindow.xaml.cs`：`RealizePage` 订阅 `pv.RequestTranslateFullDoc += OnTranslateFullDoc`，`UnrealizePage` 取消订阅；新增 `OnTranslateFullDoc(sender,e)` 打开 `FullDocTranslateWindow(_doc, _active.FilePath, this)`（侧栏菜单 Click 与页面事件共用此处理器）。
  - 命名空间：FullDocTranslateWindow 在 `PdfReader.Translation`，需 `using PdfReader.Dialogs`（AiSettingsDialog）、`PdfReader.LLM`、`PdfReader.Pdf`；MainWindow 加 `using PdfReader.Translation`。
- 验证：构建 0 错 0 警，lints 通过；待 GUI 复测（配置模型后，对中/英文 PDF 右键「全文 AI 翻译」→ 左原文右译文逐页流式显示，方向正确，复制译文可用）。
- 注意：翻译依赖用户在「AI 设置」中配置的模型/Key（本地 Ollama 免 Key）；未配置时窗口给出引导而非报错。

## 2026-11-14 V1.2.115

**新增｜侧栏「页面」右键菜单：去除文档保护**

- 需求：在 V1.2.114 侧栏「页面」右键菜单基础上增加「去除文档保护」项，解除 PDF 加密/权限限制并另存为未保护文件。
- 实现：
  - `Native/Pdfium.cs`：新增 `FPDF_GetDocPermissions`/`FPDF_GetSecurityHandlerRevision` P/Invoke 与 `FPDF_REMOVE_SECURITY = 0x03` 常量。
  - `Pdf/PdfDocument.cs`：`SaveDocHandle` 增加 `int flags` 参数并透传给 `FPDF_SaveAsCopy`（导出页沿用 `0`）；新增 `IsEncrypted`（`FPDF_GetSecurityHandlerRevision(_doc) > 0`）、`Permissions`（`FPDF_GetDocPermissions`）、`RemoveProtection(path)`（以 `FPDF_REMOVE_SECURITY` 标志另存未保护 PDF）。
  - `MainWindow.xaml`：右键菜单新增「去除文档保护」（`x:Name="MiRemoveProtection"`），菜单 `Opened="OnThumbMenuOpened"` 按 `_doc.IsEncrypted` 控制该项可用态。
  - `MainWindow.xaml.cs`：新增 `OnThumbMenuOpened`（置灰/可用）与 `OnRemoveProtection`（未加密提示 / 确认 / SaveFileDialog 默认 `原名_已解除保护.pdf` / 调 `RemoveProtection` 并提示结果）。
- 验证：构建 0 错 0 警，lints 通过；待 GUI 复测（对加密 PDF 右键「去除文档保护」→ 另存无密码副本，可正常打开且权限限制消失）。
- 注意：去除保护需文档已被加载（打开时密码已提供）；仅输入用户密码但无所有者密码的强限制文档，pdfium 可能仍拒绝对应的权限变更，失败会弹错误提示。

## 2026-11-14 V1.2.114

**新增｜侧栏「页面」缩略图右键菜单（旋转/删除/导出/属性，Ctrl/Shift 多选）**

- 需求：侧栏「页面」标签右键任一缩略图弹出菜单：顺时针/逆时针旋转页面、删除页面、导出页面（PDF/图片格式，支持 Ctrl/Shift 多选）、页面属性。
- 实现：
  - `MainWindow.xaml`：`ThumbList` 由 `SelectionMode="Single"` 改为 `Extended`，挂 `PreviewMouseRightButtonDown="OnThumbRightDown"` 与 `ListBox.ContextMenu`（5 项）。`OnThumbRightDown` 据 Ctrl/Shift 修饰键维护多选（保持既有多选以便整组操作）。
  - `MainWindow.xaml.cs` 新增 `SelectedPageIndices()`（收集多选 0-based 升序）、`RefreshThumb(i)`（重渲染单页缩略图）、`RotateSelectedPages(±1)`、`OnDeletePages`、`RebuildAfterPageChange()`（释放并重置页视图/页尺寸/缩略图缓存/列表/版面）、`OnExportPages`（调 ExportPagesDialog）、`OnPageProperties`（调 PagePropertiesDialog）。旋转/删除后 `_doc.IsModified=true` + `RefreshSaveButton()`。
  - 文档级旋转：`PdfPageView` 引入 `EffectiveRotation = (视图旋转 + 文档旋转) % 4`，用于 `ViewSize`/坐标映射/渲染；`RefreshDocRotation()` 重新度量并强制重渲染。`LayoutSizes(DocTab)` 改为逐页按有效旋转互换横纵。`RenderThumbAsync` 渲染叠加 `doc.GetPageRotation(i)`。
  - `PdfDocument`：`GetPageRotation`/`SetPageRotation`（缓存 `_pageRotations`，`RetireCurrent`/结构变更时清空）、`DeletePages`（降序删除 + `InvalidatePageHandles` 失效所有页句柄缓存）、`ExportPagesToPdf`（FPDF_CreateNewDocument + FPDF_ImportPages + 复用 WriteBlockProc 的 `SaveDocHandle`）、`ExportPagesToImage`（按 DPI 渲染 PNG/JPG）。
  - `Native/Pdfium.cs` 新增 `FPDFPage_GetRotation`/`SetRotation`/`Delete`/`CreateNewDocument`/`ImportPages` P/Invoke。
  - 新增对话框 `ExportPagesDialog`（格式单选 + 路径浏览，图片取所选文件夹）、`PagePropertiesDialog`（页码/尺寸 mm/旋转只读）。
- 验证：构建 0 错 0 警，lints 通过；待 GUI 复测（多选右键、旋转后版面/缩略图、删除重建、导出 PDF/图片、属性显示、保存持久化）。

## 2026-11-14 V1.2.113

**优化｜添加水印对话框同步页眉/页脚的分组卡片风格（消除 GroupBox 重影）**

- 用户要求：水印添加对话框与页眉/页脚对话框「相同问题同步修复」。V1.2.111 仅把页眉/页脚的三分组改为卡片，水印对话框仍用默认 GroupBox（深色主题下双框重影，风格不统一）。
- 修复（`Dialogs/WatermarkDialog.xaml`）：加入与页眉/页脚相同的窗口资源 `SectionBorder`/`SectionTitle`；来源/外观/位置/预览四个 `<GroupBox>` 全部替换为卡片 `Border`（内加粗标题 TextBlock）。注意闭合标签需配套：开标签处用外层 `StackPanel` 包裹标题+原内容，闭合处 `</StackPanel></Border>` 配对，避免多/少一层导致 MC3000 标签不匹配（构建期已验证）。
- 验证：构建 0 错 0 警；待 GUI 复测两对话框风格一致。

## 2026-11-14 V1.2.112

**修复｜添加页眉/页脚对话框点「页面范围选项(G)...」卡死后崩溃；弹窗风格不搭**

- 用户实测（截图）：点「页面范围选项(G)...」崩溃；「外观选项」弹出的 `MessageBox` 为浅色系统样式，与暗色主题不搭。
- 崩溃根因：`OnRangeMenu` 中 `menu.PlacementTarget = (UIElement)sender;`——事件 sender 是 `Hyperlink`（继承链 `Hyperlink → Span → Inline → TextElement → FrameworkContentElement`），**不是 UIElement**，强转抛 `InvalidCastException` → 未处理 → 崩溃。水印对话框 `OnRangeMenu` 是同一段代码，同样会崩（此前未点到）。
- 修复：两个 XAML 给链接宿主 `TextBlock` 加 `x:Name="RangeAnchor"`，`menu.PlacementTarget = RangeAnchor`。
- 风格统一：`WatermarkDialog.xaml.cs` 6 处、`HeaderFooterDialog.xaml.cs` 4 处 `MessageBox.Show(this,` → `Msg.Show(this,`（统一主题弹窗 `Dialogs/MessageDialog.cs` 的 `Msg` 入口）。
- 验证：构建 0 错 0 警，lints 通过；待 GUI 复测（点页面范围选项弹出菜单、选自定义范围弹主题输入框；外观选项/帮助弹窗为暗色主题）。

## 2026-11-14 V1.2.111

**优化｜添加页眉/页脚对话框：分组框重影 + 字体/页边距不等宽**

- 用户反馈（截图）：三个 GroupBox 有双框重影；字体框与页边距框宽度不一致。
- 根因：App 未定义 GroupBox 样式，默认 Aero 模板在深色主题下自带浅色硬编码边框，与主题边框叠加形成「重影」；外层 Grid 两列为 `*`/`Auto`，页边距按内容收缩故窄于字体框。
- 修复（`Dialogs/HeaderFooterDialog.xaml`）：参照 PreferencesDialog 的分组风格（`Th.PanelBg` + `Th.Border` + `CornerRadius=6` Border + 加粗标题 TextBlock），新增窗口资源 `SectionBorder`/`SectionTitle` 两个样式；字体/页边距/预览三处 GroupBox 全部替换为卡片 Border；外层两列均改 `*` 等宽。控件 x:Name 与事件保持不变。
- 验证：构建 0 错 0 警，lints 通过；待 GUI 复测。备注：添加水印对话框仍用 GroupBox（同样可能有重影），如确认可按同方案统一。

## 2026-11-14 V1.2.110

**优化｜添加页眉/页脚对话框布局调整（预览右置）**

- 用户反馈：原布局预览全宽置底且渲染宽 520px，纵向 A4 页面预览高约 730px，窗口 `SizeToContent=Height` 总高超出屏幕，底部按钮（帮助/确定/应用到多个文件/取消）被任务栏遮挡。
- 调整（`Dialogs/HeaderFooterDialog.xaml`）：顶层 Grid 两栏（`*` + 14 + 380）——左列依次为 字体 GroupBox 与 页边距 GroupBox（同一行）、六个槽位文本框（3 列 2 行）、插入页码/日期按钮行；右列为预览 GroupBox（第一行 预览页面(E) spin + "/ N" 与 RangeLabel/页面范围选项链接两端对齐，下方 Border+Grid(PreviewHost) 内 PreviewImg + PreviewOverlay Canvas）。
- 代码同步：`RefreshPreview` 渲染宽度 520 → 360；控件 x:Name 与事件全部保留，行为不变。
- 验证：构建 0 错 0 警，lints 通过；待 GUI 复测窗口高度与底部按钮可见性。

## 2026-11-14 V1.2.109

**修复｜点「添加水印…」程序无响应后崩溃（页眉/页脚对话框同样受影响）**

- 用户实测：打开 PDF（NCx57100-D.PDF，缩放 248%）后点 拓展 ▸ 水印 ▸ 添加水印…，程序短暂无响应随后崩溃退出。
- 根因（WPF XAML 解析期事件时序）：`InitializeComponent()` 解析 XAML 时初始属性即触发事件——`WatermarkDialog.xaml` 中 `TextValue Text="机密文件" TextChanged="OnSettingChanged"`（解析到该行时 `OpBox`（第 100 行）与 `_doc` 均未就绪 → `OnSettingChanged` 内 `OpBox.Text=` 抛 NRE）、`SrcText IsChecked="True" Checked="OnSourceChanged"`（`TextValue`（第 45 行）尚未解析 → NRE）、`FilePathBox Text="&lt;…&gt;"`、`SizeBox Text="24"`、`PageNumBox Text="0"`、`AbsScaleBox/OpBox/RelScaleBox/VertDistBox/HorzDistBox/AngleBox Text` 同理；`HeaderFooterDialog.xaml` 中 `MarginTop/Bottom/Left/RightBox Text="1.27/2.54"` + `SizeBox Text="8"` 触发 `OnSettingChanged → RefreshPreview → _doc.GetPageSizeOf` NRE。构造函数原在 `InitializeComponent()` 之后才 `_updating = true`，解析期事件未被抑制 → 异常沿 `new WatermarkDialog(...)` 上抛 → 未处理 → 崩溃。
- 修复：两对话框构造函数把 `_updating = true` 提前到 `InitializeComponent()` 之前；`OnSettingChanged/OnSourceChanged/OnRotChanged/OnAlignClick/OnPreviewPageChanged` 增加 `_doc is null` 守卫。运行期事件逻辑不变（_updating 仅在构造期与程序赋值时为 true）。
- 验证：构建 0 错 0 警；待 GUI 复测（打开 PDF → 添加水印对话框正常出现、预览显示「机密文件」默认水印；添加页眉/页脚对话框正常出现）。

## 2026-11-14 V1.2.108

**新增｜拓展 ▸ 页眉/页脚（添加 / 删除）+ 添加页眉和页脚对话框（仿 PDF-XChange 版式）**

- 菜单：`MainWindow.BuildExtendedToolsMenu()` 水印组后新增「页眉/页脚」父项（双横条图标 `M4,5 H20 V9 H4 Z M4,15 H20 V19 H4 Z`）+「添加页眉/页脚…」「删除页眉/页脚」子项；处理器 `OnAddHeaderFooter` / `OnRemoveHeaderFooter`（与水印处理器同模式：无文档提示 → ShowDialog → BeginUiBatch 逐项写入 → ViewAt 重渲染 + OnAnnotChanged + 状态栏）。
- 对话框：`Dialogs/HeaderFooterDialog.xaml(.cs)`，宽 980、`SizeToContent=Height`、`CenterOwner`，主题 `SourceInitialized += (_,_) => ThemeManager.ApplyTitleBar(this)`；版式对照 PDF-XChange：保存的设置（AppPrefs.HeaderFooterPresets，复用 WatermarkPreset 类）、字体组（FontCatalog、字号默认 8、U=下划线 TextDecorations.Underline、色板 Popup）、页边距组（上/下 1.27、左/右 2.54 厘米）、六个槽位文本框（页眉/页脚 × 左/中/右）、插入页码/日期按钮（插入 %p/%d 到最近聚焦文本框光标处）、页码和日期格式（TextInputDialog 两步：PageFmt 含 %p/%P、DateFmt 为 .NET 格式串）、预览（页面渲染 520px 宽 + Canvas 逐槽位叠加）、页面范围选项（全部/当前页/自定义 `1-3,7`）。
- 宏展开 `ExpandText`：`%p` → PageFmt 渲染的页号、`%P` → 总页数、`%d` → DateTime.Now.ToString(DateFmt)。
- 定位 `SlotRect`：页眉文本顶边 = 上边距（cm×28.3465pt）、页脚文本底边 = 页高 - 下边距 - 文本高；水平：左槽 = 左边距、右槽 = 页宽 - 右边距 - 文本宽、中槽 = 居中；Clamp 页内。
- 渲染 `RenderSlotBitmap`：FormattedText 测宽 → TextBlock（可 Underline）Measure/Arrange → DrawingVisual+VisualBrush → RenderTargetBitmap 96dpi Pbgra32 冻结；位图→点 ×72/96。
- PdfDocument：泛化 `AddMarkedStamp(pageIndex,rect,bmp,key)` / `RemoveMarked(key)` / `RemoveMarkedOf(pageIndex,key)`；`AddWatermark`/`RemoveWatermarks` 保持原签名改为薄封装；新增 `HeaderFooterKey="PdfReaderHeaderFooter"`、`AddHeaderFooter`、`RemoveHeaderFooters`。删除与水印互不影响（按各自标记键识别）。
- 验证：待应用内 GUI 实测（构建 0 错 0 警，lints 通过）。

## 2026-11-14 V1.2.107

**新增｜拓展 ▸ 水印（添加 / 删除）+ 添加水印对话框（仿 PDF-XChange 版式）**

- 菜单：`MainWindow.BuildExtendedToolsMenu()` 末尾新增「水印」父项（水滴图标）+「添加水印…」「删除水印」子项。
- 对话框：`Dialogs/WatermarkDialog.xaml(.cs)`，宽 920、`SizeToContent=Height`、`CenterOwner`，主题 `SourceInitialized += (_,_) => ThemeManager.ApplyTitleBar(this)`；版式对照 PDF-XChange：保存的设置（AppPrefs.WatermarkPresets，Name+设置 JSON，`JsonSerializer` 序列化 `WatermarkSettings`）、页面范围选项（Hyperlink + ContextMenu，全部/当前页/自定义 `1-3,7`）、来源（文本：字体走 `FontCatalog.All`、字号可编辑下拉、T=加粗、色板 Popup 16 预设色、三态对齐互斥 ToggleButton；文件：OpenFileDialog + 绝对比例）、外观（旋转四选一 + 自定义角度、Slider 不透明度与输入框联动、相对页宽比例、图层位置）、位置（垂直/水平距离 + 单位 cm/mm/in/pt（1cm=28.3465pt）+ 垂直锚 顶部/中心/底部 × 水平锚 左/中心/右）、预览（`doc.RenderPage(idx, 300/pageW)` + `PreviewOverlay` Canvas 按点位影像素比叠加水印位图）。
- 渲染：`RenderWatermarkBitmap` —— 文本用 `FormattedText` 逐行测宽（%p 按 `PageNumStart>0 ? start+idx : idx+1` 替换），TextBlock 宽高精确后 `Measure/Arrange`；图片按绝对比例；相对页宽比例按每页页宽缩放；旋转画外接框（|cos|/|sin| 组合），`DrawingVisual` PushTranslate(中心)→PushRotate→PushOpacity→DrawRectangle(VisualBrush)，`RenderTargetBitmap(96dpi, Pbgra32)` 冻结；外接框限 64M 像素。定位 `ComputeRect`：锚点 + 距离 → 中心，`Clamp` 在页面内；矩形/位图尺寸统一 96dpi→点（×72/96）。
- 写入：`PdfDocument.AddWatermark` = 复用 `AddStamp`（stamp 注释 + `FPDFImageObj_SetBitmap` 透明位图，`_stampUi` 叠加缓存生效）后对末位注释 `FPDFAnnot_SetStringValue(WatermarkKey="PdfReaderWatermark","1")` 标记；`RemoveWatermarks/RemoveWatermarksOf` 全页扫描 STAMP 子类型 + 标记键命中后倒序走现成 `DeleteAnnot`（含 `_stampUi` 按 Rect 匹配清理），不影响用户原有图章。
- MainWindow：`OnAddWatermark`（无文档提示 → `WatermarkDialog(_doc, PageCount, cur).ShowDialog()` → `BeginUiBatch` 逐页 `AddWatermark` → 逐页 `ViewAt(p)?.RenderAsync()` + `OnAnnotChanged(cur)` + 状态栏计数）；`OnRemoveWatermark`（`RemoveWatermarks()` → 0 个提示、`RealizedViews` 全部重渲染）。「应用到多个文件」按钮按截图保留但禁用（ToolTip 说明当前版本不支持批量文件）。
- 已知边界：图层位置两项效果相同（stamp 注释恒在上层，界面 ToolTip 已注明）；水印为注释而非页面内容流，删除依赖标记键（跨会话仍有效——标记随注释保存在 PDF 内）。
- 验证：待应用内 GUI 实测（构建 0 错 0 警，lints 通过）。

## 2026-11-14 V1.2.106

**改进｜「查找文本」文字字体改成和「适应宽度」一样大**

- 背景：V1.2.105 把搜索按钮放大到 1.2× 后，文字 `FontSize=14.4`，比工具栏「适应宽度」缩放下拉框的文字显得更大，视觉不统一。
- 改动：`MainWindow.xaml` 的 `SearchBtn` 内 TextBlock（查找文本）`FontSize` 14.4 → 12。「适应宽度」位于 `ZoomBox`（全局 ComboBox 样式未设 `FontSize`，走 WPF 默认 `SystemFonts.MessageFontSize`=12px），两者现一致。按钮外框尺寸与放大镜图标不变。
- 验证：待应用内 GUI 实测（构建 0 错 0 警，lints 通过）。

## 2026-11-14 V1.2.105

**改进｜查找按钮与自由画笔钢笔指针均放大 1.2×**

- 背景：V1.2.103 把搜索按钮缩到 0.85×、V1.2.104 把指针改成钢笔形状；用户要求「指针和按钮都增大 1.2×」。
- 改动：
  - 查找按钮（`MainWindow.xaml` 的 `SearchBtn`）：高 23.8→33.6、最小宽 90.1→127.2、内边距 "10.2,0,8.5,0"→"14.4,0,12,0"；「查找文本」FontSize 10.2→14.4、Margin "0,0,8.5,0"→"0,0,12,0"；放大镜 Path 11.9→16.8、StrokeThickness 1.1→1.56 —— 恢复到原始尺寸 1.2×（与工具栏图标 1.2× 匹配）。
  - 自由画笔指针（`PdfPageView._inkCursor`）：`RenderTransform` 由单 `RotateTransform(45)` 改为 `TransformGroup{ ScaleTransform(1.2,1.2), RotateTransform(45) }`，钢笔轮廓整体放大 1.2×；缩放与旋转中心均为局部 (0,0)=笔尖，热点不变，`SyncInkCursor` 仍把笔尖对齐鼠标。
- 验证：待应用内 GUI 实测（构建 0 错 0 警，lints 通过）。

## 2026-11-14 V1.2.104

**修正｜自由画笔指针形状改为钢笔（铅笔）而非标准箭头**

- 背景：V1.2.102 用经典箭头轮廓 `M0,0 L0,16 L4,12 L7,18 L9,17 L6,11 L11,11 Z` 作指针，用户反馈颜色已对，但形状是标准箭头，不是钢笔指针。
- 改动：`PdfPageView._inkCursor` 的 `Data` 改为铅笔/钢笔轮廓 `M0,0 L-4,-7 L-4,-19 L-4,-22 L4,-22 L4,-19 L4,-7 Z`（笔尖在 (0,0) 为热点，笔身向上），并加 `RenderTransform = new RotateTransform(45)`，使笔身指向右上、笔尖在左下，模拟系统钢笔指针朝向；`Fill=ToolColor`、`Stroke` 半透明黑、`StrokeThickness=1.2`、`StrokeLineJoin=Round`、`IsHitTestVisible=false`。`SyncInkCursor` 仍把笔尖 (0,0) 对齐鼠标位置、隐藏系统光标。热点经旋转后仍固定在鼠标处（旋转中心为局部 (0,0) = 笔尖）。
- 验证：待应用内 GUI 实测（构建 0 错 0 警，lints 通过）。

## 2026-11-14 V1.2.103

**改进｜搜索按钮（含文字）缩小到 0.85×**

- 背景：V1.2.098 把搜索按钮整体放大到 1.2× 以匹配工具栏图标；用户现要求把搜索按钮与文字缩到 0.85×。
- 改动：`MainWindow.xaml` 的 `SearchBtn`：高 33.6→23.8、最小宽 127.2→90.1、内边距 "14.4,0,12,0"→"10.2,0,8.5,0"；「查找文本」TextBlock `FontSize` 14.4→10.2、`Margin` "0,0,12,0"→"0,0,8.5,0"；放大镜 Path 16.8→11.9、`StrokeThickness` 1.56→1.1。缩放基准为原始默认尺寸（28/106/12/14/1.3）的 0.85×，即比默认更小巧；工具栏 `ToolButton`/`ActionButton`/`ToolIcon` 的 1.2× 不动。
- 验证：待应用内 GUI 实测（构建 0 错 0 警，lints 通过）。

## 2026-11-14 V1.2.102

**修正｜自由画笔指针本身改为画笔色（不再只是圆点 + 红色光标）**

- 背景：V1.2.101 保留系统钢笔光标（红色）并在其旁叠加彩色圆点；用户反馈圆点能显示画笔色，但指针仍是红色，希望指针本身也是画笔色。系统光标无法直接改色。
- 改动：`PdfPageView._inkCursor` 由 `Ellipse`（圆点）改为 `Path`（经典箭头轮廓 `M0,0 L0,16 L4,12 L7,18 L9,17 L6,11 L11,11 Z`，热点=左上尖角 0,0，`Stretch=None`，`Fill=ToolColor`，半透明黑描边+圆角连接保证任意背景可见）。`SyncInkCursor` 改为把箭头 `Fill` 设为 `ToolColor`、`Canvas.SetLeft/Top` 对齐鼠标位置（尖角即热点）、`Cursor=Cursors.None`（隐藏红色系统光标）；去掉此前按笔宽换算直径的逻辑。`HideInkCursor` 维持隐藏并复位 `Cursors.Arrow`。`OnMouseMove` 顶部调用不变。
- 细节：箭头随鼠标实时重取 `ToolColor`，切换画笔色下一帧即变色；拖拽绘制期间（CaptureMouse）箭头仍跟随，落笔点=箭头尖角，与即将画出的笔画起点一致。
- 验证：待应用内 GUI 实测（构建 0 错 0 警，lints 通过）。

## 2026-11-14 V1.2.101

**修正｜自由画笔指针被隐藏只剩圆点**

- 背景：V1.2.099 为让指针颜色匹配画笔，将 `SyncInkCursor` 里设为 `Cursor = Cursors.None` 并只显示彩色圆点，导致鼠标指针（钢笔形状）消失，用户反馈「画笔指针没有了，只剩下个点」。
- 改动：`PdfPageView.SyncInkCursor` 改为 `Cursor = Cursors.Pen`（保留系统钢笔指针），彩色 `Ellipse` 仍叠加在鼠标位置作颜色/粗细指示；`HideInkCursor` 去掉只对 None 的复位判断，统一 `Cursor = Cursors.Arrow` 复位。Ink 分支 `OnMouseMove` 维持不重设光标（由 SyncInkCursor 统一处理）。
- 验证：待应用内 GUI 实测（构建 0 错 0 警，lints 通过）。

## 2026-11-14 V1.2.100

**改进｜无搜索历史时禁用历史按钮**

- 背景：查找栏的历史按钮（`SearchHistBtn`，时钟图标）在任何时候都可点击，但无历史时点开只有「暂无历史」空态，属于无效交互。
- 改动：`MainWindow.xaml.cs` 新增 `UpdateSearchHistEnabled()`（`SearchHistBtn.IsEnabled = _searchHistory.Count > 0`），在三处调用——构造函数绑定 `SearchHistList.ItemsSource` 之后（启动初始禁用）、`AddSearchHistory()` 末尾（有历史即启用）、`OnSearchHistClear()` 清空后（重新禁用）。禁用态视觉复用 `App.xaml` `ActionButton` 样式已有的 `IsEnabled=False → Opacity 0.35` 触发器，无需新增样式。
- 细节：`OnSearchHistClick` 里原有的 `if (_searchHistory.Count == 0) return;` 兜底保留（禁用态按钮 Click 本就不会触发，双保险）；弹层内「清除」按钮不受影响。
- 验证：待应用内 GUI 实测（构建 0 错 0 警，lints 通过）。

## 2026-11-14 V1.2.099

**改进｜自由画笔指针颜色跟随当前画笔颜色**

- 背景：V1.2.099 之前，自由画笔（ToolMode.Ink）在文档上移动时用系统 `Cursors.Pen`（固定色），与用户当前画笔色（`InkStrokeColor` / `ToolColor`）不一致，用户看不到"会用哪种颜色画"。
- 改动：`PdfPageView` 构造时在 `_overlay` 加入 `IsHitTestVisible=false` 的 `Ellipse _inkCursor`（半透明黑色描边、初始 Collapsed）；新增 `SyncInkCursor(Point)` 与 `HideInkCursor()`。`OnMouseMove` 顶部调用 `SyncInkCursor(e.GetPosition(this))`——当 `Tool==Ink`：按 `_image.ActualWidth/_pageW` 把 `AppPrefs.Current.ShapeStrokeWidth` 换算成屏幕像素直径（下限 4px），`Fill` 设为 `ToolColor`（颜色解析走 `ColorResolver`，与落笔同色），定位到鼠标、`Visibility=Visible`、`Cursor=Cursors.None`（用彩色圆点代替系统箭头/钢笔光标）；非 Ink 或鼠标离开页面（`MouseLeave` 新增 `HideInkCursor`）则收起圆点，并在曾隐藏系统光标时复位 `Cursor=Arrow`，避免指针消失。`Tool` 属性切离 Ink 时也调用 `HideInkCursor`。
- 细节：圆点绘制在 `_overlay`（与标注预览同坐标系，鼠标坐标 `e.GetPosition(this)` 即可定位）；切换画笔颜色后下一帧 `MouseMove` 实时重取 `ToolColor`，无需额外刷新；拖拽绘制期间（`CaptureMouse`）圆点仍跟随，颜色和粗细与即将落下的笔画一致。
- 验证：待应用内 GUI 实测（构建 0 错 0 警，lints 通过）。

## 2026-11-14 V1.2.098

**改进｜工具栏「查找文本」搜索按钮与文字同步放大 1.2×**

- 背景：V1.2.096 只放大了工具栏左侧图标（`ToolButton`/`ActionButton`/`ToolIcon`），右上角「查找文本」搜索按钮是独立模板（自带 Height/MinWidth/Padding、内嵌 TextBlock 与放大镜 Path），未随之变大，视觉上比例失衡。
- 改动：`MainWindow.xaml` 中 `SearchBtn`：`Height` 28 → 33.6、`MinWidth` 106 → 127.2、`Padding` "12,0,10,0" → "14.4,0,12,0"；内部 `TextBlock`（查找文本）`FontSize` 12 → 14.4、`Margin` "0,0,10,0" → "0,0,12,0"；放大镜 `Path` `Width`/`Height` 14 → 16.8、`StrokeThickness` 1.3 → 1.56，全部精确 1.2×。
- 细节：按钮 33.6 低于工具栏左侧图标按钮的 34，工具栏行高不变；`SearchBtnHost` 为 `VerticalAlignment=Center`，居中不受影响。
- 验证：待应用内 GUI 实测（构建 0 错 0 警，lints 通过）。

## 2026-11-14 V1.2.097

**改进｜Ctrl+F 打开查找栏自动带入页面上选中的文本**

- 背景：用户双击/拖选文本后按 Ctrl+F，查找栏是空的，还要手动复制粘贴。
- 改动：`PdfPageView` 新增 `public string? GetSelectedText()`（`OrderedSelection()` 取选中区间，`Document.GetText(PageIndex, start, count)` 包在 `PdfDocument.BeginUiBatch()` 里，异常/无选中返回 null，与 `CopySelection` 同链路）；`MainWindow.OpenSearchBar()` 在 `SearchBox.Focus()` 后、`SelectAll()` 前，用 `RealizedViews.FirstOrDefault(p => p.HasSelectionRects)?.GetSelectedText()` 取选中文本，非空则 `SearchBox.Text = sel.Trim()`——Ctrl+F 与工具栏查找按钮共用该入口，行为一致；随后 `SelectAll()` 全选带入的文本，直接输入即覆盖。
- 细节：高级搜索结果定位（`OnAdvResultSelected`）也走 `OpenSearchBar()`，但它在调用后显式覆写 `SearchBox.Text`，不受带入逻辑影响。无选中时不改动输入框内容（保留上次输入）。
- 验证：待应用内 GUI 实测（构建 0 错 0 警，lints 通过）。

## 2026-11-14 V1.2.096

**改进｜工具栏图标放大 1.2×**

- 改动：`App.xaml` 中 `ToolButton` / `ActionButton` 的 `FontSize` 由 16 → 19.2（Segoe MDL2 字形图标，正好 1.2×）；`MainWindow.xaml` 的 `ToolIcon` 矢量图标 `Width`/`Height` 14.4 → 17.28、`StrokeThickness` 1.8 → 2.16（保持线宽比例）。按钮外框 34×34 与工具栏高度不变，仅图标内容放大，避免裁切。
- 范围：仅作用于顶部工具栏图标。`ToolIconFill`（侧栏大纲开关，非工具栏）与菜单图标（`MenuIcon`/`MenuIconFill`）未改动；查找栏内带显式 `FontSize` 的按钮（如搜索历史按钮 `FontSize=14`）不受全局样式影响，保持原尺寸。
- 验证：待应用内 GUI 实测（构建 0 错 0 警，lints 通过）。

## 2026-11-14 V1.2.095

**改进｜查找栏增加仅内存的搜索历史（用户诉求：软件关闭后清除）**

- 背景：查找栏 `SearchBox` 此前无历史记录；`AppPrefs` 里只有 `MaxRecentFiles` / `RecentFiles` 用于最近文件，没有搜索历史字段。
- 方案：在 `MainWindow` 新增实例级 `ObservableCollection<string> _searchHistory`（上限 20），**不写入任何持久化字段**。在真正执行搜索的 `RunSearch()` 里，过滤掉空串后对 `q` 去重（已存在则先移除再插到最前）、限长；列表绑定到 `SearchBar` 内新增的 `SearchHistList`（WPF `ListBox`）。
- UI：`MainWindow.xaml` 的 `SearchBar` DockPanel 内新增 `SearchHistBtn`（Segoe MDL2 `E81C` 历史图标，Dock=Left），点击打开 `SearchHistPopup`（仿照既有 `ColorPopup` 的 `Th.PopupBg`/`Th.Border`/`Th.PopupText` 风格，`StaysOpen=False` 点击外部自动关闭）。弹层含标题、右侧「清除」按钮、空态提示 `SearchHistEmpty` 与 `SearchHistList`。点击列表项 → 回填 `SearchBox.Text` 并 `EnsureSearchResults()`、聚焦全选；`OnSearchHistSelectionChanged` 里先把 `SelectedIndex` 复位为 -1 以便重复点同一项，再关闭弹层。
- 验证：待应用内 GUI 端到端实测（构建 0 错 0 警，lints 通过）。

## 2026-11-13 V1.2.094

**改进｜文档标签切换动画改为视图从中间绽开（用户二选一确认：只改标签切换，跳页保留卷角）**

- 背景：`ActivateTab` 原有 `BeginDocCrossFade(AnimKey.DocSwitch)` 走 `LayoutAnim.Fade(DocOverlay, 1→0)` 整层淡出；同一方法还被 `TransitionDocument`（版面变更）复用，不能直接改掉方法语义。
- 改动：`BeginDocCrossFade` 加 `bool bloom` 参数，两条揭示路径共用「抓旧视口快照 → 不透明盖住 DocOverlay」前置；`bloom=true` 时给 `DocOverlay.OpacityMask` 挂 `RadialGradientBrush`（中心 Transparent、外围 Black），返回动作里对两个 `GradientStop.Offset` 用同一曲线做 `DoubleAnimation`，透明区从中心扩张 → 新视图从中间绽开。`ActivateTab` 传 `bloom: true`，`TransitionDocument` 保持淡出。新增 `_bloomMask` 字段，`ResetDocCrossFade` / `Cleanup` 里停掉色标动画时钟并清 `OpacityMask`，避免连续切换残留。
- 坑（离线渲染实测发现）：第一版 `RadiusX/Y=0.75`、`inner` 终点 0.86 时，矩形四角的归一化半径约 0.943 大于 0.86，终点帧四角仍有旧快照残留，撤遮罩瞬间会「四角闪一下」。改 `RadiusX/Y=0.8`（角落半径 ≈0.884）、`inner` 终点 0.90、`outer` 0.15→1.0，透明区终点越过四角，且渐变带全程保持 0.10~0.15 宽度（边缘始终柔和）。
- 验证：PowerShell STA + 真实 WPF `RenderTargetBitmap` 离线渲染中间帧（0.45 / 0.575）与终点帧（0.90 / 1.0）：中间帧为中心蓝色椭圆绽开、外围旧快照红色、柔和过渡；终点帧整屏纯蓝无角残留。探针已删。
- 经验：径向遮罩做 reveal 时，别只按「圆的半径」估算覆盖范围——矩形四角比边远，必须让透明区终点 offset 大于四角的归一化半径，否则收尾会跳。

## 2026-11-13 V1.2.093

**改进｜翻页动画改为文档页面左上角页角卷起（用户诉求）**

- 背景：`AnimateScrollTo → SlideToOffset → SetSlideProgress` 原本把当前页 / 目标页两张视口快照首尾相接做整屏水平推拉（`TranslateTransform` + 1 设备像素重叠 + 接缝线 + 抛物线压暗）。用户要改成页角卷起。
- 方案：WPF 无内置 page-curl shader，用 2D 折角近似。`MainWindow.xaml` 的 `PageSlideLayer` 重排为：底层 `PageSlideNew`（目标页，静止）、上层 `PageSlideOld`（当前页，`Clip` 挖掉左上角三角形）、`PageSlideCurlHost`（无变换的父 Grid，裁到折起三角形）+ 内层 `PageSlideCurl`（Image 做镜像）、`PageSlideShade`（折痕阴影）；旧推拉用的 Dim/Edge 隐藏。
- 几何：折痕为直线 x+y=r，r=(w+h)·p。T={(0,0),(r,0),(0,r)} 为被卷起区域，关于折痕反射 (x,y)→(r-y,r-x) 得到 T'={(r,0),(0,r),(r,r)} 即纸背落点。`PageSlideOld.Clip = CombinedGeometry(Exclude, 整页矩形, T)`；r=w+h 时折痕越过右下角，旧页恰好全被卷走，p=1 只剩底层新页，收层不跳变。
- 坑：① 不要把 `Clip` 和 `RenderTransform` 放在同一元素上——WPF 对两者先后语义容易踩坑，改为「无变换的父 Grid 裁 T' + 子 Image 做镜像」，坐标系确定；② `LinearGradientBrush` 没有 `(Point, Point)` 构造重载，要用无参构造 + `StartPoint`/`EndPoint` 属性（构建曾报 CS1503）；③ 旧代码的方向字段 `_slideForward`、`_dpiScaleX`、`SlideEdgeWidth` 在卷页模式下不再被读取，必须一并删掉，否则 CS0414 警告；④ 收层时要清空 Clip / RenderTransform / Source，否则影响下次翻页。
- 阴影：`LinearGradientBrush` 沿包围盒对角线，offset 0.52（折痕处）最深 `Argb(110,0,0,0)`，向卷角尖端渐隐。
- 验证：用 PowerShell STA + 真实 WPF（`RenderTargetBitmap`）离线渲染过 p=0.18 / p=0.45 两帧：早期呈左上角小三角折角（蓝色露出新页 + 绿色镜像纸背盖在剩余旧页上），中期折痕按 x+y=r 推进、旧页逐段退走，末尾只剩新页，与公式一致。
- 限制：这是 2D 平面折角近似，不是圆柱面卷曲（WPF 无 HLSL shader 时的常见做法）；纸背显示的是旧页镜像而非真正的背面内容。未做应用内 GUI 端到端实测。

## 2026-11-13 V1.2.092

**改进｜OCR「PDF输出类型」改为 PDF-XChange Viewer 风格（用户二选一确认后实现）**

- 背景：原下拉是「保留原内容&添加文字层 / 仅提取文本 (.txt)」，后一项不是 PDF，命名也与常见阅读器不一致。用户确认要「可搜索图像 / 可编辑文本和图像」两项都输出 PDF，后者要用识别文字替换页面图像。
- 实现：`Native/Pdfium.cs` 新增 `FPDFPage_CountObjects/GetObject/RemoveObject/InsertObject/GenerateContent`、`FPDFPageObj_Destroy/CreateTextObj/SetFillColor`、`FPDFText_SetText/LoadFont/LoadStandardFont` 等 P/Invoke；`PdfDocument.RebuildPageAsEditableText` 倒序移除图像对象（正序会漏删）、按 `LineIndex` 分组按行插入可见文本对象、最后**必须**调 `FPDFPage_GenerateContent` 才会写回 /Contents；`MainWindow.OutputOcrEditablePdfAsync` 在副本上重建后另存 `原名_OCR_可编辑.pdf`，原文件不动。
- CJK 字体：`FPDFText_LoadFont(doc, simhei.ttf bytes, FPDF_FONT_TRUETYPE=2, cid=1)`。用 Python ctypes 对真实 pdfium.dll 做过端到端探针：字体加载成功、`FPDFText_SetText(to, "中文测试 ABC 123 电压")` 成功、`InsertObject`/`GenerateContent` 成功、`FPDFText_GetText` 回读 15 字符完全一致。
- 坑：① `FPDFPageObj_Transform` 原生返回 void，项目里的历史声明写成 int 只会读到垃圾返回值（不影响调用，新代码不检查返回值）；② `RemoveObject` 成功后对象所有权交回调用方，要 `FPDFPageObj_Destroy`，否则泄漏；③ 不调 `GenerateContent` 保存后改动全丢；④ 行内拼接不能一律 `string.Join(" ")`，中文会变成「中 文 测 试」，改按相邻块间距 > 0.25 字号才补空格；⑤ `OcrWord.Y` 是文字框底边（PDF 左下原点），文本对象基线要略高于它。
- 限制：扫描页的整体图像被移除（不是只擦除文字区域），输出是纯文字版面的 PDF；页面上的矢量图形、原有文字和标注保留。RapidOCR 无图像修复能力，做不到 PDF-XChange 那种「图像里只把字擦掉」的精细重建。未做应用内 GUI 端到端实测。

## 2026-11-13 V1.2.091

**改进｜AI 分析导出文件名追加当前时间（用户诉求：`文档名_分析报告_时间.md`）**

- 背景：V1.2.090 只带文档名，同一份规格书连续导出两次仍会同名，保存对话框会提示覆盖。
- 改动：`AIAnalysisDialog.DefaultReportName()` 末尾追加 `DateTime.Now.ToString("yyyyMMdd_HHmmss", CultureInfo.InvariantCulture)`，单份 / 对比两种命名都带；时间戳在 `OnSave` 打开保存对话框时生成，不是窗口创建时，所以每次导出都是当下时间。
- 坑：时间格式别用 `yyyy-MM-dd HH:mm:ss`——冒号是 Windows 文件名非法字符，会导致保存失败；用 `InvariantCulture` 避免个别区域设置（如佛历）输出非公历年份。时间戳固定 15 字符，加上限长 60 的文档名后总长仍远小于 255。
- 经验：默认文件名里加「可排序的时间」比加序号更实用——既不依赖已有文件列表、天然按时间排序，也不会和用户自己的编号冲突。

## 2026-11-13 V1.2.090

**改进｜AI 规格书分析导出报告默认文件名带文档名（用户诉求）**

- 背景：`AIAnalysisDialog.OnSave` 的 `SaveFileDialog.FileName` 写死 `规格书分析报告.md` / `规格书对比报告.md`，连续分析多份规格书时每次导出都要手动改名，否则会覆盖上一份报告。
- 改动：新增 `DefaultReportName()` / `SafeDocName()`；单份输出 `{文档名}_分析报告.md`，对比输出 `{文档名A}_对比_{文档名B}_分析报告.md`。`_docs[i].Title` 来自 `MainWindow` / `CompareWindow` 的 `Path.GetFileName(doc.FilePath)`（含 `.pdf`）或占位名，故用 `Path.GetFileNameWithoutExtension` 去扩展名，并清理 `Path.GetInvalidFileNameChars()`、去掉结尾点/空格、单名限长 60 字。
- 坑：`Path.GetFileNameWithoutExtension` 遇到含非法字符的标题会抛 `ArgumentException`，要 try/catch 回退「未命名文档」；文档名以点结尾时 Windows 保存会异常，`TrimEnd('.', ' ')` 不能省。
- 经验：默认文件名是「每次都用、错了会覆盖用户成果」的细节，命名要能表达来源对象；直接从已有 `Title` 派生即可，不必给对话框新增参数。

## 2026-11-13 V1.2.089

**修复｜欧路取词翻译部分词只显示音标、没有中文释义（用户反馈：`Copyright` 无中文）**

- 现象：切到欧路词典后查 `Copyright`，悬浮窗只有「英 /kɒpirait/ 美 /kɑ:pirait/」与「来源 欧路词典」，没有中文行。
- 根因：`ParseEudic` 的 `EudicExpBlock` 正则写死 `<div class="exp"><ol>…</ol></div>`。实测欧路 `ExpFCchild` 主释义区有四种排版：① `div.exp > ol > li`（test / device / hello / 中文词「测试」）；② `ol > li` 无 exp 外层（logic）；③ `div.exp` 内裸文本（Cirrus / voltage）；④ 完全裸文本 `<i>n.</i> 版权`（Copyright，单条释义不生成列表）。②③④ 全匹配不到，`explains` 为空，但音标正则仍能命中，于是返回「有音标无释义」的结果——正是截图现象。
- 改动：`Translation/WordLookup.cs` 以 `<div id="ExpFCchild">` 为锚点截取主释义区（边界取下一个 `<div id="ExpSYN/SPEC/LJ">`），先删 `<div id="trans">` 时态块与 HTML 注释；区内有 `<li>` 就逐条取，否则把 `<br>` / 块结束标签转换行后按行拆出裸释义。新增 `HtmlComment/BrTag/BlockEnd/EudicTransBlock` 正则与 `t.Length > 120`、`t.Contains('<')` 过滤。
- 附带修复（图片化缺字）：站点把部分汉字换成 `<img class="dictimgtoword">`，实测按词条固定命中（`device`/`voltage` 连续 6 次全中，`Cirrus` 6 次中 1 次），重试无用。因此 `ParseEudic` 加 `out bool obscured`，`FetchAsync` 在缺字 / 主释义为空 / 欧路请求失败时用 `FetchYoudaoAsync` 自动回退有道并覆盖「来源」文案；`FetchYoudaoAsync` 自带 try/catch，降级失败不能把已解析的欧路结果一起吞掉。`PdfPageView.BuildTranslationSection` 在两引擎都无释义时补一行可操作提示。
- 坑：`html.IndexOf("id=\"ExpFCchild\"")` 定位在属性中间，直接 Substring 会把 `id="ExpFCchild" class="expDiv">` 残留成一条「释义」，必须回退 `LastIndexOf('<', hit)` 从完整标签开始；截断边界要用 `<div id="Exp` 而非 `class="explain_wrap"`，否则半个标签会留在 scope 里。
- 经验：抓第三方网页别拿单个样本的结构写死正则——同一站点「多释义 / 单释义 / 无外层列表」可能是三套模板。验证要覆盖典型词条（本次用 PowerShell 对 9 个真实词跑同一套解析逻辑，确认 `Copyright → n. 版权`、中文词仍返回英文释义、缺字词被正确标记降级）。站点把文字转图片时，优先「检测 + 换数据源降级」而不是盲目重试。

## 2026-11-13 V1.2.088

**改进｜AI 设置移出首选项、改独立对话框并重排布局（用户诉求：从首选项移出来，只保留拓展下拉菜单项，界面挤且乱）**

- 根因（为什么会挤且乱）：`AiSettingsPanel` 原本是 220px 左栏 + `Star` 右栏的 Grid，被塞进 620px 宽的 `PreferencesDialog` 右侧内容区（约 406px），扣掉 220 + 16 间隔后**右栏实际只有约 170px**。于是：四个固定宽度按钮放进 `WrapPanel` 在左栏折成参差两行；六个字段各自「标题 + 输入框」纵向堆叠、长说明每行只显示十来个字；「测试连接」与 `MaxWidth=320` 的结果文本硬塞同一行，互相挤压。`Field()` 存的 placeholder 只写进 `TextBox.Tag`、从未展示，属于无效布局负担。
- 改动：新增 `Dialogs/AiSettingsDialog.cs`（独立窗口：`ThemeManager.ApplyTitleBar` + `DialogCentering` + 动态主题资源 + 关闭前 `Flush()`）；`AiSettingsPanel` 重构为 `Grid` 三行三列 —— 左栏 252px（固定高度列表 + 2×2 等宽按钮 Grid）、中间 20px 间隔、右栏 `Star`（「连接参数 / 生成参数」两组两列表单，标签列 112px），底部跨 3 列放分隔线与说明。placeholder 改作 `ToolTip`；测试结果用带边框的 `Border` 独占一行并去掉 `MaxWidth`。
- 入口：`MainWindow.BuildExtendedToolsMenu` 的 `miAiSet` 与 `AIAnalysisDialog._settings` 从 `new PreferencesDialog("AI 大模型")` 改为 `new AiSettingsDialog`；`PreferencesDialog.xaml` 删除「AI 大模型」`ListBoxItem` 与 `PageAi`/`AiHost`，`OnCategoryChanged` 去掉 `idx == 10` 分支。首选项分类收敛为 10 项（0–9），索引 7/9 的文件关联与 OCR 刷新逻辑不变。
- 坑：`UserControl` 靠 `LostFocus` 提交时，按 Esc 关闭窗口不会触发 `LostFocus`，最后一次编辑可能丢失；所以在窗口 `Closed` 里显式调用 `Flush() → Commit() → Save()`。另外 `SizeToContent=Height` 的窗口里 `Grid` 行别用 `Star`，改 `Auto`，否则内容测高会被压到最小值。
- 经验：「把一个功能页从通用设置里搬出来」要同时核对四处：分类列表项、页面容器、索引切换分支、以及所有以「打开首选项并定位分类」为形式的跳转（`initialCategory`），漏一处就会出现空分类或跳到错误页。

## 2026-11-13 V1.2.087

**新增｜接入欧路（欧陆）词典取词翻译，并可切换引擎（用户诉求）**

- 调研结论（决定实现路径）：① 欧路官方 OpenAPI 是 `https://api.frdic.com/api/open/v1/...`，鉴权为 Header `Authorization: NIS {token}`，Token 要到 `my.eudic.net/OpenAPI/Authorization` 申请，且接口以生词本 / 笔记 / 语料为主，不是通用查词释义；② 官方 URL Scheme 文档明确写「以下 URL Scheme 仅 iOS 设备可用」，`eudic://dict/{word}` 在 Windows 需第三方注册协议处理器；③ 但 `https://dict.eudic.net/dicts/en/{word}` 网页**免登录直接返回音标与释义**，中文词走同一路径也返回汉英释义。因此选③，零配置、应用内悬浮窗显示。
- 改动：`Translation/WordLookup.cs` 加 `EngineYoudao/EngineEudic` 常量、`CurrentEngine/CurrentEngineName`；`LookupAsync` 缓存 key 改为 `引擎 + \u0001 + 词`，`FetchAsync(word, engine)` 分发到 `FetchYoudaoAsync`（原逻辑）与 `FetchEudicAsync`（新 HttpClient：完整 Chrome UA + `AutomaticDecompression=GZip|Deflate|Brotli`）；新增 `ParseEudic` 用正则取 `<span class="phontype">英/美</span><span class="Phonitic">/.../</span>` 与 `<div class="exp"><ol><li>…</li></ol></div>`；`LookupResult` 加 `Source`。`AppPrefs.WordLookupEngine` 持久化；`PreferencesDialog.xaml/.cs` 的取词翻译页加引擎 ComboBox（Tag=Youdao/Eudic）、载入与保存、切换时 `WordLookup.ClearCache()`；`PdfPageView` 悬浮窗显示「来源」并把失败文案从写死「有道词典」改为通用。
- 坑（实测）：欧路网页有**反爬**——User-Agent 只写 `Mozilla/5.0` 时，部分汉字会变成 `<img class="dictimgtoword" src="...png">`，把 HTML 标签去掉后释义会缺字（如 `n. 检；`）。换完整 Chrome UA 后连续 4 次请求均为纯文本 `<li>n. 检验；试验</li>`。所以 UA 不能省；站点若日后改策略，个别词释义可能不完整，界面已提示可切回有道。
- 经验：接入第三方词典先核实官方接入方式（OpenAPI / URL Scheme / 网页）的**平台限制与鉴权成本**，别想当然用移动端 Scheme；抓网页做数据源时，必须用真实浏览器 UA + 自动解压，并用真实响应验证解析正则（本次先用 PowerShell 对真实 HTML 跑正则才锁定标签结构）；多引擎切换时缓存 key 一定要带引擎标识。

## 2026-11-13 V1.2.086

**新增｜大模型输入 API Key 后要有测试功能（用户诉求）**

- 背景：V1.2.085 加了「添加免费模型」一键带入配置，但用户填完 Key 无法立即知道是否可用，只能关掉首选项点「AI 分析」，失败信息还是原始的 `401 Unauthorized: {...}`。
- 改动：`LLM/LlmClient.cs` 新增 `TestAsync(baseUrl, apiKey, model, ct)`（最短非流式请求 + 普通 JSON / SSE 双解析 + `Shorten` 截断 + `ExplainHttpError` 状态码中文归因 + `ExtractErrorDetail` 取服务端 error.message），`IsLocalEndpoint` 改 `internal` 供面板复用；`Dialogs/AiSettingsPanel.cs` 在 API Key 行下加「测试连接」按钮与结果 TextBlock，`OnTest()` 用 `async void` + `ConfigureAwait(true)` + `CancellationTokenSource(25s)`，缺字段即时提示、切换模型清空结果、测试期间禁用按钮；note 补上「粘贴 Key 后点测试连接」。
- 坑：`ChatAsync` 只在 `onDelta != null` 时才把 `stream` 设为 true，但它**无论流式与否都按 `data:` SSE 行解析**，非流式返回的普通 JSON 会被整段跳过、返回空字符串——所以测试必须写独立方法，不能传 `onDelta: null` 复用。另外免费模型的 404/429 很常见（模型轮换、免费额度），错误信息要翻译到「去控制台确认模型名 / 稍后再试」这种可操作层级，并保留服务端原文。
- 经验：给第三方 API 做「测试连接」，请求体尽量只带 `model/messages/stream/temperature`，不要加 `max_tokens` 等各家兼容性不一的字段；用带超时的 CTS 而不是依赖全局 HttpClient 的 10 分钟超时；异步事件处理用 try/finally 恢复按钮状态，early return 也要走 finally。

## 2026-11-13 V1.2.085

**改进｜让免费 AI 大模型「一键可用」（用户诉求：自动接入免费 AI 大模型，选择只做免费云端预设）**

- 背景：AI 分析原本默认预设是 `https://api.openai.com/v1` + `gpt-4o-mini`（付费且无 Key），用户要自己查 4 项配置；`LlmClient.IsConfigured` 只校验地址 + 模型名，导致「显示已配置、点分析才 401」。
- 改动：新增 `LLM/FreeModelCatalog.cs`（`FreeModelPreset` 记录 + 5 份免费云端预设）与 `Dialogs/FreeModelPickerDialog.cs`（纯 C# 选择窗口：模型清单、端点/说明、「打开申请页面」用 `Process.Start(UseShellExecute=true)`、隐私告知）；`Dialogs/AiSettingsPanel.cs` 左栏按钮行由 `StackPanel` 改 `WrapPanel` 容纳第 4 个按钮「添加免费模型」，`OnAddFree()` 创建 `AiModelEntry`（Name/BaseUrl/Model 自动带入、Key 留空）、加入 `AiModels`、设为 `AiActiveModelId`、`ResyncWorking()` + `Save()`，`LoadList()` 后把焦点交给 `_apiKey`；note 增加三步提示与隐私说明。`LlmClient.IsConfigured` 增加云端 Key 校验（`IsLocalEndpoint` 覆盖 loopback 与 10./192.168./172.16-31. 内网段，避免让自建推理服务回归），`AIAnalysisDialog` 未配置文案改为「AI 设置 → 添加免费模型」指引。
- 取舍：**不做**内置共享 Key / 免 Key 公共代理——会被滥用封禁，且把用户 PDF 内容静默发给第三方；云端免费层必须本人申请 Key，程序只负责把地址与模型名带对。所有端点按现有 `LlmClient` 规则拼成 `BaseUrl + "/chat/completions"`，且分析走 `onDelta` 流式（`stream=true`），与这些服务的 SSE 兼容。
- 经验：给「免费模型」做内置清单时，务必同时给出申请入口 + 免费政策会变的免责说明 + 文档外发的隐私告知；加第 4 个按钮到窄左栏用 `WrapPanel` 自动换行而非硬加宽；判定「是否配置好」不能只看地址/模型，要把云端 Key 纳入，但本地/内网自建服务要豁免。

## 2026-11-13 V1.2.084

**动效修正｜翻页「页面右移后反弹」不是 iPhone 翻页动态（用户反馈）**

- 现象/根因（三处叠加）：① V1.2.081 把翻页曲线换成 `t+sin(πt)/π`，它虽单调无超调，但 `f'(0)=2`（起步速度是平均的 2 倍）、前半程走完 82% 距离，视觉上就是「猛地弹出去再长尾慢慢收」，被感知为反弹；② `PdfPageView.PlayRotationInAnimation` 用 `LayoutAnim.Spring`（`1-e^{-11t}cos(10t)`，约 3.6% 超调）做页面旋转角度，是页面级**真正会超调回弹**的动画；③ `SetSlideProgress` 给进入页恒加 `dir/s` 的 1 设备像素接缝重叠，动画结束帧新页仍停在 ±1px，收层露出真实文档区时跳一下，也像回弹。
- 改动：`LayoutAnim.IosGlideEase.EaseInCore` 改为 `(1-cos(πt))/2`（easeInOutSine），`Glide` 与 `StartSlideAnimation` 注释同步；`PlayRotationInAnimation` 的 `EasingFunction` 由 `Spring` 改 `Decel`；`SetSlideProgress` 用 `double overlap = p < 0.999 ? dir * (1.0/s) : 0.0;` 让收尾帧归零；`AppPrefs.Anim.Items` 里 Rotation 描述改为「平滑旋入与淡入」。两页贴合推拉、设备像素对齐、不透明底色保留。
- 经验：用户说「反弹/回弹」时，除了找真正超调的 Spring/BackEase，还要检查 **easeOut 系的起步猛冲** 和 **动画终值与真实布局的 1px 偏差**——两者都不含超调却同样产生「弹一下」的错觉。iPhone 整页翻动是两端平滑、无超调的 easeInOut（`UIViewAnimationCurveEaseInOut`），不是 easeOut；页面级动效应与 UI 卡片的弱回弹分开处理。

## 2026-11-12 V1.2.083

**界面改进｜侧栏底部三个页签要充满侧栏并随宽度自适应（用户截图红框标注）**

- 现象：`SideTabs`（`TabStripPlacement=Bottom` 的 TabControl）默认模板用 `TabPanel` 承载页签，按内容宽度左对齐排列，三个小页签只占侧栏底部左侧一小块，右侧大片空白。
- 改动：`MainWindow.xaml` 给 `SideTabs` 增加 `TabControl.Template` —— `DockPanel LastChildFill=True`，`UniformGrid Dock=Bottom Rows=1 IsItemsHost=True` 作页签条，`Border` + `ContentPresenter x:Name=PART_SelectedContentHost ContentSource=SelectedContent` 作内容区（Background/BorderBrush/BorderThickness/Padding 均 TemplateBinding）。三个 Header 的 TextBlock 加 `TextAlignment=Center` + `HorizontalAlignment=Stretch`。
- 坑：WPF `TabControl` 的默认模板里**直接硬编码了 `<TabPanel IsItemsHost="true">`，没有 `ItemsPresenter`**，所以只设置 `TabControl.ItemsPanel` 不会生效，必须替换整个 `ControlTemplate`。另外 `UniformGrid` 只指定 `Rows=1`、不写死 `Columns`，列数会按子项数量自动算，页签增减不用改代码。
- 经验：要改 TabControl 页签条的排布（等分 / 换行 / 右对齐），别指望 `ItemsPanel`，直接自定义模板换 items host；模板里保留 `PART_SelectedContentHost` 与 `ContentSource=SelectedContent` 才能正常显示选中页内容。

## 2026-11-12 V1.2.082

**界面调整｜把不透明度调节移到「线厚度」上面（用户诉求）**

- 改动：`Dialogs/MarkupStyleDialog.cs` 用 `int widthRowIndex = showOpacity ? 2 : 1; int buttonRowIndex = showOpacity ? 3 : 2;` 统一计算行号；`Grid.SetRow(opRow, 1)`、`Grid.SetRow(widthRow, widthRowIndex)`、`Grid.SetRow(buttons, buttonRowIndex)`；不透明度行上边距 12→10、线厚行 10→12。只改布局行号，颜色/线厚/不透明度的取值与写回逻辑完全不变。
- 坑：不能只交换两行 `Grid.SetRow` 的字面值。`showOpacity=false` 时不会创建不透明度行与对应 `RowDefinition`，若把线厚写死成 Row2、按钮仍是 Row3（钳到最后一行 Row2），两者会重叠在同一行。行号必须由可选行是否存在推导。
- 经验：Grid 里存在**条件显示的行**时，行索引一律用变量按条件推导，别写死数字；WPF 会把超出范围的 `Grid.Row` 钳制到最后一行，这类重叠不会报错、只表现为布局错乱，容易漏测。

## 2026-11-12 V1.2.081

**优化｜iOS 文档操作动效不够丝滑（用户诉求：目标更丝滑）**

- 现象/根因：整屏翻页用 `IosDecelerate` 四次衰减 `1-(1-t)^4`，前 10% 时间就走完 34% 距离、末段速度趋近 0；而 V1.2.072 为消除接缝 shimmer 把位移 `snap` 到设备像素，位移 <1px/帧 的帧画面完全不动。四次衰减下这类「静止帧」约占动画后 21% 时长（360ms@60fps 约 5 帧），观感就是起步猛冲 + 尾段粘滞 + 突然收层。次要因素：抓图分辨率上限 12M 让 UI 线程在动画开始前同步渲染两张大位图；`WhenViewportRendered` 必须等第一个 16ms timer tick 才开始淡化。
- 改动：`LayoutAnim` 新增 `IosGlideEase`（`t+sin(πt)/π`）与 `Glide` 属性；`StartSlideAnimation` 的 `EasingFunction` 由 `Decel` 改 `Glide`，`SlideDurationMs` 420→360；`SetSlideProgress` 压暗系数 0.24→0.18；`CaptureViewport` 的 `MaxPixels` 12M→8M；XAML 两张 `PageSlide*Image` 加 `RenderOptions.BitmapScalingMode="LowQuality"`；`WhenViewportRendered` 在起 timer 前加 `if (PagePanel.HasLayout && ViewportPagesReady()) { done(); return; }`（只判断不触发 `EnsureViewportRendered`，避免同步路径拖慢当帧；布局未完成不抢跑，防白纸）。
- 经验：做「位图平移 + 设备像素对齐」的动画时，缓动曲线的**低速帧占比**直接决定流畅度——easeOut 次数越高长尾越粘，应选起点/终点加速度都连续、中段接近匀速的曲线（这里是 `t+sin(πt)/π`）；降采样阈值/位图缩放模式只影响运动中的临时快照，是低风险的提速手段；「等待渲染完成再开始过渡」的轮询要加同步快速路径，但必须带布局完成守卫，否则会在页面未排版时揭开遮罩。优化前先确认不回退此前的防闪动成果（像素对齐 + 接缝重叠 + 不透明底色）。

## 2026-11-12 V1.2.080

**修复｜后台打开第二个文档时窗口不切前台、只闪任务栏按钮（用户反馈）**

- 现象：打开第一个文档时窗口正常在前台；切到资源管理器后再双击第二个 PDF，软件只是在任务栏闪，不切到前台。
- 根因：程序是单实例（Global Mutex + 命名管道）。第二个实例转发文件路径后立刻 `Environment.Exit(0)`，已有实例在管道回调里 `win.WindowState = Maximized; win.Activate();`。`Window.Activate()` 底层就是 `SetForegroundWindow`，而 Windows 的前台锁定规则规定：**非前台进程**调用它一般会被拒绝，系统改为闪烁任务栏按钮提示用户，不会把窗口切过来。第一实例此时正是后台进程，必然被拒。
- 改动：新增 `PdfReader.Native.WindowActivator`。① `GrantForegroundToOtherInstance()` 由第二实例在转发/退出前调用 `AllowSetForegroundWindow(ASFW_ANY)`（由前台进程 shell 拉起的短命进程通常有此权限）；② `BringToFront(Window)` 在 UI 线程执行：`IsIconic` 时 `ShowWindow(SW_RESTORE)`，取前台窗口线程 → `AttachThreadInput(cur, fg, true)` → `SetWindowPos(HWND_TOPMOST)` 再 `HWND_NOTOPMOST` → `BringWindowToTop` + `SetForegroundWindow`，若 `GetForegroundWindow()` 仍不是本窗口则 `SwitchToThisWindow(hwnd, true)` 兜底 → 分离线程输入 → `win.Activate()/Focus()`。`App.StartPipeServer` 用 `BringToFront` 替换 `Activate()`，并只在非最大化时才改 `WindowState`。
- 经验：WPF 单实例转发的经典坑——「窗口已经存在但在后台」时 `Activate()` 不可靠，必须按 Win32 前台规则处理：`AllowSetForegroundWindow`（由新实例授权）+ `AttachThreadInput`（附加前台线程输入队列）+ 临时 TOPMOST 压 Z 序 + `SetForegroundWindow`；`SwitchToThisWindow` 作兜底。授权调用必须放在第二实例退出之前。另外对已最大化的窗口别重复赋 `WindowState = Maximized`，可少一次布局抖动。

## 2026-11-12 V1.2.079

**交互调整｜文档标签指针改标准箭头 + 双击关闭文档（用户诉求）**

- 改动：`MainWindow.xaml` 中 `DocTabItemStyle`、`TabCloseButton` 两个样式的 `FrameworkElement.Cursor` 由 `Hand` 改为 `Arrow`（两种指针来源都覆盖，标签任一位置都是标准箭头；其它工具栏按钮/滚动三角的手型不变）。`MainWindow.xaml.cs` 的 `MakeTabItem` 把 `item.MouseDoubleClick` 由 `ActivateTab(tab)` 改为 `CloseTab(tab)`；给关闭按钮加 `MouseDoubleClick` 并 `e.Handled = true` 阻断冒泡；`CloseTab` 开头加 `if (!_tabs.Contains(tab)) return;` 防重入。
- 为什么两处 Cursor 都要改：WPF 的 `Cursor` 是继承属性，子元素（关闭按钮）自己设了 `Hand` 会覆盖父级 TabItem 的 `Arrow`，只改样式之一会出现「标签文字上是箭头、移到叉号又变手」。
- 经验：改一组控件的鼠标指针要先找出所有显式设置点（样式 Setter 用 `FrameworkElement.Cursor`，不易被 `Cursor=` 文本搜索命中）；把双击从「激活」改成「关闭」这类破坏性操作，要保留原有的未保存确认流程，并对"连点/双击命中关闭按钮"加冒泡拦截与关闭入口防重入。

## 2026-11-12 V1.2.078

**修复｜侧边栏无法拖动改变宽度（用户反馈）**

- 现象：左侧书签/缩略图侧栏的分隔条拖不动，宽度无法调整。
- 根因：`MainWindow.xaml` 的 `SidebarSplitter` 带着设计器误拖留下的属性——`Margin="1,0,997,0"`（右边距 997）、`Grid.ColumnSpan="2"`（跨到文档区列）、`RenderTransform` 里 `RotateTransform Angle="1.987"`。按列宽计算，跨列总宽约 `6 + 文档区宽`，减去左 1 右 997 后，在常见窗口宽度下命中宽度被压成 0；窗口更宽时又会把透明分隔条铺开覆盖文档区左侧。列宽本身只有 4 DIP，即使命中也偏窄。次因：展开动画 `AnimateColumn` 用 `FillBehavior.HoldEnd`，动画未结束时 `GridSplitter` 写入的列宽会被动画值压制。
- 改动：XAML 去掉超大 Margin / ColumnSpan / 旋转变换，分隔条改为只占 `SidebarSplitterColumn` 并 `HorizontalAlignment+VerticalAlignment=Stretch`；`SetSidebarVisible` 把该列宽 4→6 DIP；新增 `SidebarSplitter.DragStarted`，若 `_layoutAnimating` 则读出 `SidebarColumn.Width`（动画当前呈现值）→ `BeginAnimation(WidthProperty, null)` 撤动画 → 回写该值落定 → 递增 `_layoutAnimToken` 作废旧回调 → 复位 `_layoutAnimating`/`MinWidth`/`SidePanel.Width`。`DragCompleted` 记录宽度、退出写首选项的逻辑不变。
- 经验：XAML 设计器会留下"看起来无害"的异常值（超大 Margin、ColumnSpan、微小旋转），排查命中问题先核对 `Margin`/`ColumnSpan`/`RenderTransform` 与实际列宽；`GridSplitter` 要稳定可拖，请让它**只占一个固定宽度的分隔列**（≥6 DIP），不要靠跨列+大负/正 Margin 去凑位置；带列宽动画的布局，用户拖动前必须撤掉 `HoldEnd` 动画并落定当前呈现值，否则动画值优先级高于本地值导致拖动无效。

## 2026-11-12 V1.2.077

**修复｜查找工具栏无法弹出（用户反馈）**

- 现象：点工具栏「查找」按钮 / Ctrl+F / 菜单「查找」，悬浮查找栏不出现。
- 根因（三个叠加）：① `MainWindow.xaml` 的 `SearchBar` 带 `Height="0"`，代码从未改回，Border 由内容撑不开，即使 `Visibility=Visible` 也是 0 高；② `CloseSearch` 的 `LayoutAnim.PopOut` 用 `FillBehavior.HoldEnd` 把 `Opacity` 停在 0、缩放停在 0.94，动画值优先级高于本地值，所以「动效关闭」分支里 `SearchBar.Opacity = 1` 被压制，栏仍是透明；③ `OnSearchToggle` 用 `SearchBar.Visibility` 判断开关，而 PopOut 动画期间 Visibility 仍是 `Visible`，再点会被判为「已打开」而执行关闭，表现为点了没反应。
- 改动：XAML 去掉 `Height="0"`；新增 `_searchShown` 目标状态替代 Visibility 判断；`OpenSearchBar` 无条件设 `Visible`，动效开启走 `PopIn(240ms)`、关闭走 `PopIn(0)`（该分支 `ResetTransform` 会 `BeginAnimation(...,null)` 清残留 + 复位 scale/translate/Opacity）；`CloseSearch` 同步状态、无动效时也复位，PopOut 完成回调加 `if (_searchShown) return` 防止动画途中重开被误隐藏。
- 经验：WPF 里 `FillBehavior.HoldEnd` 的动画值优先级高于本地属性值，直接赋 `Opacity=1` 无效，必须先 `BeginAnimation(dp, null)` 清动画（或让动画库提供 0ms 复位分支）；带进出动画的浮层要用独立布尔目标状态判断开/关，不能用 `Visibility`——动画期间 Visibility 还没变；显式写 `Height=0` 的容器即使 Visible 也不可见，折叠请用 `Visibility` 而非 Height。

## 2026-11-12 V1.2.076

**改进｜文档属性 GroupBox 显示两条框线（用户反馈）**

- 根因：默认 `GroupBox` 控制模板的标题处会把上边框断开成标题两侧的两段横线，整体看上去像"两条框线"；叠加主题边框后更明显。
- 修复：`DocumentPropertiesDialog.cs` 用 `XamlReader.Parse` 定义一个单线模板（`ControlTemplate`）——标题 `ContentPresenter` 放在 `Grid.Row=0`、框体 `Border`（圆角 4、单一 1px 边框）在 `Row=1`，标题置于框上方不再切边框，整体为一条干净线框；实例 `box.Template = GroupBoxTemplate` 局部套用（GroupBox 全项目仅此一处使用，且未动全局样式）。
- 经验：WPF 默认 `GroupBox` 模板的标题凹槽易显"双线"；要干净单线就自定义 `ControlTemplate`（标题上置 + 单个 `Border`）而非沿用默认；纯 C# 构建 UI 时可用 `XamlReader.Parse` 直接解析模板字符串，免去另建 XAML 资源文件。

## 2026-11-12 V1.2.075

**改进｜文档属性去掉顶部蓝色标题区（用户红框标注该区去重求紧凑）**

- 改动：`DocumentPropertiesDialog.cs` 删除 `header` 蓝色 `Border`（「文档属性」标题 + 文件名两行），`fileName` 变量一并移除；`Title="文档属性"` 仍保留作窗口标题栏。`DockPanel` 顶部直接是分组主体，文件名信息由「文件 ▸ 文件名」行提供，不丢失。
- 经验：对话框里"标题 + 文件名"这类顶部横幅若与下方分组内容重复就属冗余，可删；窗口标题用 `Title` 即可满足系统标题栏/任务栏显示，不必在内容区再画一遍。

## 2026-11-12 V1.2.074

**改进｜文档属性用 GroupBox 包裹分组 + 宽度 1.5×（用户诉求）**

- 改动：`DocumentPropertiesDialog.cs` 主体构建时，每个分组不再用独立的 `TextBlock` 小标题 + 裸 `Grid`，改为包进 `GroupBox`（`Header=分组名`，`Margin`/`Padding` 留白，前景/背景/边框绑定 `Th.Text`/`Th.PanelBg`/`Th.Border`）；去掉了原来的分组标题文字块。`Width` 620→930（1.5×），高度仍 `SizeToContent.Height` 自适应。
- 经验：同组内容用 `GroupBox` 包裹比"标题+网格"更规范、分区更清晰；因为 Header 已充当分组名，记得删掉原先独立的标题文字避免重复；纯 C# 构建 UI 时 `GroupBox.Content` 直接赋子控件即可。

## 2026-11-12 V1.2.073

**改进｜文档属性里 PDF 创建/修改日期显示原始串（用户截图红框：`D:20260528205629+08'00'`）**

- 根因：`PdfDocument` 构建属性行时直接把 `FPDF_GetMetaText` 取到的 `/CreationDate`、`/ModDate` 原文塞进行值，PDF 日期是 `D:YYYYMMDDHHmmSS±HH'mm'` 专有格式，对用户不友好。
- 修复：新增 `PdfDocument.FormatPdfDate`（剥 `D:` 前缀 → 取连续数字段 → ≥8 位按 YYYYMMDD 起、≥10/12/14 位补时分秒，容错缺省与非法值，失败原样返回），「创建日期/修改日期」两行经其格式化为 `yyyy/MM/dd HH:mm:ss`；`DocumentPropertiesDialog` 保存后刷新「修改日期」也走同一格式化（文件内仍写标准 PDF 日期）。
- 经验：PDF 专有格式（日期/字符串 hex 串等）展示给用户前必须在展示层格式化；解析器要容错——`D:` 前缀可选、字段逐级缺省（有的生成器只写到分钟甚至只到日）、尾部带时区引号，解析失败宁可原样返回也别抛异常丢信息。

## 2026-11-12 V1.2.072

**优化｜翻页动效有闪动 → 对齐设备像素 + 不透明层底（用户反馈）**

- 现象：整屏横向翻页滑动时画面有抖动/闪动。
- 根因：翻页用两张视口快照（`PageSlideOld`/`PageSlideNew`）盖层做水平推拉，`SetSlideProgress` 的位移是小数 DIP，逐帧在两张图接缝处被重新采样产生 shimmer；且 `PageSlideLayer` 背景 `Transparent`，底层文档（异步渲染中）从边角/缝隙透出。
- 改动：`MainWindow.xaml` 层背景改 `{DynamicResource Th.DocAreaBg}` 不透明 + `UseLayoutRounding`/`SnapsToDevicePixels`；`SetSlideProgress` 新增 `_dpiScaleX`（滑动前 `VisualTreeHelper.GetDpi(PageScroll).DpiScaleX` 缓存），位移 `snap()` 对齐设备像素，进入图多压 `1/s` 设备像素重叠接缝。
- 经验：WPF 里用位图平移做过渡动画，位移必须对齐设备像素（`Math.Round(x*dpiScale)/dpiScale`）并让相邻图重叠 1 设备像素，否则高分屏接缝处逐帧 shimmer；覆盖层要设不透明底色而非 Transparent，否则被覆盖内容异步重绘时会从缝隙透出闪烁。

## 2026-11-11 V1.2.071

**改进｜拓展菜单「取词翻译」点击看不出状态 → 加勾选 √（用户反馈）**

- 背景：用户点「拓展 ▸ 取词翻译」后发现看不出功能——它其实是开关（`OnReqWordLookupToggle` 切 `AppPrefs.EnableWordLookup` 仅用状态栏提示），菜单项没有勾选标记。
- 改动：`BuildExtendedToolsMenu` 里把 `Act.WordLookup` 的 `MenuItem` 设 `IsCheckable=true`，初始 `IsChecked=EnableWordLookup`；因 WPF 可勾选项点击会先自动翻转再触发 Click，故 Click 后再把 `IsChecked` 显式对齐到 `EnableWordLookup` 真值；并挂 `ToolsExtended.SubmenuOpened`（`SyncWordLookupCheck`）在每次展开时刷新，覆盖右键/首选项改动。`PdfPageView.AddToolContextItems` 右键同名项同样 `IsCheckable+IsChecked` 按首选项置勾选。
- 经验：开关型菜单项要用 `IsCheckable` 勾选态显式表达开/关；一旦自定义 Click 改了底层值，务必在 Click 里把 `IsChecked` 覆写为真值，否则与 WPF 默认自动翻转叠加导致状态错乱；另用 `SubmenuOpened` 刷新可解决"已在别处改了同一开关、菜单项显示滞后"的问题。

## 2026-11-11 V1.2.070

**精简｜移除工具栏形状组按钮（实心三角矩形图标）及弹出菜单代码（用户红框标注）**

- 改动：`MainWindow.xaml` 删除 `ToolShapes`（图标 + 底部小实心三角）与 `ShapesPopup`/`ShapesMenuHost` 弹层；`MainWindow.xaml.cs` 删除 `OnShapesClick`（动态构建线条/箭头/矩形/圆菜单项）、`OnShapesPopupClosed`、`IsShapeGroupTool`/`UpdateShapeGroupChecked` 及 `BackToSelectTool` 里的 `ToolShapes.IsChecked=false`、两处 `UpdateShapeGroupChecked()` 调用。
- 依据：形状组的存在意义是收纳同类型形状；V1.2.062 删掉云朵/多边形后组内只剩四个工具，而它们在工具栏本就有独立按钮，组按钮成了纯冗余入口。
- 经验：删共用入口按钮时按"XAML 控件+弹层 → 弹层构建代码 → 选中态联动（IsChecked 回弹/跟随）→ 禁用列表引用"四步清理，最后 grep 全部符号名确认零残留（obj 生成文件会在构建时重生成，不算残留）。

## 2026-11-11 V1.2.069

**改进｜文档属性窗口内容被截断出现滚动条（用户截图：关键词行被底边切掉）**

- 根因：窗口写死 `Width=540/Height=560`，而行数随内容增长（文件 5 行 + 文档 3 行 + 文档信息 4 行 + 分组标题），560 放不下，ScrollViewer（Auto）出滚动条且底部行被截。
- 修复：`Width` 540→620，去掉固定 `Height`，改 `SizeToContent=Height` 让窗口按内容自适应高度；`MaxHeight=SystemParameters.WorkArea.Height` 兜底防小屏溢出（此时 ScrollViewer 才兜底滚动）。居中复用既有 `DialogCentering.RecenterOnSourceInitialized`。
- 经验：内容行数可变的对话框别写死 Height——用 `SizeToContent=Height` + 工作区 `MaxHeight` + ScrollViewer 兜底三层组合；项目里 `DialogCentering.RecenterOnSourceInitialized` 已是 SizeToContent 弹窗的标配（StampStyleDialog / MarkupStyleDialog / FreeTextEditDialog 同款）。

## 2026-11-11 V1.2.068

**修复｜侧栏收起后「展开侧栏」把手不可见（用户截图红框标注收起钮）**

- 根因：`SidebarStrip`（内含 `SidebarExpandBtn` ►）是 `BodyGrid` 直接子级但**未设 `Grid.Column`**，默认落在第 0 列；侧栏收起后 `SidebarColumn.Width=0`，该列宽为零，而 Border 又是 `Width=0/Height=0` + `HorizontalAlignment=Center` 的"零尺寸锚点"写法，靠子内容溢出渲染——把手指望出现在窗口最左缘 x≈0 处，实际不可见（极不显眼且位置脆弱），用户收起侧栏后没有可见的展开入口。
- 修复：`SidebarStrip` 显式 `Grid.Column="2"`（文档区列）、`HorizontalAlignment="Left"` + `Margin="5,0,0,0"`、去掉 `Width=0/Height=0` 让 Border 自适应按钮尺寸、`VerticalAlignment=Center` 保持垂直居中；`Panel.ZIndex=10` 浮于文档之上，按钮去掉补偿性 Margin。显隐仍由 `SetSidebarVisible` 控制（展开时 Collapsed、收起时 Visible + SlideIn 滑入），逻辑零改动。
- 经验：`Grid` 里省略 `Grid.Column` 默认落第 0 列——把浮动元素挂到"某个宽度会变 0 的列"上，该列塌缩时元素跟着消失/错位；浮动把手应显式锚定在稳定可见的列（文档区），并用自动尺寸代替"0×0 Border 溢出"这类脆弱写法（同文件的 PerfHud 同款写法但因锚在恒宽的列 2 才侥幸可见）。

## 2026-11-11 V1.2.067

**改进｜取色弹层：当前颜色色块与标题文字间距 5px（用户截图红箭头标注大空隙）**

- 根因：`PdfPageView` 取色弹层标题行两列 Grid 为 `Star + Auto`，标题列 Star 撑满剩余宽度，把 Auto 列的当前颜色色块推到弹层最右缘，与标题文字之间出现约 150px 空隙。
- 修复：标题列 `Star`→`Auto`（两列皆 Auto，Grid 随 StackPanel 仍横向撑满、内容左聚），色块左 Margin 8→5px，色块即紧跟标题文字 5px。
- 经验：Grid 里 `Star` 列会吃掉所有剩余空间，把相邻 Auto 列推到最右；要"控件紧跟文字"应让文字列也用 Auto，靠控件自身 Margin 控制间距。

## 2026-11-11 V1.2.066

**改进｜「拓展功能」子菜单提至顶层并改名「拓展」**

- 改动：`MainWindow.xaml` 将 `Name="ToolsExtended"` 的 `<MenuItem Header="扩展功能(_X)">` 从「工具」子菜单移出，作为顶层菜单置于「工具」与「窗口」之间，Header 改为「拓展(_X)」。该 MenuItem 仍按 `Name` 被 `BuildExtendedToolsMenu()` 动态填子项（`ContextToolCatalog` 的 `InDropdown` 项 + 对比分屏 + AI 分析/设置），故代码逻辑零改动。
- 经验：WPF 菜单项靠 `Name` 引用时，移动位置/改 Header 不影响后台填充逻辑，只需保持 `Name` 不变；跨文件注释描述菜单路径要同步更新，否则文档与实现漂移。

## 2026-11-11 V1.2.065

**改进｜文档属性：标题/作者/主题/关键词可获取并可编辑（用户红框标注）**

- 背景：用户截图红框圈住文档属性「文档信息」的标题/作者/主题/关键词，要求能获取且能编辑。
- 关键事实：捆绑 pdfium.dll 的 PE 导出表里**没有** `FPDF_SetMetaText`（实证字节搜索 False；`FPDF_GetMetaText` 有），读可以、写不行。
- 方案：复用书签写回的增量更新机制。新建 `Pdf/PdfInfoWriter.Apply(pdfBytes, title, author, subject, keywords)`：`PdfFileReader`（新增 `InfoNum` 捕获最新 trailer 的 /Info）取现有 Info 字典为底稿 → `DictSet/PdfString`（UTF-16BE 十六进制串）改写四键 + `/ModDate`（D:YYYYMMDDHHmmSS±HH'mm' 本地时区）→ 追加新对象 `N 0 obj`（N=reader.Size）+ xref 子段 + 新 trailer（/Size N+1 /Root /Info N 0 R /Prev StartXref）。`PdfDocument.InfoOverride` 每次保存重放，避免被 pdfium 全量重写覆盖掉。
- 细节：①对话框「—」占位符↔空串映射，留空=DictRemove 删键；②`SetDocumentInfo` 先用 `OriginalBytes` 过一遍 `PdfFileReader.IsEncrypted` 提前拒绝加密文档，否则 InfoOverride 挂上后每次 Ctrl+S 都会抛异常；③Load()/Release() 与 OutlineOverride 一并清空 InfoOverride；④保存回调在对话框里包等待光标，返回错误串统一弹窗，返回 null 算成功并禁用保存按钮。
- 经验：写 PDF 结构前先查捆绑 pdfium 的导出表（PE 字节搜索函数名），有 `FPDF_GetMetaText` 不代表有 `FPDF_SetMetaText`；pdfium 全量/增量保存都会按内存视图重写 Info，任何绕过 pdfium 的字节级编辑必须像 `OutlineOverride` 一样挂 override 在每次 Save 后重放；增量更新对象号直接用 `reader.Size`、trailer `/Size=Size+1`；trailer 解析沿 /Prev 从最新回溯，「首个出现」即最新语义。

## 2026-11-11 V1.2.064

**动效｜用 iOS 流畅丝滑风格替换 macOS 动效**

- 背景：用户要求把「mac os 动效」换成仿 iPhone iOS 桌面与文档操作的流畅丝滑手感。
- 改动：`AnimationSet.Mac` 改名为 `AnimationSet.iOS`（值 0 不变；prefs.json 以整数存储枚举，旧配置兼容），默认 `AppPrefs.AnimSet` 改为 iOS；首选项单选 `RbAnimMac`→`RbAnimiOS`、文案「Mac OS 风格」→「iOS 风格」；`LayoutAnim.IosSpringEase` 曲线由 `1-e^(-7t)cos(7.6t)` 改为 `1-e^(-11t)cos(10t)`，过冲由约 5.6% 降到约 3%（iOS 式弱回弹，去除弹跳感）；`IosDecelerate` 四次缓出保持。翻页与文档交叉淡化本就用 `Decel`/`Smooth`（无回弹），不动。
- 经验：枚举改名前先确认序列化方式——本项目用 System.Text.Json 默认（枚举按整数），故改名不破坏旧 prefs；若用 `[JsonStringEnumConverter]` 则旧名字会反序列化失败。`<RadioButton x:Name>` 改名要同步 XAML 与 .cs 两处引用，生成的 .g.cs 会随 XAML 重建。把"弹跳"降为"弱回弹"只需调阻尼/频率比 a/b≈1.1（过冲≈e^(-aπ/b)），比直接换曲线更可控。

## 2026-11-11 V1.2.063

**样式｜所有方形色块改为圆形**

- 诉求：把软件里所有的方形色块换成圆形。
- 改动：遍历所有 `Background = new SolidColorBrush(...)` 的颜色色块，把 `CornerRadius` 设为边长一半（正方形色块即变正圆）。不同源的色块：首选项 11 列面板与「颜色风格」统一由 `PreferencesDialog.BuildColorRow` 的 `CornerRadius = new CornerRadius(chipSize / 2.0)` 一处解决；MainWindow 注释列表下拉项(16×16)与条目色块(12×12)、工具栏 ColorPopup 调色板(填充 25×25 单元，CornerRadius 12.5)、PdfPageView 取色弹层「当前颜色」(40×16→24×24)；TextInputDialog / StampStyleDialog / MarkupStyleDialog / FreeTextEditDialog 的预览块(22×22)与 BuildChip 色块(22×22 / FreeText 18×18)。工具栏 ColorSwatch 由 `<Rectangle RadiusX/Y=2>` 改为 `<Ellipse>`。生成代码 MainWindow.g.cs 自动随 XAML 把 ColorSwatch 字段由 Rectangle 改为 Ellipse，后台只用 `.Fill` 不受影响。
- 经验：批量把色块改圆形优先找共用构造器（BuildColorRow / BuildChip）一处改全；XAML 里 `<Rectangle>` 改 `<Ellipse>` 不用 RadiusX/Y；确认引用处只用 Shape 公共属性（如 Fill）而非具体类型，否则生成的 .g.cs 会断。

## 2026-11-11 V1.2.062

**移除｜删除「云朵」「多边形」标注工具**

- 诉求：删除云朵与多边形两种标注类型。
- 改动：`ToolMode` 枚举移除 `Polygon`/`Cloud`；`ContextToolCatalog` 移除对应目录项；`App.xaml` 移除 `Geo.Polygon`/`Geo.Cloud`；`PdfPageView` 移除鼠标按下(Cloud 拖拽 / Polygon 逐点)、移动、抬起(Cloud)三条绘制分支与 `UpdateShapePreview` 的云朵真实轮廓预览分支，并整段删除不再使用的 `FinishPoly`/`UpdatePolyPreview` 与 `_polyPoints` 字段；`MainWindow` 移除形状组弹出菜单的多边形 / 云朵项、`IsShapeGroupTool` 判定两项、工具栏颜色表两项；`MainWindow.xaml` 形状组按钮 ToolTip 改为「线条 / 箭头 / 矩形 / 圆」、图标由被删的 `Geo.Polygon` 改为保留的 `Geo.Rect`。专用几何类 `Controls/CloudGeometry.cs` 删除。
- 经验：删除共享绘制体系中「上层」工具时，要顺带清理它独占的辅助方法 / 字段与独立几何类，否则留下死代码；图标若直接引用被删的 `StaticResource`，XAML 编译期不报错（运行时才缺资源），务必同时替换；枚举删值要核查是否有整数序列化。

## 2026-11-11 V1.2.061

**移除｜删除「连接的线条」（Polyline）标注工具**

- 背景：用户要求删除该标注类型。它与多边形共用逐点点击绘制链路（顶点缓存 `_polyPoints`、`FinishPoly(closed)`、`UpdatePolyPreview`），仅闭合行为不同。
- 改动：仅摘除 Polyline 分支，保留多边形。枚举 `ToolMode.Polyline` 删除（后续枚举值顺移，不持久化整数值故无影响）；`ContextToolCatalog` 目录项、`App.xaml` 的 `Geo.Polyline`、`PdfPageView` 两处 `case ToolMode.Polyline`、`MainWindow` 形状组菜单项 / `IsShapeGroupTool` 判定 / 工具栏颜色表 / 形状按钮 ToolTip 一并移除。
- 经验：删除「共用一半逻辑」的工具时，先确认另一半（此处为多边形）仍被保留且引用完整；枚举删值要核查是否有整数序列化；XAML 里的 ToolTip 文案也容易漏改。

## 2026-11-11 V1.2.060

**新增＋修复｜取色弹层当前色块 / 点不透明度滑块后编辑框跳位（用户截图反馈）**

- 诉求：截图两个红框——标题「椭圆颜色」文字后的空位希望放「当前使用的色块」；点击不透明度滑块时编辑框会跳到另外的位置。
- 跳位根因：`Controls\PdfPageView.cs` 的 `FlushOpacity` 在拖动结束 120ms 后调用 `Document.SetAnnotOpacity`（文本标记是「删除重建」，新标注追加到 `/Annots` 末尾），随后 `RenderAsync()` 在渲染完成的续跑里调 `DrawAnnotSelection()`，后者移除并重建整个快捷操作条。于是：
  1. `Popup` 的 `PlacementTarget = btn` 指向被销毁的旧按钮 → 弹层失去锚点、跳到默认位置；
  2. 只有局部变量 `annotIndex` 接住了删除重建返回的新索引，`_selAnnot` 仍是旧值 → 覆盖层按旧索引取标注，选中框 / 快捷条画到别处。
- 改动：
  1. 标题行由单个 `TextBlock` 改为两列 `Grid`，右列加 `currentSwatch`（`Border`，40×16、圆角 3、主题边框），背景取 `dot.Fill`；色板改色回调里同时更新 `dot.Fill` 与 `currentSwatch.Background`。声明必须放在色板 lambda 之前，否则 C# 报 `CS0841`（局部变量在声明前被闭包使用）。
  2. `Popup` 改为 `PlacementTarget = this`（稳定的页面视图）+ `PlacementRectangle = new Rect(anchor.X, anchor.Y, size, size)`，`anchor` 由 `btn.TransformToVisual(this)` 得到；`PlacementMode.Top` 与 `StaysOpen=false` 不变。
  3. `SetAnnotOpacity` / `UpdateTextMarkupStyle` 返回的新索引在 `_selAnnot >= 0` 时同步回 `_selAnnot`。
- 经验：WPF `Popup` 的 `PlacementTarget` 不要指向会被重建的临时控件，应锚定稳定父容器 + `PlacementRectangle` 固定位置；任何「删除重建」标注的操作，除了返回新索引给调用链，还要同步 UI 的选中状态字段，否则覆盖层会按旧索引错位。

## 2026-11-11 V1.2.059

**优化｜云朵标注轮廓平滑化（用户截图反馈「云朵标注有点丑，请帮忙平滑处理和优化」）**

- 现象：红色云朵上下边是一串尖三角锯齿（每个鼓包一个尖峰），左右两侧与四角还有硬折线，整体不像圆弧云朵。
- 根因：PDF 的 INK 标注只存点序列，pdfium 用直线段连接。`PdfPageView.MakeCloudStroke`（V1.2.050）每个鼓包只采样 **4 段**二次贝塞尔，且控制点外推 1.4×弦长使顶点外凸 0.7×弦长 → 4 条直线画出来就是尖峰；四条边各自从角点开始铺鼓包、角上直接相接，相邻两边的外凸方向垂直，撞出直角折线。
- 改动：
  1. 新增 `Controls\CloudGeometry.cs`，把轮廓生成抽成纯函数。鼓包改为**半圆**（`radius = step/2`，外凸 0.5×弦长），采样数按 `clamp(ceil(radius/1.2), 8, 16)` 自适应，弦误差远小于线宽；相邻鼓包、直边与角圆弧共用端点时去重。
  2. 四角用二次贝塞尔圆角过渡（控制点取角点），半径 `min(chord*0.55, 短边/5)`——比鼓包半径略小，既不留长直线段，也让四条边的直段长度更接近 chord 整数倍，四边鼓包大小一致。
  3. `PdfPageView.cs` 删除旧 `MakeCloudStroke`；云朵落地改调 `CloudGeometry.MakeStroke(rc)`，并在 `UpdateShapePreview` 增加 Cloud 分支，用同一轮廓画真实云朵预览（原来只画虚线矩形）。
- 验证：`CloudProbe` 探针通过 `Compile Include` 直接编译主项目 `CloudGeometry.cs`，并排渲染 320×120 的旧 / 新轮廓：旧 121 点、尖锯齿 + 直角折线（复现截图）；新 351 点、半圆鼓包圆润且四边尺寸一致、四角平滑。
- 经验：PDF INK 想画曲线只能靠密集采样，采样密度要按曲率半径算（每 1.2pt 左右一个点）而不是固定段数；把纯几何抽成独立无依赖的类后，探针可以直接链接真实源码渲染验证，不必复刻算法。

## 2026-11-11 V1.2.058

**修复｜滚动条滑块端头是尖的（用户截图反馈「滚动条比较尖」）**

- 现象：2002 页文档右侧的小滑块两端是尖的（橄榄形），不是 Adobe 参照图里端头半圆的钝胶囊。放大截图右侧滚动条可见一个上下收尖的灰色小条。
- 根因：`Rectangle.RadiusX` / `RadiusY` 被 WPF **分别**钳制到 `Width/2` 与 `Height/2`，不是统一钳到短边一半。细长滑块（约 6.5×28px）于是得到半径约 (3.25, 14) 的半椭圆圆角，上下端收尖。V1.2.055 误判了这一点，把 `Border CornerRadius` 换成了 `Rectangle 999`；V1.2.057 把滑块缩到 28px 后，尖形更明显。
- 验证：`CornerProbe` 无头渲染（`RenderTargetBitmap`）并排渲染 8×28 的 `Border CornerRadius=4.25` 与 `Rectangle RadiusX/Y=999`：左为端头半圆胶囊、右为尖头橄榄形，完整复现截图。
- 改动：`App.xaml` 滑块改回 `Border` + `CornerRadius="{DynamicResource Th.ScrollBarRadius}"` + `Background="{DynamicResource Th.Icon}"`，并订正两处注释；轨道、28px 最小长度、`MinThumbTrack` 都不变。
- 经验：WPF 做胶囊要用「四角同半径」的 `Border.CornerRadius`；`Rectangle` 的 `RadiusX/RadiusY` 是两个独立轴，给 `999` 这类超大值在细长矩形上必然变成尖椭圆。判断端头形状时，把控件单独渲染放大比反复调数值直观。

## 2026-11-11 V1.2.057

**调整｜滚动条滑块尺寸对齐 Adobe（用户截图反馈「按照这个尺寸显示就可以」）**

- 现象 / 诉求：V1.2.056 把长文档滑块的最小长度恢复到 50px，比 Adobe Reader 打开 2000 页文档时的小胶囊明显偏长；用户给出 Adobe 截图（红框圈出滑块）作为尺寸参照。
- 测量：原图 1920×975，红框区域 8 倍放大后量得滑块约 8×36 物理像素（长宽比约 4.5:1）。我们轨道宽 8.5px、滑块减 `Margin=1` 后约 6.5px，按同一比例应为约 29px，取 28px。
- 改动：`App.xaml` 的 `ctrl:MinThumbTrack MinThumbLength` 50→28；`Controls\MinThumbTrack.cs` 的默认值 50.0→28.0。钳制公式 `viewport >= L × range / (trackLength - L)`、胶囊画法、轨道宽度均不变。
- 说明：该值只是下限，长文档（按可视比例算出的滑块短于 28px）才生效；侧栏等短内容仍按原比例显示长滑块。

## 2026-11-11 V1.2.056

**优化｜长文档滚动条滑块缩成小点（用户截图反馈：红框内是侧栏长滑块，箭头指向文档区小点）**

- 现象：主文档区（820 页）的滚动条只剩几像素的小点，侧栏内容少时却是一条长滑块。V1.2.055 去掉 `Thumb` 的最小长度后完全按可视比例显示，长文档下几乎抓不住。
- 根因 / 约束：`Track` 按 `ViewportSize / (Maximum - Minimum + ViewportSize)` 分配滑块槽位。V1.2.051 用 `Thumb.MinHeight=50` 造最小长度，但槽位没变，`DesiredSize` 超过槽位触发 `layout clip` 裁掉下半段（即 V1.2.055 修的「上圆下方」）；直接去掉下限又让滑块过小。改「计算输出」和放弃下限都不对。
- 改动：
  1. 新增 `Controls\MinThumbTrack.cs`：继承 `Track`，`ViewportSizeProperty.OverrideMetadata` 挂 `CoerceValueCallback`，按下式钳制下限：`viewport >= minLength × range / (trackLength - minLength)`，使计算出的 `thumbLength >= minLength`（默认 50px）。`OnRenderSizeChanged` 与 `Maximum`/`Minimum`/`Orientation` 变化时重新 Coerce；轨道比最小长度还短、或范围无效时不钳制。
  2. `App.xaml`：`PART_Track` 换成 `ctrl:MinThumbTrack MinThumbLength="50"`（`xmlns:ctrl="clr-namespace:PdfReader.Controls"`），滑块仍是 `Rectangle RadiusX/Y=999`。
- 验证（无头渲染探针，编译真实 `MinThumbTrack`）：820 页 / 视口 1 页 → `trackVp=117`、`thumbH=50`、`clip=null`；末端 `Value=Maximum` → `thumbY=350`、`bottom=400/400` 不溢出；内容少 → `trackVp=2`、`thumbH=160` 不强行撑到 50；渲染图为上下都圆的完整胶囊。
- 经验：WPF 里要改滚动条滑块的最小长度，应改「计算输入」（`Track.ViewportSize`）而不是「计算输出」（`Thumb.MinHeight`）。输入被钳制后槽位、位置、拖动换算全部自洽，也不会产生 `layout clip`；`Track` 的 DP 可以用 `OverrideMetadata` + `CoerceValueCallback` 无侵入地改造。

## 2026-11-11 V1.2.055

**修复｜小尺寸滚动条滑块只有上半部分有圆角（用户截图反馈）**

- 现象：内容较长、滑块很短时，灰色滑块顶部两角是圆的，底部两角却是直角，像是被切掉了一半。
- 排查：搭了一个无头 WPF 渲染探针（`RenderTargetBitmap` + `VisualTreeHelper.GetClip`）复现 6 组配置，关键数值：
  - `MinHeight=50` + `Border CornerRadius=4`：`thumbH=50`、`clip=0,0,16.8,9.76` → 上圆下方，与截图一致。
  - `MinHeight=50` + `Rectangle RadiusX/Y=999`：clip 完全相同 → 仍是上圆下方，证明「换 Rectangle」这条思路无效。
  - 去掉下限（`Border` 或 `Rectangle`）：`thumbH=9.8`、`clip=null` → 上下都圆，完整胶囊。
  - `Track.ViewportSize=25` 在模板未显式绑定时也会由 `ScrollBar` 同步过来，滑块长度按 `ViewportSize / (Maximum - Minimum + ViewportSize)` × 轨道长度计算。
- 根因：`Track` 只按上述比例给 `Thumb` 分配槽位，不会为 `Thumb.MinHeight` 预留空间。`MinHeight=50` 让 `DesiredSize` 远大于槽位后，`FrameworkElement` 会生成 `layout clip` 把超出部分裁掉，于是只能看见滑块的顶部一小截；底部圆角本来在 50px 高的末端，正好落在裁剪区外。V1.2.054 只修了 `MinWidth` 撑宽，没意识到 `MinHeight` 同样在破坏布局。
- 改动：
  1. `App.xaml` 的 `ScrollBar` 模板移除 `Thumb` 的 `MinHeight="50"`、`x:Name="ThumbEl"`，以及 `Orientation=Horizontal` 触发器里的 `MinHeight`/`MinWidth` 两个 Setter。
  2. 滑块视觉由 `Border CornerRadius="{DynamicResource Th.ScrollBarRadius}"` 改为 `Rectangle RadiusX="999" RadiusY="999"`：WPF 把半径统一钳制到短边一半，不依赖固定圆角值，任意滑块长度都是四角对称的胶囊。轨道继续用 `Th.ScrollBarRadius`。
- 经验：WPF 里靠 `Track.Thumb` 的 `MinWidth`/`MinHeight` 做「最小滑块长度」不可行——`Track` 不给它预留空间，超出槽位就被自动裁剪。遇到控件「只画一半 / 少一个圆角」，先查 `VisualTreeHelper.GetClip(visual)` 与 `DesiredSize` vs `ActualHeight`，比反复调 `CornerRadius` 有效得多。

## 2026-11-11 V1.2.054

**修复｜竖直滚动条滑块被撑成宽白块（用户截图反馈「宽度有问题」）**

- 现象：侧栏 / 文档区的竖直滚动条上出现一条明显过宽的浅色长条，与细条宽不符。
- 根因：V1.2.051 为「滑块太短难抓取」给 `Thumb` 同时加了 `MinHeight="50" MinWidth="50"`。WPF 布局时 `MinWidth` 会钳制滑块的**最终宽度**，竖直滚动条的滑块于是被撑到 50px 宽（轨道只有 `Th.ScrollBarWidth`，约系统默认 17px 的 0.5 倍 ≈ 8.5px），溢出成宽白块。V1.2.053 的胶囊圆角放大了这个视觉异常。
- 改动：
  1. `App.xaml` 的 `ScrollBar` 模板：滑块默认只设 `MinHeight="50"`，宽度不设下限、完全跟随轨道；在 `Orientation=Horizontal` 的 `ControlTemplate.Triggers` 里改设 `MinWidth="50"`、`MinHeight="0"`（给 `Thumb` 加 `x:Name="ThumbEl"` 供 Setter 引用）。
  2. 胶囊圆角不再用 `CornerRadius="999"` 依赖 `Border` 自动钳制：`ThemeManager` 新增 `Th.ScrollBarRadius = new CornerRadius(min(vw, hh) / 2)`（取条宽/条高较小者的一半），轨道与滑块的 `CornerRadius` 都绑定该动态资源，端头正好半圆且随系统参数缩放。
- 经验：WPF 中给 `Thumb` 设 `MinWidth`/`MinHeight` 必须区分滚动条方向——竖直条的「最小长度」是高度，水平条才是宽度；两个一起设会让短边也被撑大。胶囊圆角优先用「短边一半」的精确值，别依赖超大 `CornerRadius` 的隐式钳制。

## 2026-11-11 V1.2.052

**修复｜点击标注快捷条的圆圈色块直接卡死（用户截图反馈）**

- 现象：选中文字/标注后，点击快捷操作条上的圆形取色色块，整个界面立即失去响应。
- 根因（V1.2.049 引入的回归）：`Controls\PdfPageView.cs` 的 `MakeColorSwatch` 在不透明度行改为 Adobe 两行布局时，新增了 `opRow.Children.Add(opLabel)` 与 `opRow.Children.Add(sliderRow)`，但**没有删除旧布局末尾的三行**：
  ```
  opRow.Children.Add(opLabel);
  opRow.Children.Add(sliderHost);
  opRow.Children.Add(opText);
  ```
  WPF 的 `UIElementCollection.Add` 会先把元素从原父容器移出：`sliderHost`/`opText` 从 `sliderRow`（Grid 的两列）被抢到 `opRow`（StackPanel），`opLabel` 被重复挂载。于是 `sliderHost.SizeChanged` → `UpdateVisual()` 改 `thumb.Margin` → 布局再次变化 → `SizeChanged` 再次触发，形成无限布局回环，UI 线程 100% 占用。点击色块时才构建弹层，故表现为「点击即卡死」。
- 改动：
  1. 删除重复挂载的三行，`opRow` 只含 `opLabel` + `sliderRow`，`sliderRow` 只含 `sliderHost` + `opText`。
  2. 防抖计时器 `renderTimer` 原本声明为 `null` 且从未实例化（`SetVal` 里 `renderTimer!.Stop()` 必抛 `NullReferenceException`）：现在真正实例化 `DispatcherTimer(120ms)`；`SetVal` 只更新百分比文字/滑钮位置并写入 `pendingOpacity`，由 `FlushOpacity()` 在 `Tick` 或弹层 `Closed` 时落地一次 `SetAnnotOpacity` + `RenderAsync`。拖动时不再每移动一次就做一次「删除重建」标注（同步 UI 线程、极重）。
  3. `popup` 由 `PdfPageView` 的共享实例字段改为 `MakeColorSwatch` 内的局部变量 `swatchPopup`（每个色块按钮独立），打开前先关掉上次残留弹层，避免多个 `StaysOpen=false` 的 Popup 同时抢鼠标捕获导致假死。
  4. 色板点击改色接收 `UpdateTextMarkupStyle` 返回的新标注索引（此前只有透明度路径修过），避免连续改色指向错误标注。
  5. `Native\Pdfium.cs` 的 `FPDFAnnot_GetStringValueByKey` 对原生返回的 `num` 增加 64KB 上限：读取不存在的冗余键时若返回异常长度，原先会按 `num + 2` 分配巨型数组（`ulong` 溢出），加一道兜底。
- 经验：WPF 中「同一 UIElement 被挂到两个父容器」不会抛异常，而是静默重父化；若该元素带 `SizeChanged` 回调且回调里改布局，就会形成无限布局回环。改控件树结构时必须检查是否残留旧版的 `Children.Add`。自绘滑杆的拖动回调里不能放重量级同步操作（删除重建 + 渲染），必须防抖。

## 2026-11-11 V1.2.048

**新增｜「修改样式」对话框增加透明度设置（用户截图反馈）**
- 需求：截图中的「修改样式」对话框（颜色调色板 + 线厚度 0.5/1/2）希望增加不透明度设置。
- 改动：`Dialogs\MarkupStyleDialog.cs` 新增不透明度行（标签 + 自绘滑杆 + 百分比），与 `PdfPageView.MakeColorSwatch` 的自绘滑杆同风格：Grid 宿主 150×16、5px 圆角轨道（`Th.Border` 50% 透明）、当前所选颜色的填充段（点击色块联动换色）、14px 圆滑钮（`Th.PanelBg` 底 / `Th.Border` 描边 / 投影）；点击捕获鼠标跳转、拖动连续调值、`SizeChanged` 重排。`Show` 增加 `ref double opacity` 与 `bool showOpacity`（形状/墨迹不显示该行），`ResultOpacity` 带出结果。
- 调用链：`EditMarkupStyle` 读取 `GetTextMarkupStyle` 的三元组 `(Color, Width, Opacity)`，确定时把 opacity 传给 `UpdateTextMarkupStyle`；调色板改色 / 文本输入改色两处也改为透传原 opacity，避免被重置为 100%。

**修复｜线厚度设置不起作用（同批根因排查）**
- 排查：用无头探针（`d:\SW with codebuddy\_RenderProbe_Tool`，Program.cs 已改为本轮实证程序）逐项验证本机 `pdfium.dll`：
  - `SetBorder(0,0,4)` 写入回读成功，但下划线渲染仍 1pt → **文本标记 AP 忽略 `/Border`**（只认 `/BS /W`，本机无 dict 写 API）。
  - 导出表解析（471 个导出）：**没有** `FPDFPage_GenerateAP` / `FPDFAnnot_GenerateAppearance` / `FPDFAnnot_SetFloatValue` / `FPDFAnnot_GetFloatValue`；`FPDFAnnot_SetAP` 恒返回 0；`FPDFAnnot_AppendObject` / `RemoveObject` 对文本标注返回 0（`GetObjectCount` 能读到 1 个自动 AP 对象但改不了）。
  - 实证可行路径：`SetColor` 的 alpha 会被本版 AP 生成采用（alpha=128 → 渲染为半透明）；同一标注内**复制 quad** 可叠加线厚（3 条 1pt 间隔 quad → 3pt 线）。
  - 另实证 `SetColor(alpha)` / `SetRect` / `SetBorder` 对**已生成** AP 都不会触发重生成，透明度必须删除重建。
- 改动：`Pdf\PdfDocument.cs`
  - `UpdateTextMarkupStyle` 增加 `opacity` 参数：颜色 alpha = `opacity*255`（下限 5%）；线厚 > 1.5pt 时对下划线/删除线/波浪线按 1pt 间隔向下复制 quad（2 条）；写 `PdfReaderOpacity` 冗余键；`/Border` 仍写以供其它阅读器回退。
  - `GetTextMarkupStyle` 返回 `(Color, Width, Opacity)`，从冗余键回读不透明度。
  - `GetAnnotOpacity/SetAnnotOpacity` 去掉对缺失导出的调用：改读/写 `PdfReaderOpacity`，文本标记走 `UpdateTextMarkupStyle` 删除重建，其它类型尽力写颜色 alpha —— 修复 V1.2.037 起取色弹窗透明度静默失效（异常被 catch 吞掉）。
  - `Native\Pdfium.cs` 移除失效的 `FPDFAnnot_Set/GetFloatValue` 声明并留警示注释。
- 安全性：`FPDFPage_CreateAnnot` 把新标注追加到 `/Annots` 末尾，索引会变。`UpdateTextMarkupStyle` / `SetAnnotOpacity` 改为返回新索引（在 `ReleasePage` 前用 `FPDFPage_GetAnnotCount(page)-1` 取值），取色弹窗连续拖动透明度时回写捕获的 `annotIndex`，避免后续拖动/改色指向错误标注。
- 经验：第三方原生库的功能缺失不能靠"函数名看起来存在"判断，应解析 PE 导出表 + 无头渲染探针实证；对无法写字典键的 pdfium 构建，可用「quad 复制」与「颜色 alpha」这类受支持的间接手段实现线厚与透明度。

## 2026-11-10 V1.2.047

**美化｜取色弹窗不透明度滑杆与程序风格不符（用户截图反馈）**
- 反馈：弹窗内 WPF 默认 Slider（浅灰粗轨 + 大方块滑钮）在深色弹窗里非常突兀。
- 改动：`PdfPageView.cs` `MakeColorSwatch` 中删除 `Slider`，改为自绘滑杆（Grid 宿主 16px 高 + `Th.Border` 50% 透明 5px 圆角轨道 + `SolidColorBrush(current)` 即当前标注色的填充段 + 14px `Ellipse` 滑钮，`Th.PopupBg` 填充 / `Th.Border` 描边 / 柔和投影）。交互自实现：`MouseLeftButtonDown` 捕获鼠标 + 按位置取值（点击跳转）、`MouseMove` 捕获期间连续取值、`MouseLeftButtonUp` 释放、`SizeChanged` 重排视觉；值域 5–100，`SetVal` 更新 % 文本 + 写 `SetAnnotOpacity` + 200ms 防抖渲染。
- 经验：WPF 默认控件模板在自绘弹窗中观感割裂时，轻量自绘（轨道+填充+滑钮三层）比写整套 Slider ControlTemplate 更省事；局部函数 + 闭包即可承载状态，无需新控件类。

## 2026-11-10 V1.2.046

**修复｜删除图标悬停移开后一直保持红色**
- 现象：快捷条刚弹出时删除垃圾桶为正常文字色，悬停变红底白图标，鼠标移开后图标持续为红色不复位（用户提供截图）。
- 根因：V1.2.044「删除图标去红」时用 `replace_all` 只命中了 `MakeQuickButton` 里初始化那一处 `SetResourceReference`（old_str 携带的注释行仅存在一份），而 `MouseLeave` 处理器内还有一处同表达式 `a.Danger ? "Th.Danger" : "Th.Text"` 未改——移开后把图标描边重设回警示红，覆盖悬停的白色本地值。
- 改动：`PdfPageView.cs` `MakeQuickButton` 的 `MouseLeave` 复位逻辑改为统一 `SetResourceReference(StrokeProperty, "Th.Text")`，与初始化一致。
- 经验：对同一行多处出现的代码做 replace_all 时，若 old_str 绑定了仅存在一份的上下文（如注释行），实际只会替换一处；替换后应全局搜索残留引用确认。

## 2026-11-10 V1.2.045

**调整｜颜色弹窗色点再放大（UI 观感）**
- 反馈：取色弹窗的圆点还想更大一点。
- 改动：`PdfPageView.cs` `MakeColorSwatch` 色板循环里色块 `Border` 边长 `20.0 → 24.0`、圆角 `10.0 → 12.0`（保持正圆）、间距 `3.0 → 4.0`。弹窗自适宽，标题行与不透明度行布局不受影响。

## 2026-11-10 V1.2.044

**调整｜删除垃圾桶图标不要红色（UI 观感）**
- 反馈：删除图标常驻红色与期望不符。
- 改动：`PdfPageView.cs` `MakeQuickButton` 中图标描边的 `SetResourceReference` 由 `a.Danger ? "Th.Danger" : "Th.Text"` 改为统一 `Th.Text`（初始化与 MouseLeave 两处）；删除类图标默认不再红色，与编辑/取色图标同色；`a.Danger` 仍控制悬停红底 + 白图标强调。注：图章/标注的 `SetAnnotColor` 真红填充不在快捷条图标范畴。

## 2026-11-10 V1.2.043

**调整｜颜色弹窗快捷色块圆角放大为正圆**
- 反馈：取色弹窗里的色块圆点半径希望更大（当前圆角矩形 radius 4）。
- 改动：`PdfPageView.cs` `MakeColorSwatch` 色板循环里每个色块 `Border.CornerRadius` 由 `4.0` 改为 `10.0`（20px 边长 → 正圆）；尺寸 20px、间距 3px、选中描边/勾选逻辑不变。
- 清理：顺带消除不透明度 `DispatcherTimer.Tick` lambda 的 CS8622 空性警告（`object _` → `object? _`，匹配 `EventHandler` 的 `object? sender`）。

## 2026-11-10 V1.2.042

**调整｜删除图标细化为带盖垃圾桶（iconfont 参考图）**
- 需求：按 iconfont「删除」搜索页选中的图标样式（盖沿宽于桶身的带盖垃圾桶）调整现有垃圾桶图标。
- 改动：`PdfPageView.cs` `IconTrash` 常量替换：盖沿 `M 4.5,6.5 L 19.5,6.5`（宽于桶身 2.5px 外扩）；提手 `M 10,6.5 L 10,3.5 L 14,3.5 L 14,6.5`（缩小为盖上小提手）；桶身 `M 7,9.5 L 7,20.5 L 17,20.5 L 17,9.5`（与盖留 3px 缝隙）；竖纹 `M 10.3,11.5 L 10.3,18` / `M 13.7,11.5 L 13.7,18`。描边 2.2、主题警示红、悬停红底白图标逻辑不变。

## 2026-11-10 V1.2.041

**调整｜编辑图标换为「方框 + 铅笔穿角」（iconfont 参考图）**
- 需求：按 iconfont「编辑」搜索页选中的图标样式（方框 + 铅笔斜穿右上角）替换现有钢笔尖编辑图标。
- 改动：`PdfPageView.cs` `IconPen` 常量替换为两段 path：① 方框 `M 16,4 L 4,4 L 4,20 L 20,20 L 20,8`（右上角留缺口）；② 铅笔 `M 10,14 L 11.2,10.2 L 19.2,2.5 L 21.5,4.5 L 13.8,12.8 Z`（45° 斜置、笔尖在框内）+ 笔身分隔线 `M 11.2,10.2 L 13.8,12.8`。仍为描边渲染（`IconPenStroke`=2.2，圆角连接），无填充，颜色跟随主题文字色。缺口端点 (16,4)/(20,8) 经核算与铅笔轮廓边缘（穿出点 x≈17.6/y≈6.6）留有约 1.5px 空隙，不会粘连。

## 2026-11-10 V1.2.040

**调整｜标注悬停虚线框整体外扩 2px**
- 反馈：悬停标注时的蚂蚁线虚线框希望整体外扩 2px（之前只在上下各扩 2px、左右贴边）。
- 改动：`PdfPageView.cs` 绘制悬停框的 `val3` 矩形由 `new Rect(val2.Left, val2.Top - 2, val2.Width, val2.Height + 4)` 改为 `new Rect(val2.Left - 2, val2.Top - 2, val2.Width + 4, val2.Height + 4)`，四边各外扩 2px。仅影响 hover 态 `_hoverBox`，不改变选中态 `selbox` 与绘制预览框。

## 2026-11-10 V1.2.039

**调整｜删除图标由圆圈 X 改为线条垃圾桶**
- 反馈：清除标注图标希望与 Adobe 一致的垃圾桶造型，而非圆圈 X。
- 改动：`PdfPageView.cs` `IconTrash` 常量由「圆 + 对角 X」替换为线条垃圾桶 path（24 网格：盖沿 + 盖提手倒 U + 桶身两侧竖线加底 + 桶内两道竖纹），沿用 `IconTrashStroke`=2.2 描边，颜色跟随主题（删除态 `Th.Danger` 警示红）。`MakeQuickButton` 悬停红底白图标逻辑不变。

## 2026-11-10 V1.2.038

**调整｜快捷条圆角仍偏大、按钮偏高（用户提供截图对照）**
- 反馈：V1.2.036 的圆角观感仍偏大，且按钮整体偏高，希望更接近 Adobe 的紧凑比例。
- 改动：`PdfPageView.cs` `BuildQuickActions` 缩放系数 K 由 1.92 降为 1.536（= 1.92 × 0.8，按钮 ≈27.6px、图标 ≈17.1px）；外层 Border `CornerRadius` 由 size/3 改为 size/4（≈7px，约为条高 1/6）；`MakeQuickButton` 与 `MakeColorSwatch` 按钮 Border `CornerRadius` 由 size/8 改为 size/10（≈2.8px）。取色弹窗与透明度功能不受影响。

## 2026-11-10 V1.2.037

**改进｜标注取色弹窗对齐 Adobe（标题 + 色块 + 不透明度滑杆）**
- 需求：快捷条取色弹窗按 Adobe Acrobat 样式分层——第一行标注类型标题、中间快捷色块、底部不透明度设置（用户提供截图）。
- 实现：① `PdfPageView.MakeColorSwatch` 弹窗重构为 StackPanel：`AnnotColorTitle(_selSubtype)` 标题（1=便签/3=文本框/5=矩形/6=椭圆/9=高亮/10=下划线/11=波浪线/12=删除线/13=图章/15=墨迹）→ 21 色网格 → 「不透明度」行（Grid 三列：标签 / Slider 5–100 / 百分比）；② 透明度 API：`Pdfium` 新增 `FPDFAnnot_GetFloatValue/SetFloatValue`（byte[] key 带结尾 \\0），`PdfDocument.GetAnnotOpacity`（读 /CA，缺省 1.0）与 `SetAnnotOpacity`（/CA+/ca 双写 + 按 alpha 重写当前颜色触发外观流缓存重生成，0.05~1.0 钳制）；③ 滑杆 ValueChanged 实时写 /CA 更新 % 文本，`RenderAsync` 用 200ms `DispatcherTimer` 防抖；图章(subtype 13)颜色烘焙在位图、隐藏不透明度行；弹窗 `Closed` 停掉防抖计时器。
- 经验：改 /CA 后需触发外观流重生成才能立即生效——通过重写颜色（FPDFAnnot_SetColor）让 pdfium ClearCachedAppearance；写标注字典键要用 `Encoding.UTF8.GetBytes("CA\0")` 带结尾空字节。

## 2026-11-10 V1.2.036

**调整｜标注快捷条圆角过大，改为 Adobe 风格（UI 观感）**
- 反馈：快捷操作条整体为全胶囊形（外层半径 = size/2）、按钮悬停背景圆角 size/4，圆角过大，与 Adobe PDF 的选中工具条不符（用户提供 Adobe 截图对照）。
- 改动：`PdfPageView.cs` `BuildQuickActions` 外层 Border `CornerRadius` 由 `size/2.0` 改为 `size/3.0`（约容器高度 1/4 的中等圆角）；`MakeQuickButton` 与 `MakeColorSwatch` 按钮 Border `CornerRadius` 由 `size/4.0` 减半为 `size/8.0`。图标样式（描边钢笔/色点/红圈⊗）与 1.5x 尺寸（K=1.92）不变。

## 2026-11-10 V1.2.035

**回退｜标注快捷条图标恢复替代前描边样式（尺寸保留 1.5x）**
- 反馈：V1.2.034 的 SVG 图标观感不佳，要求恢复替代前样式，尺寸不动。
- 改动：`PdfPageView.cs` `BuildQuickActions` 的五处编辑图标引用与删除图标引用改回 `IconPen`/`IconTrash`（描边常量，`IconPenStroke`/`IconTrashStroke`=2.2）；`MakeQuickButton` 恢复为单一描边 Path（移除 svg: 分支、半透明红底悬停等 SVG 专属逻辑）；`MakeColorSwatch` 恢复为显示当前标注颜色的圆形色块（含取色后 `dot.Fill` 回写），删除 V1.2.034 引入的调色板 SVG；删除内嵌 SVG path 数据常量（`SvgEditData`/`SvgDeleteCircleData`/`SvgDeleteXData`/`SvgColorBodyData`/`SvgColorLineData`/`SvgColorDotsData`）与 `MakeSvgIcon`/`ParseSvgPathData` 辅助方法。缩放系数 K 维持 1.92（=1.28×1.5），按钮 ≈34.6px，图标 1.5x 不变。

## 2026-11-10 V1.2.034

**调整｜标注快捷操作条图标换为用户 SVG + 放大 1.5x**
- 需求：`PdfPageView` 标注选中后的快捷操作条（编辑/颜色/删除）改用 temp 目录提供的三张 SVG，图标尺寸放大 1.5x。
- 实现：① SVG path 数据内嵌为常量（`PdfPageView.cs` 顶部 SvgEdit/SvgColor/SvgDelete 系列常量）；② 新增 `ParseSvgPathData`（正则补负号分隔符 `(?<=[0-9])-(?=[0-9])` → ` -`；FillRule 改 nonzero，与 SVG 默认一致，防止 X 交叉挖空）；③ 新增 `MakeSvgIcon`（1024×1024 Canvas 承载多路径 + Viewbox 等比缩放，保证多色路径相对位置）；④ `MakeQuickButton` 按 svg: 前缀分支（填充式 vs 描边式），悬停逻辑区分：描边删除钮红底白图标，SVG 删除钮用半透明红底；⑤ 取色钮由「显示当前颜色的圆点」换为调色板 SVG（点击仍弹 21 色色板，回调中移除 dot.Fill 回写）；⑥ 缩放系数 K 1.28→1.92（=1.28×1.5，按钮 ≈34.6px）。
- 经验：SVG→WPF 直接 Geometry.Parse 可解析 M/L/C/A/H/V/S 等命令，但需处理负号隐式分隔与 FillRule 差异；多路径彩色图标必须共享同一坐标系（Canvas+Viewbox），逐路径 Stretch.Uniform 会错位。

## 2026-11-10 V1.2.033

**调整｜图章默认两侧留白 80px → 120px（UI 观感）**
- 用户反馈图章两侧留白偏窄，要求加宽；用户选择从 80px 改为 120px（较 160px 收敛）。
- 改动：`Dialogs/StampFactory.cs` `RenderTextStamp` 公式 `formattedText.Width + 2.0*80.0 + 2.0*6.0 + 2.0*8.0` 的 `80.0` 改为 `120.0`；画布高度 160、边框 8、内缩 6 与文字垂直居中不变；宽度钳制 (160–760) 仍生效（空文字时最小宽约 268px）。

## 2026-11-10 V1.2.032

**修复｜注释筛选区显示不全（UI 裁切）**
- 现象：侧栏「注释」页签的筛选行（类型 74 + 作者 80 + 颜色 40 + 清除 44 + 间距 ≈ 247px 固定宽度横排）在较窄的侧栏里被裁切，下拉框文字截断、布局挤压（用户截图红框）。
- 根因：`MainWindow.xaml` 注释页签用 `StackPanel Orientation="Horizontal"` + 固定 `Width` 排布筛选控件，总宽超出侧栏默认宽度，超出部分被裁掉且不可见。
- 修复：改为 2×2 自适应 `Grid`（`ColumnDefinition Width="*"` 两列均分），类型/作者一行、颜色/清除一行，控件随侧栏宽度伸缩，任何宽度下完整显示；各控件 `MinHeight=24` 保持可点性。

## 2026-11-10 V1.2.031

**改进｜AI 大模型设置移入首选项 + 多模型管理 + 工具栏快捷分析**
- AI 设置从独立弹窗（`AiSettingsDialog`）整合进「首选项 ▸ AI 大模型」分类页，支持多模型预设增删与「工作模型」设定；接口地址 / Key / 模型名 / 温度 / 单文档字符上限保留。
- 数据模型：`AppPrefs.AiModels`（`List<AiModelEntry>`）+ `AiActiveModelId`；新增 `AiModelEntry` 预设类（Id/Name/BaseUrl/ApiKey/Model/Temperature）。旧单组字段（AiBaseUrl/AiApiKey/AiModel/AiTemperature）保留为工作模型镜像，`LlmClient` 不变。
- 迁移：`Upgrade` 增加 ConfigVersion<5，将旧单组配置（或默认）转为首个预设并设为工作模型，确保存量配置不丢。
- UI：新增 `Dialogs/AiSettingsPanel.cs`（UserControl，管理列表+编辑+工作模型）；`PreferencesDialog` 增加第 11 个分类项与 `PageAi` 页（ContentControl 承载面板），支持 `initialCategory` 定位；主窗口工具栏 `MainWindow.xaml` 增加 `AiAnalyzeBtn`（闪光图标，Click=OnAiAnalyzeCurrent）；`OnAiAnalyzeCurrent` 改为 RoutedEventHandler 签名以适配 XAML 绑定。
- 删除 `Dialogs/AiSettingsDialog.cs`；`MainWindow`「AI 大模型设置」菜单项与 `AIAnalysisDialog`「设置」按钮均改为打开首选项并定位 AI 页。

## 2026-11-10 V1.2.030

**新功能｜接入大模型 · 规格书智能分析与版本对比**
- 需求：在对比中引入 AI 大模型，阅读/分析 PDF 元器件规格书，整理关键指标与设计要点并自动生成 MD 报告；打开两版规格书对比参数优缺点。
- 实现：① `AppPrefs` 增加 `AiBaseUrl/AiApiKey/AiModel/AiMaxCharsPerDoc/AiTemperature`（OpenAI 兼容，云端与本地 Ollama 通用）；② 新增 `LLM/LlmClient.cs`（流式 SSE 解析，Bearer 鉴权，错误回带服务端信息）；③ `PdfDocument` 新增 `GetPageText`/`GetFullText`（按上限截断防超上下文）；④ 新增 `Dialogs/AiSettingsDialog.cs`（设置窗）；⑤ 新增 `Dialogs/AIAnalysisDialog.cs`（单份分析与两版对比，流式生成、复制、保存 .md）；⑥ 对比窗口工具栏加「AI 分析左/右/对比」；⑦ 主窗口「工具」扩展菜单加「AI 分析当前文档」「AI 大模型设置」。
- 设计取舍：本地桌面应用直接将 pdfium 抽取的文字送入模型（不上传 PDF 文件本身）；单文档字符上限默认 48k 以适配上下文。

## 2026-11-10 V1.2.029

**调整｜图章两端留白恢复 2x**
- 应要求撤销 V1.2.028 的回退：印章两侧留白从默认 28px 重新加宽到 2x（80px），画布宽度钳制回到 160–760（`StampFactory.RenderTextStamp`）。
- 影响范围：仅新放置与「修改样式」重渲染的印章；存量印章位图持久化在标注元数据（StampImage），显示不变。

## 2026-11-10 V1.2.028

**调整｜恢复图章默认视图尺寸**
- 应要求撤销印章两侧留白的两轮加宽（原始 28px → 40px → 80px，此前按用户要求实施），`StampFactory.RenderTextStamp` 两侧留白恢复默认 28px、画布宽度钳制恢复 120–600。
- 影响范围：仅新放置与「修改样式」重渲染的印章；存量印章位图持久化在标注元数据（StampImage），显示不变。

## 2026-11-10 V1.2.027

**Bug｜对比 / 分屏窗口左栏打开文档后不显示（整块土黄色）**
- 现象：左栏打开 PDF 后看不到页面，只显示一整块土黄色区域；右栏正常。V1.2.025 的 EnsureRendered 修复后仍复现。
- 根因：`CompareWindow` 构造布局时 `GridSplitter` 只设置了双向 `Stretch`，未调用 `Grid.SetColumn(splitter, 1)`，默认落入第 0 列（左栏所在列），整格渲染土黄色背景（#C9AE7A）并盖在左栏 `DocViewer` 之上（后添加的子元素 Z 序更高），同时拦截鼠标；右栏在第 2 列不受影响。
- 修复：捕获分隔条为局部变量并显式 `Grid.SetColumn(splitter, 1)` 放入 5px 分隔列。
- 教训：WPF Grid 子元素不显式 SetColumn/SetRow 时默认 0 行/列，Stretch 布局的覆盖型控件（Splitter 等）漏设即整格遮挡同格内容；代码构建 UI 时无 XAML 可视化核对，更易漏。

## 2026-11-10 V1.2.026

**Bug｜打开文档点击选中标注时卡死后崩溃退出**
- 现象：表单类文档（如 SGM822，HasForm=True）上用选择工具点击标注，UI 冻结数秒后进程崩溃退出；崩溃日志无托管异常记录。
- 定位：崩溃日志最后活动是 7 次悬停命中测试（`[annotcolor]`），点击本身零日志——冻结发生在 `OnMouseLeftDown` 最前端的表单派发 `RunExclusive` 内。检查该 P/Invoke：`FPDFAnnot_GetFormFieldAtPoint` 声明为 3 参，pdfium 真实为 4 参（hForm, page, x, y）。x64 下托管 3 参调用使 native 的 `page` 读到 RDX 寄存器残留垃圾并当作 `CPDF_Page*` 解引用——野指针 UB，死循环（冻结）或 AV（崩溃）随机出现。
- 验证：无头探针（`_RenderProbe_Tool\RenderProbe`）重放"表单派发→命中测试→取矩形→取色→渲染"30 轮：修复前版本不可直达（UB），修复后 4 参签名全部干净通过。
- 修复：`Native/Pdfium.cs` 签名补全 hForm；`PdfPageView.OnMouseLeftDown` 调用点传入 `Document.FormHandle`。并全量核对 `FPDFAnnot_*`/`FORM_*` 声明与 DLL 导出，无其他同类缺陷。

## 2026-11-10 V1.2.025

**Bug｜对比 / 分屏窗口打开文档后左右两栏都看不见内容**
- 现象：对比窗口工具栏正常、页数统计正常（文档已加载），但两栏只显示占位纸面，无页面内容。
- 根因：`PdfPageView` 的渲染是惰性的——构造/布局/SizeChanged 都不触发渲染，主窗口在 `RealizePage` 后显式调用 `EnsureRendered()`（滚动/跳转路径也各自调用）。而对比窗口的 `DocViewer.Realize` 只创建并摆放 `PdfPageView`，从未调用 `EnsureRendered`，`_bitmap` 恒为 null，页面永远停留在占位纸面。
- 修复：`DocViewer.UpdateVisible` 实例化视口内页面后统一调用 `EnsureRendered()`（`Realize` 改为返回实例以便复用）；因 `EnsureRendered` 内部按"位图缺失或比例变化"判断，缩放后重新进入视口的页面也会按新比例渲染，无需额外处理。

## 2026-11-10 V1.2.024

**构建｜消除 CA1416 警告**
- 现象：`FileAssociation.cs`/`ThemeManager.cs` 调用 `Registry.*` 等 Windows 专属 API，触发约 70 条 CA1416（“可在所有平台上访问此调用站点”）。
- 根因：V1.2.020 为修 WPF CS0579 关闭了 `GenerateAssemblyInfo`，SDK 不再自动生成程序集级 `[SupportedOSPlatform("windows")]`，使 CA1416 把这些调用当作跨平台可达而误报。
- 修复：在 `Properties/AssemblyInfo.cs` 补 `[assembly: SupportedOSPlatform("windows")]`（该文件已 `using System.Runtime.Versioning`），声明整个程序集仅 Windows 运行；CA1416 计数降为 0，无需逐处标注。

## 2026-11-10 V1.2.023

**调整｜撤销滚动条加宽**
- 用户反馈滚动条只需长度自适应、无需加宽。移除 V1.2.021 在 App.xaml 加的全局隐式 `ScrollBar` 样式（竖 34px / 横 34px），恢复默认滚动条宽度。

## 2026-11-10 V1.2.022

**Bug｜「对比 / 分屏查看」窗口菜单/工具栏看不清**
- 现象：暗色主题下打开对比窗口，顶部工具栏文字与背景几乎同色，按钮与状态文字难以辨认。
- 根因：`CompareWindow` 为纯代码构建，工具栏使用 WPF 默认 `ToolBar`——其控件模板配色固定为系统浅灰系，且 `ThemeManager` 只对窗口整体设置背景/前景，未覆盖 `ToolBar` 内部模板颜色，导致浅灰工具栏叠在主题底色上、默认黑字控件在暗色下不可读。
- 修复：弃用默认 `ToolBar`，改为 `Border`（`Th.PanelBg` 背景 + `Th.Border` 底边线）内嵌横向 `StackPanel`；按钮走 `Th.InputBg`/`Th.Text`/`Th.Border`，复选框前景 `Th.Text`，状态文字 `Th.TextMuted`，分隔符为 `Th.Border` 细线。全部使用 `SetResourceReference` 动态资源，主题切换/护眼模式实时跟随。

## 2026-11-10 V1.2.021

**需求｜滚动条太细不好抓，加宽 2 倍**
- WPF 默认竖向滚动条宽度为 17px（SystemParameters.VerticalScrollBarWidth），高 DPI 大文档下偏细。
- 处理：App.xaml 增加全局隐式 `ScrollBar` 样式，按 Orientation 分别设竖向 Width=34 / 横向 Height=34（2 倍），轨道与滑块随宽度自动拉伸。

## 2026-11-10 V1.2.020

**Bug｜特定 PDF（如 SGM61231.PDF）整页空白**
- 现象：打开该文件后页面全白（之前正常）。
- 定位：写无头探针（`RenderPageToBuffer` + 直接 P/Invoke pdfium）对比两条渲染路径，锁定根因——该文档 `FPDF_GetFormType=1`（有 AcroForm），渲染因 `_formHandle!=0` 走 `FPDF_FFLDraw`；但此文档的 AcroForm 与 pdfium 表单引擎不兼容，`FPDF_FFLDraw` 对其整页不绘制（探针实测非白像素 0），而 `FPDF_RenderPageBitmap` 正常（61371）。`FPDF_FFLLoadPage` 对该文档还会直接崩溃（进一步印证表单引擎不兼容）。手写 `FPDF_FORMFILLINFO` 布局与托管结构体均为正确的 v1 布局，非结构体封送错误。
- 修复：在 `PdfDocument.InitFormFill` 创建表单环境后做一次探测（对比第 0 页两路径非白像素），若判定该文档 `FPDF_FFLDraw` 渲染损坏（`_formDrawBroken`），`RenderPageCore` 改用 `FPDF_RenderPageBitmap` 渲染（内容可见，仅丢失该文档表单控件外观）；正常文档仍走 `FPDF_FFLDraw`，表单填充功能不受影响。

## 2026-11-10 V1.2.019

**Bug｜点击搜索结果只跳到含关键字的页面，而非定位到命中段落**
- 现象：查找/高级搜索命中点结果项，视图只落到该页顶部，未滚动到具体关键字段落。
- 根因：`GoToMatch` 仅调用 `GoToPage(hit.Page)`，而 `DocumentViewer.GoToPage` 实现为 `ScrollToVerticalOffset(_panel.TopOf(page))`——即该页顶部，不含"页内定位"。命中矩形在 `RunSearch` 时已算好（`_searchHitRects`），但跳转时未利用。
- 修复：文本命中（`hit.Start >= 0`）时改用新辅助 `ScrollToSearchRect(page, rects)`——将命中矩形包围盒在视口内垂直居中（横向仅在确有滚动空间时居中），复用 `RestoreAnchor` 的"页内点居中"算法（`TopOf + frac*HeightOf - viewport/2`）。注释/书签命中（无页内点）仍走 `GoToPage` 页顶。
- 关联修正：注释/书签命中此前不向 `_searchHitRects` 添加条目，使该数组与 `_searchHits` 下标错位，其后文本命中的高亮被 `SyncPageHighlights` 取错矩形；已对这两类命中补入空矩形保持并行。

## 2026-11-10 V1.2.018

**Bug｜打开多个文档后切换/关闭标签，进程原生崩溃（空白页伴发）**
- 现象：连续打开多个 PDF（含 829/2002 页大文档）后切换/关闭标签，进程直接消失；部分页面空白。
- 关键证据：`%TEMP%\xc-pdfreader-boot.log` 在「关闭标签」一行后戛然而止，无任何托管异常记录——说明是 AccessViolation 级别的原生崩溃（托管 try/catch、DispatcherUnhandledException、UnobservedTaskException 都拦不住也来不及记录）。V1.2.017 的托管层防护无效与此吻合。
- 根因（系统性审计 pdfium 原生层，五类问题）：
  1. **页句柄跨锁间隙（主嫌疑）**：大量方法"锁外 `GetPageHandle` → 锁内用句柄"或"锁 1 取 count、锁 2 用句柄遍历"，句柄横跨锁间隙；而注释总览/在位扫描（`StartAnnotPresenceScan` 等 `Task.Run`）每页扫完即 `ReleasePage`（内部 `FPDF_ClosePage`）。关标签→激活新标签→其覆盖层绘制（`GetFreeTextOverlayBorders/Text`、`GetAnnotAt`、`GetStampAt`）与扫描线程并发：扫描线程在间隙里关掉句柄 → UI 线程用野指针 → 原生崩溃。渲染路径安全只是因为渲染有 lease+pin，命中测试/覆盖层路径无任何保护。
  2. **先 `ReleasePage`(FPDF_ClosePage) 后 `finally { FPDFPage_CloseAnnot }`**（6 处）：FPDF_ClosePage 销毁页对象及标注列表，annot 句柄悬空，CloseAnnot 写已回收内存 → 必然 UAF（编辑标注内容/颜色/样式时 100% 触发，损坏可能延迟到之后任意一次分配时炸，与"开关几个标签后崩"表象吻合）。
  3. **表单调用完全无锁**：PdfPageView 的 `FORM_*`/`FPDFAnnot_GetFormFieldAtPoint` 与渲染线程的 `FPDF_FFLDraw`（持 `_lock`）并发进入 pdfium 表单引擎（非线程安全）→ 堆损坏；且 `fh/page` 是跨锁句柄，关标签退休后继续用 → UAF。
  4. **GetText 栈缓冲越界**：`stackalloc` 按 `min(count,65536)` 分配却传原始 `count`，字符数超限的页写穿栈。
  5. **退出顺序**：OnExit 直接 `FPDF_DestroyLibrary` 与在途任务并发 → 退出瞬间崩溃。
- 修复：①约 26 处"取句柄→用句柄"全部收进同一持锁区（双锁块合并 + 取句柄移入锁内，`Monitor` 可重入故锁内再调 `GetPageHandle` 安全）；②6 处 ReleasePage 移到 CloseAnnot 之后；③新增 `PdfDocument.RunExclusive(Action)`（锁内执行、`_doc==0` 静默跳过），PdfPageView 全部表单事件（按下/移动/抬起/键盘/输入/失焦）收敛进排他锁；④GetText 改传容量 `n`；⑤OnExit 先 `ShutdownDocuments()` 且移除 `FPDF_DestroyLibrary`。另：退休清理 `_pageToIndex`、保存回调约定 Stdcall→Cdecl 对齐头文件、空白页自愈重试加强至 20 次×400ms。

## 2026-11-10 V1.2.017

**Bug｜切换/关闭标签几次后程序崩溃（ObjectDisposedException / 未观察任务异常）**
- 现象：连续打开多个 PDF、来回切换/关闭若干标签后程序崩溃（偶发）。
- 日志证据：`%TEMP%\xc-pdfreader-boot.log` 记录 `未观察的任务异常: ... ObjectDisposedException: Cannot access a disposed object. 'PdfDocument'` → 堆栈 `PdfDocument.GetPageHandle → GetFreeTextOverlayBorders → PdfPageView.DrawFreeTextBorders → RenderAsync`。
- 根因：`RenderAsync` 是 `_ = RenderAsync()`（fire-and-forget，未被 await）。其位图渲染部分在 `Task.Run` 内、持有 lease 期间访问文档是安全的（lease 让文档退休而不立即关闭）；但位图渲染结束后 `RenderPageCore.finally` 已归还 lease，此时若标签被关闭导致文档彻底释放（`_doc==0`），紧随其后的覆盖层绘制（`DrawFreeTextBorders` 等）再次访问文档即抛 `ObjectDisposedException`。该异常未被任何 try/catch 捕获，作为未观察任务异常在 finalizer 线程重新抛出，进程终止。
- 修复：`RenderAsync` 尾部覆盖层绘制整体包进 try/catch（`ObjectDisposedException` 静默跳过，其余异常亦不向外抛出）；全局 `TaskScheduler.UnobservedTaskException` 处理器追加 `ev.SetObserved()`，作为纵深防御，确保即便仍有遗漏的未观察任务异常也不会终止进程。

## 2026-11-10 V1.2.016

**Bug｜打开多个文档，部分页面显示空白**
- 现象：连续打开多个 PDF 后，某些标签页（或某些页）只显示空白纸面，滚动/缩放后才恢复；左侧大纲与状态栏均正常。
- 根因：打开/切换文档时 `OpenFileCore` 用 `PdfDocument.BeginUiBatch()` 包住建页/大纲（UI 线程连续短调用，后台渲染让路）；`RenderPageCore` 在门未撤销时轮询等待 3 秒（200×15ms）后**主动放弃并返回 null**。`RenderAsync` 收到 null 只静默返回——而此时页面往往已在视口内，后续 `EnsureRendered` 不会再被触发（它只在实例化与滚动进视口时调用），页面就此永久空白。连续打开多个文档时各文档的批量门区间重叠，在途渲染大量放弃，命中概率最高。
- 修复：`PdfPageView.RenderAsync` 收到空渲染结果（无异常、无位图）时调度自愈重试——`ScheduleBlankRetry` 有限 8 次、间隔 250ms，在 UI 线程重调 `RenderAsync`；成功渲染后计数清零。UI 批量门撤销后首轮重试即恢复正常渲染；页面确实无法渲染时重试耗尽即止，不会无限循环。

## 2026-11-10 V1.2.014

**Bug｜双实例并发启动弹"启动失败"（IOException: 文件被另一进程占用）**
- 现象：已有实例运行时再启动一次（如双击 .pdf 触发第二个实例），弹出"启动失败"对话框，内容为 `System.IO.IOException: The process cannot access the file '...\Temp\pdfreader-boot.log' because it is being used by another process`，堆栈指向 `PdfReader.App.Log`。
- 根因：`App.Log` 用 `File.AppendAllText` 写 `%TEMP%\pdfreader-boot.log`，该方法内部以 `FileShare.Read` 打开；第二个实例转发参数路径上的多处 `Log(...)` 与首实例（或另一第二实例）的写入瞬间并发，占用冲突抛异常，异常发生在 `OnStartup` 的 try 内，被"启动失败"对话框捕获展示。
- 修复：改为 `new FileStream(path, FileMode.Append, FileAccess.Write, FileShare.ReadWrite)` 共享追加写，多实例可并发写同一日志（行间可能交错，属可接受的调试日志语义）；整个 `Log` 包 try/catch 静默，写日志永不抛异常、不再影响启动；日志文件名同步品牌改为 `xc-pdfreader-boot.log`（旧文件残留于 %TEMP%，可自行清理）。

## 2026-11-10 V1.2.013

**变更｜产品更名 CA PDF Reader → XC PDF Reader**
- 背景：统一品牌名，涉及程序集 / 可执行文件名、窗口标题、关于窗口、文件关联与 OCR 缓存目录等显示与文档。
- 说明：本次为产品更名与版本同步（V1.2.012 → V1.2.013），无缺陷修复；历史 Bug 记录保持原样。

## 2026-11-09

**Bug｜保存时在文档目录生成 .bak 备份文件**
- 现象：每次在原 PDF 上保存注释（Ctrl+S / 自动写回）都会在该 PDF 旁边多出一个同大小的 `xxx.pdf.bak`，长期积累污染文档目录。
- 根因：`PdfDocument.Save` 覆盖保存走“写临时文件 → `File.Replace` 原子替换”，此前把旧文件传给 `File.Replace` 的第三个参数（备份路径），Windows 替换成功后就把原文件内容写成 `.bak`。
- 修复：`File.Replace(temp, path, null)` 备份参数传 `null`（仍是原子替换，不写 `.bak`）；保存成功后顺手删除该路径下历史遗留的 `.bak`；重试逻辑（应对杀毒 / 同步盘瞬时占用）保持不变。

**Bug｜调试日志残留上线污染 %TEMP%**
- 现象：长期运行后 `%TEMP%/capdf_lv.log` 不断增大，里面是文档恢复位置与整段异常 `StackTrace`。
- 根因：`MainWindow` 在恢复文档（`RESTORE ...`）与恢复异常（`LOADED_EX ...`）时无条件 `File.AppendAllText` 写临时文件，属调试期遗留、随版本上线。
- 修复：移除两处 `AppendAllText` 写入；异常分支保留静默容错（catch 仅吞掉、避免崩溃），不再产生任何日志文件。

**Bug｜撤销历史上限常量与逻辑漂移**
- 现象（维护性）：`AnnotationHistory.Trim` 用字面量 `268435456` 表示 256MB 上限，与类内已定义的 `MaxBytes` 常量若不同步会悄悄改变淘汰行为。
- 修复：统一改用 `MaxBytes` 常量。

**Bug｜P1 内存治理导致打开文件明显变慢**
- 现象：升级到 V1.2.011（P1 把整份 PDF 改存非托管堆）后，打开文件比之前慢很多，文档越大越明显。
- 根因（真正）：P1 把 `File.ReadAllBytes` 换成「64KB 分块循环 + 逐块 `Marshal.Copy`」读盘——上千次小块 P/Invoke 与循环开销，比 `ReadAllBytes` 慢得多；打开时多拷一份整文件托管数组喂历史只是次要因素（已先修，但未解决主因）。
- 修复：`AnnotationHistory` 新增「从非托管缓冲直接分块压缩」的 `Reset(nint, long)` 重载；`PdfDocument` 提供 `SeedHistory`，打开时不再产生这份多余托管副本。打开速度恢复至治理前水平，内存治理收益（非托管堆、无 LOH 钉死）保持不变。

---

## 2026-11-09

**Bug｜多文档点击关闭按钮时确认对话框不显示（或卡死）**
- 现象：此前用原生 `MessageBox` / WPF `MessageBox.Show` / 自定义 `Window.ShowDialog` 在窗口关闭流程中弹出"确认退出"提示，要么直接返回默认值不显示，要么无 UI 卡死。
- 根因：WPF 在 Closing 事件及 WM_SYSCOMMAND/WM_CLOSE 的消息处理栈内无法再启动嵌套 Dispatcher 消息循环（ShowDialog 靠它 pump 消息），而独立线程方案又因自定义对话框访问主线程 `Application.Current.Resources`（主题资源）导致跨线程死锁。
- 修复：将确认改为程序内的主题化覆盖层（属于主窗口可视化树，使用 `DynamicResource Th.*` 资源），拦截 `WM_SYSCOMMAND/SC_CLOSE` 后显示覆盖层而非弹窗，彻底规避该限制。

**Bug｜内存无界增长（页面 / 缩略图缓存与标注编辑）**
- 现象：打开超多页或大容量 PDF 时内存随操作持续攀升——全文档扫描、长文档缩略图滚动、连续标注编辑都会把内存推到数百 MB 甚至上 GB 且不回落。
- 根因：① 注释只读路径（`GetAnnotationsOfPage` / `GetAllAnnotations`）逐页加载 pdfium 页句柄却从不释放，全量扫描把所有页钉在内存（每页带字体 / 图像资源），驻留页数线性等于总页数；② 缩略图缓存超过 150 张时 `Array.Clear` 整批清空再按需重建，长文档滚动反复整批重渲染；③ 标注增删改操作后不释放页句柄，编辑多页时驻留页堆积。
- 修复：① 只读扫描路径读完即 `ReleasePage`（在锁内取句柄消除跨锁悬空，且不引入后台 LRU 的跨线程 use-after-free 崩溃风险）；`GetAllAnnotations` 默认释放页句柄；② 缩略图改为 `LinkedList` 驱动的 LRU 平滑淘汰，仅丢弃最久未用项，所有重置点（换标签 / 关文档 / 撤销重做 / 重新上色 / 标注变更）同步维护 LRU 与计数；③ 高亮 / 形状 / 墨迹 / 文本框 / 图章 / 删除等写方法操作完毕后即时释放页句柄。实测 2002 页文档全扫描工作集 823MB→182MB、标签轮转峰值 1060MB→347MB。
- 附带优化：撤销历史快照改为 gzip 压缩存储，256MB 上限内可容纳步数大幅提升（71MB 文档由仅 3 步提升至近 30 步）。

**Bug｜大文档保存时界面冻结（十几秒）**
- 现象：打开超多页 / 大容量 PDF（如 71MB）点保存 / 另存为，整个窗口冻结十几秒，期间无法滚动、点击。
- 根因：`SaveDoc` / `OnSaveAs` 在 UI 线程同步执行“补齐撤销快照（`Snapshot()`）+ 保存（`doc.Save`）”，两者都是对整份 PDF 的原生 `FPDF_SaveAsCopy` 序列化（71MB 文档各约 5~10 秒），叠加在 UI 线程。
- 修复：新增后台保存方法，把“补齐撤销快照 + 保存”整体搬到右台线程，UI 线程只显示“正在保存…”并保持响应；保存中禁止关标签 / 关窗口（`CloseTab` / `Window_Closing` 加保护），避免中途释放文档崩溃。另存为同样走后台保存。

**Bug｜大文档标注操作很慢（界面卡死）**
- 现象：打开超多页 / 大容量 PDF 时，所有标注操作（高亮、批注、删除等）反应迟缓，每次操作都要卡顿等待。
- 根因：`OnAnnotChanged` 每次标注变更都会调用 `RefreshSaveButton` → `HasAnyAnnotations()`，旧实现逐页调用 `GetAnnotationsOfPage(p)` 遍历全部页（2002 页全扫），只为决定保存按钮是否可用——每次加 / 删一个标注都扫一遍全文档。
- 修复：改为增量维护“有标注的页”集合（`_pagesWithAnnot`，0 基），`OnAnnotChanged` 只探测被改动的单页并更新集合（O(1) 判定）；仅在打开 / 还原后首次判定时惰性全扫一次（且因 `&&` 短路，未修改的文档根本不触发全扫）；后台注释扫描完成时直接据结果填充该集合。

---

## 2026-11-08

**Bug｜大文档（>500 页 / 大容量）标注操作反应迟钝**
- 现象：打开超多页或大容量 PDF 时，所有标注操作（高亮、下划线、矩形、删除等）反应迟缓，每次操作都需要卡顿等待。
- 根因：① 每次标注变更都在 UI 线程同步调用 `Snapshot()` 把整份 PDF 重新序列化（33MB 文档约 5 秒、产物 71MB），历史固定保留 30 份导致大文档下内存占用接近 1GB；② 注释总览每次标注变更都 `GetAllAnnotations()` 全量扫描全部页面（每页需 `FPDF_LoadPage` 加载页对象），2002 页文档下重扫全文会卡住整个界面。
- 修复：撤销快照改为停手后由后台线程生成并延后入栈；历史按总字节封顶（256MB）自动丢弃最旧状态；注释总览改为分批后台扫描（每批 16 页，批间释放锁并让出线程）+ 单页增量更新；大文档（>16MB）撤销分级处理。实测 2002 页 / 33MB 文档标注 UI 耗时 < 1ms、283MB 文档 1.2ms，不再阻塞。

---

## 2026-11-07

**Bug 1｜删除标注保存后重开，被删标注仍在（核心问题）**
- 现象：在注释列表删除若干标注、点保存、重新打开，标注又回来了。
- 根因：`ApplyHistoryState`（Ctrl+Z / Ctrl+Y / 历史点跳转）恢复文档后刷新了页面与缩略图，未重建注释列表——撤销会把已删标注恢复回来而列表却停在旧状态（索引失效）；此时点保存会把“标注已恢复”的文档存盘，重开自然全在。列表“5 条 vs 页面 3 个”的错位即源于此。
- 修复：`ApplyHistoryState` 恢复后重建注释列表；删除按钮点击索引失效时不再静默，而是重建列表并提示“该标注已不存在，列表已刷新”，杜绝旧索引无效点击/误删。

**Bug 2｜注释面板文字在主题切换后看不清**
- 现象：从深色主题切到浅色主题后，注释列表里部分行（尤其浅色标记对应的行）文字看不清。
- 根因：`MakeCommentItem` 用 `Application.Current.FindResource("Th.Text"/"Th.TextMuted")` 取的是构建时刻的画刷快照；主题切换（跟随系统）只替换资源字典，列表行不重建，深色主题下的浅色文字残留配浅色背景 = 看不清。
- 修复：行标题/内容改用 `SetResourceReference` 动态资源引用，主题切换时实时跟随，与搜索面板、翻页三角同机制。

**Bug 3｜删除按钮 ✕ 颜色不随主题切换**
- 现象：✕ 一开始是固定红色，后与翻页三角不同步。
- 根因：初始用固定红色画刷，后被错误指向 `Th.Icon`（树展开箭头的灰）；而翻页三角实际用的是 `Th.TabActiveAccent`（浅色蓝 / 深色橙）。
- 修复：✕ 改绑 `Th.TabActiveAccent`，与翻页三角同源，主题切换实时跟随；另将 ✕ 字形加粗（线条厚度 +1）。

**Bug 4｜修改图章样式后位置偏移**
- 现象：右键图章→修改样式确定后，图章从原虚框位置移到了另一个位置（整体下移约一个印章高度）。
- 根因：`EditStampStyle` 计算旧矩形中心时误把 WPF `Rect.Top` 当作页面上边缘。实际上 `GetRectOf` 把 pdfium 的 `(left,bottom,right,top)`（y 向上）塞进 `new Rect(l,b,w,h)`，即 `Rect.Y`（`Top`）存的是页面下边缘；写成 `cy = old.Top - old.Height/2` 等于把中心放到下边缘再往下半个高，整体下移。
- 修复：中心按 `cy = old.Y + old.Height/2` 计算（下边缘 + 半高），新矩形仍以旧中心定位；宽度随新文字长度自适应但中心不变。

**Bug 5｜修改类弹窗弹出位置未锚定在对象上**
- 现象：图章右键“修改样式”对话框在中部居中弹出，与修改对象位置无关。
- 根因：`StampStyleDialog` 与 `FreeTextEditDialog` 使用 `CenterOwner` 居中，未沿用标注样式/注释编辑对话框已有的“左下角锚定”约定。
- 修复：两个对话框均新增 `Anchor`/`ViewBounds` 与 `Loaded += DialogCentering.ApplyAnchor`，调用处传入修改对象的左下角屏幕坐标（`PagePointToScreenDip(new Point(r.Left, r.Top))`）；统一为所有“修改对象”类弹窗锚定在对象左下角，视图区放不下时改左上角并夹在屏幕工作区内。新建类对话框（创建图章/全局设置）属“创建/全局”而非修改既有对象，保持居中。

**Bug 7｜文本框批注输入中文后页面不显示（双击编辑却能看到文字）**
- 现象：文本框工具点击输入中文、右键退出后，页面上看不到文字；但双击该标注→编辑对话框里文字内容正常。
- 根因：新建/更新文本框时 DA 字体取自偏好默认值 `"Helv"`（Helvetica），该字体无中文字形；pdfium 用它渲染中文时没有可用字形 → 标注框可见、文字空白。编辑对话框直接读取 `Contents` 故能显示，与渲染无关。并非“选择模式/阅读模式冲突”。
- 修复：`ApplyFreeTextStyle`（新建/更新/移动三条路径共用的唯一入口）中，若标注文字含 CJK 且当前 DA 字体非中文字体，则把 DA 字体兜底改为 `"SimSun"`（宋体，pdfium 在 Windows 上可渲染）。就地编辑器同步：输入含中文时实时切换为宋体预览，与提交后一致；若偏好已选宋体/黑体/楷体等中文字体则保持原样。
- 现象：放置图章保存、重新打开后页面上看不到图章；把鼠标移到原位置能看到虚线框（数据层标注在）。
- 根因：叠加显示方案依赖内存缓存 `_stampUi`（页索引→(矩形,位图)），该缓存不持久化；重开后缓存为空而本地 pdfium 画不出无外观流的 stamp 图像，叠加层无从重建。
- 修复：`AddStamp` 时把印章位图 PNG+Base64 写入标注元数据 `StampImage`（与 `StampText`/`StampColor` 同机制，随文档持久化）；`GetStampUi` 配对时发现缓存缺失的现存标注即从元数据重建叠加位图并回填缓存（每次仅重建一次）。撤销后重做同样受益；重开前已保存的旧图章无该元数据，需重新放置。

**Bug 8｜主题 ComboBox 模板缺 PART_TextBox，字号/宽度框不显示也无法输入**
- 现象：双击文本框打开编辑对话框，字号、边框宽度框为空，且手动键入无效。
- 根因：自定义 ComboBox 模板只有 `ContentPresenter`（SelectionBox），没有可编辑状态下的 `TextBox x:Name="PART_TextBox"`；所有 `IsEditable=true` 的下拉框既无法显示 `.Text` 赋值，也无法输入。
- 修复：补全 `PART_TextBox` 与 `PART_ContentHost`，`IsEditable=True` 时显示输入区、隐藏 `ContentPresenter`，不可编辑时反之。

**Bug 9｜自由文本框字体下拉不显示当前字体、仅内置 6 项**
- 现象：编辑已有标注时字体下拉只有 Arial/Times/Courier/宋体/黑体/楷体，且当前字体不回选；选择任意系统字体后写入与渲染断裂。
- 根因：`Fonts` 写死 6 项，下拉项显示元组原文；DA 写入与 `MapFreeTextFont` 只识别内置键；含中文时一律兜底宋体，把用户自选的中文系统字体也替换掉。
- 修复：`BuildFontList()` 列出系统全部字体并去重；下拉用 `DisplayMemberPath` 显示字体名、当前值回选；DA 用族名（空格→下划线）写入；`MapFreeTextFont` 还原下划线键；仅内置 Latin 字体含中文时才兜底宋体。

**Bug 10｜菜单项图标/文字参差不齐**
- 现象：搜索选项等菜单里各条目图标与文字起点错开，视觉混乱。
- 根因：MenuItem 模板勾选列/图标列均为 `Auto` 独立 Grid，可勾选项多出勾选列导致偏移。
- 修复：勾选列与图标列加 `SharedSizeGroup`，弹出菜单容器启用 `Grid.IsSharedSizeScope`，同菜单内所有项对齐并整体左移。

**Bug 11｜点击搜索结果时面板自动横向滚动**
- 现象：点击高级搜索结果（尤其长文本深层行），面板横向滚动条自行移动。
- 根因：与标签栏同类——`TreeView` 内层 `ScrollContentPresenter` 先响应 `BringIntoView` 横向滚动，冒泡到处理器再清零时已被延迟布局覆盖。
- 修复：`OnTreeBringIntoView` 在同步清零后，于 `ContextIdle` 再兜底清零横向偏移。

**Bug 12｜画笔画出的默认色与形状颜色混淆**
- 现象：选画笔后在文档上画的线默认是红色（与矩形/箭头同色），不能直观区分。
- 修复：画笔默认色独立为 `InkStrokeColor`（靛蓝 `#5B5BD6`），与 `ShapeStrokeColor` 分离；取色器回写各走各的偏好。

**Bug 13｜侧栏展开三角与翻页三角颜色不一致**
- 现象：侧栏收起展开三角用 `Th.Icon` 灰，与状态栏翻页三角（强调色）不同。
- 修复：侧栏收起/展开三角统一改用 `NavIcon` 样式（强调色、随主题切换、禁用变灰）。
